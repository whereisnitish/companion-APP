/**
 * Test bootstrap.
 *
 * The native modules the app talks to (keychain, sockets, reanimated) have no
 * JS implementation under jest, so each is replaced with the smallest stub that
 * keeps the code under test honest.
 */

import { configure } from '@testing-library/react-native';

// The RN 0.81 jest environment is slower than the default 1s async timeout
// assumes; a screen that mounts, fetches and paints can exceed it on a cold
// worker. Kept under jest's own 5s so a real failure reports as a failed
// assertion rather than an opaque test timeout.
configure({ asyncUtilTimeout: 3000 });

// Reanimated's native worklets runtime does not exist under jest; its own mock
// keeps the animated components renderable so layout can still be asserted.
jest.mock('react-native-reanimated', () => require('react-native-reanimated/mock'));

jest.mock('expo-secure-store', () => ({
  getItemAsync: jest.fn(async () => null),
  setItemAsync: jest.fn(async () => undefined),
  deleteItemAsync: jest.fn(async () => undefined),
}));

jest.mock('expo-font', () => ({
  useFonts: () => [true, null],
  isLoaded: () => true,
  loadAsync: jest.fn(async () => undefined),
}));

jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
);

// The socket is an enhancement layer; tests assert on REST-backed state.
jest.mock('../src/core/realtime/socketClient', () => {
  class SocketClient {
    isConnected = false;
    subscribe() {
      return () => undefined;
    }
    connect() {}
    send() {}
    sendTyping() {}
    disconnect() {}
    dispose() {}
  }
  return { SocketClient };
});
