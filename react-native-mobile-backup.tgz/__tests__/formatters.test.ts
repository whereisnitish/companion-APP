import { Format } from '../src/core/utils/formatters';

const daysFromNow = (days: number, hours: number, minutes = 0) => {
  const base = new Date();
  base.setDate(base.getDate() + days);
  return new Date(base.getFullYear(), base.getMonth(), base.getDate(), hours, minutes);
};

describe('Format.whenLabel', () => {
  test('calls an evening today "Tonight"', () => {
    expect(Format.whenLabel(daysFromNow(0, 20, 30))).toMatch(/^Tonight · /);
  });

  test('calls a morning today "Today"', () => {
    expect(Format.whenLabel(daysFromNow(0, 9))).toMatch(/^Today · /);
  });

  test('names tomorrow explicitly', () => {
    expect(Format.whenLabel(daysFromNow(1, 19))).toMatch(/^Tomorrow · /);
  });

  test('uses the weekday inside the coming week', () => {
    const label = Format.whenLabel(daysFromNow(3, 18));
    expect(label).toContain(',');
    expect(label).not.toContain('Tomorrow');
  });

  test('crosses midnight by calendar day, not by elapsed hours', () => {
    // 23:30 today and 00:30 tomorrow are one hour apart but different days.
    const lateTonight = daysFromNow(0, 23, 30);
    const earlyTomorrow = new Date(lateTonight.getTime() + 60 * 60 * 1000);
    expect(Format.whenLabel(lateTonight)).toMatch(/^Tonight/);
    expect(Format.whenLabel(earlyTomorrow)).toMatch(/^Tomorrow/);
  });
});

describe('Format.relative', () => {
  const ago = (ms: number) => new Date(Date.now() - ms);

  test('reads "just now" under a minute', () => {
    expect(Format.relative(ago(20_000))).toBe('just now');
  });

  test('counts minutes, then hours, then days', () => {
    expect(Format.relative(ago(12 * 60_000))).toBe('12m');
    expect(Format.relative(ago(3 * 3_600_000))).toBe('3h');
    expect(Format.relative(ago(2 * 86_400_000))).toBe('2d');
  });

  test('falls back to a date beyond a week', () => {
    expect(Format.relative(ago(30 * 86_400_000))).not.toMatch(/d$/);
  });
});

describe('Format.distance', () => {
  test('switches to metres below a kilometre', () => {
    expect(Format.distance(0.42)).toBe('420 m away');
  });

  test('keeps one decimal under ten kilometres', () => {
    expect(Format.distance(2.44)).toBe('2.4 km away');
  });

  test('drops the decimal beyond ten kilometres', () => {
    expect(Format.distance(24.4)).toBe('24 km away');
  });

  test('renders nothing when distance is hidden', () => {
    expect(Format.distance(null)).toBe('');
  });
});

describe('Format.lastSeen', () => {
  test('prefers live presence over a timestamp', () => {
    const longAgo = new Date(Date.now() - 3 * 86_400_000);
    expect(Format.lastSeen(longAgo, true)).toBe('Active now');
  });

  test('degrades gracefully with no timestamp', () => {
    expect(Format.lastSeen(null, false)).toBe('Offline');
  });
});

describe('Format.initials', () => {
  test('takes first and last initials', () => expect(Format.initials('Sara Mehta')).toBe('SM'));
  test('handles a single name', () => expect(Format.initials('Nitish')).toBe('N'));
  test('handles a middle name', () => expect(Format.initials('A B C')).toBe('AC'));
  test('never throws on empty input', () => expect(Format.initials('   ')).toBe('?'));
});
