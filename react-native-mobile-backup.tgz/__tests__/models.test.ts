import { parseActivity, isOpen, spotsLeft } from '../src/models/activity';
import { parseMessage, isRead, isSystem } from '../src/models/conversation';
import { ACTIVITY_CATEGORIES, isInvitationOpen, isVerified } from '../src/models/enums';
import { orderedCategories, parseHomeFeed } from '../src/models/homeFeed';
import { headline, isReceived, parseInvitation, resolvedCategory } from '../src/models/invitation';
import { firstName, gallery, parseCurrentUser, parseProfile } from '../src/models/profile';

describe('parseProfile', () => {
  test('parses a full payload', () => {
    const profile = parseProfile({
      id: 'u1',
      displayName: 'Sara Mehta',
      age: 24,
      gender: 'FEMALE',
      bio: 'Chronically early to films.',
      occupation: 'Product designer',
      city: 'Bengaluru',
      area: 'Indiranagar',
      avatarUrl: 'https://example.com/a.jpg',
      photos: ['https://example.com/b.jpg'],
      interests: [{ slug: 'indie-films', label: 'Indie films', emoji: '🎞' }],
      preferredActivities: ['MOVIE', 'COFFEE'],
      availability: ['TONIGHT'],
      verification: 'VERIFIED',
      rating: { average: 4.9, count: 23 },
      distanceKm: 2.4,
      isOnline: true,
      lastActiveAt: '2026-08-31T06:00:00.000Z',
    });

    expect(profile.displayName).toBe('Sara Mehta');
    expect(firstName(profile)).toBe('Sara');
    expect(profile.preferredActivities).toEqual(['MOVIE', 'COFFEE']);
    expect(profile.availability).toEqual(['TONIGHT']);
    expect(isVerified(profile.verification)).toBe(true);
    expect(profile.ratingAverage).toBe(4.9);
    expect(profile.interests[0]?.label).toBe('Indie films');
  });

  test('survives an empty object without throwing', () => {
    const profile = parseProfile({});
    expect(profile.displayName).toBe('Someone');
    expect(profile.age).toBeNull();
    expect(gallery(profile)).toEqual([]);
    expect(profile.verification).toBe('UNVERIFIED');
  });

  test('maps an unknown enum value to a safe default rather than throwing', () => {
    const profile = parseProfile({
      gender: 'MARTIAN',
      preferredActivities: ['TELEPORTING'],
    });
    expect(profile.gender).toBe('OTHER');
    expect(profile.preferredActivities).toEqual(['OTHER']);
  });

  test('gallery puts the avatar first and de-duplicates', () => {
    const profile = parseProfile({ avatarUrl: 'a.jpg', photos: ['a.jpg', 'b.jpg'] });
    expect(gallery(profile)).toEqual(['a.jpg', 'b.jpg']);
  });

  test('respects a hidden age', () => {
    expect(parseProfile({ age: null }).age).toBeNull();
  });
});

describe('parseCurrentUser', () => {
  test('carries the owner-only fields', () => {
    const me = parseCurrentUser({
      id: 'u0',
      displayName: 'Nitish',
      email: 'demo@companion.app',
      isDiscoverable: false,
      showDistance: true,
      showAge: false,
      isProfileComplete: true,
      latitude: 12.97,
      longitude: 77.64,
    });

    expect(me.email).toBe('demo@companion.app');
    expect(me.isDiscoverable).toBe(false);
    expect(me.isProfileComplete).toBe(true);
    expect(me.latitude).toBe(12.97);
  });
});

describe('parseActivity', () => {
  test('parses a plan and its host', () => {
    const activity = parseActivity({
      id: 'a1',
      category: 'MOVIE',
      title: 'The late show',
      startsAt: '2026-09-01T16:10:00.000Z',
      locationName: 'PVR Orion',
      capacity: 2,
      participantCount: 1,
      status: 'OPEN',
      host: { id: 'u1', displayName: 'Sara Mehta' },
      viewerInvitationStatus: 'PENDING',
    });

    expect(activity.category).toBe('MOVIE');
    expect(isOpen(activity)).toBe(true);
    expect(spotsLeft(activity)).toBe(2);
    expect(firstName(activity.host)).toBe('Sara');
    expect(activity.viewerInvitationStatus).toBe('PENDING');
  });

  test('leaves viewerInvitationStatus null when absent', () => {
    expect(parseActivity({ category: 'COFFEE' }).viewerInvitationStatus).toBeNull();
  });
});

describe('parseInvitation', () => {
  test('reads direction and falls back to the activity for context', () => {
    const invitation = parseInvitation({
      id: 'i1',
      direction: 'received',
      status: 'PENDING',
      message: 'Come along?',
      counterpart: { id: 'u1', displayName: 'Sara Mehta' },
      activity: {
        id: 'a1',
        category: 'MOVIE',
        title: 'The late show',
        startsAt: '2026-09-01T16:10:00.000Z',
        host: { id: 'u1', displayName: 'Sara Mehta' },
      },
    });

    expect(isReceived(invitation)).toBe(true);
    expect(isInvitationOpen(invitation.status)).toBe(true);
    expect(resolvedCategory(invitation)).toBe('MOVIE');
    expect(headline(invitation)).toBe('The late show');
  });

  test('builds a headline for a free-form proposal', () => {
    const invitation = parseInvitation({
      direction: 'sent',
      status: 'ACCEPTED',
      category: 'COFFEE',
      counterpart: { displayName: 'Ananya Bose' },
    });

    expect(isReceived(invitation)).toBe(false);
    expect(isInvitationOpen(invitation.status)).toBe(false);
    expect(headline(invitation)).toBe('Up for something for coffee?');
  });
});

describe('parseMessage', () => {
  test('distinguishes system messages', () => {
    const message = parseMessage({
      id: 'm1',
      type: 'SYSTEM',
      body: 'You are both in.',
      isMine: false,
    });
    expect(isSystem(message)).toBe(true);
    expect(isRead(message)).toBe(false);
    expect(message.isPending).toBe(false);
  });
});

describe('HomeFeed', () => {
  test('orderedCategories returns all twelve, busiest first', () => {
    const feed = parseHomeFeed({
      greeting: 'EVENING',
      city: 'Bengaluru',
      categories: [
        { category: 'COFFEE', openActivities: 1, people: 0 },
        { category: 'MOVIE', openActivities: 5, people: 2 },
      ],
      pendingInvitations: 4,
    });

    const ordered = orderedCategories(feed);
    expect(feed.greeting).toBe('EVENING');
    expect(ordered).toHaveLength(ACTIVITY_CATEGORIES.length);
    expect(ordered[0]?.category).toBe('MOVIE');
    expect(ordered[1]?.category).toBe('COFFEE');
    expect(feed.pendingInvitations).toBe(4);
  });
});
