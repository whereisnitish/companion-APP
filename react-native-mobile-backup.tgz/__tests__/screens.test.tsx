import React from 'react';
import { act, waitFor } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';

import { HomeScreen } from '../src/features/home/HomeScreen';
import { ConversationsScreen } from '../src/features/chat/ConversationsScreen';
import { InvitationsScreen } from '../src/features/invitations/InvitationsScreen';
import { SplashScreen } from '../src/features/onboarding/SplashScreen';
import { InviteSheetProvider } from '../src/features/invitations/InviteSheet';
import { parseHomeFeed, type HomeFeed } from '../src/models/homeFeed';
import { parseCurrentUser } from '../src/models/profile';
import {
  conversationService,
  discoveryService,
  invitationService,
  notificationService,
} from '../src/services';
import { useAuthStore } from '../src/stores';
import { renderWithProviders } from './helpers';

const me = parseCurrentUser({
  id: 'u0',
  displayName: 'Nitish Kumar',
  city: 'Bengaluru',
  area: 'Indiranagar',
  isProfileComplete: true,
});

/** Every screen sits under a navigator and the invite host in the real app. */
const withShell = (ui: React.ReactElement) => (
  <NavigationContainer>
    <InviteSheetProvider>{ui}</InviteSheetProvider>
  </NavigationContainer>
);

const baseFeed = {
  greeting: 'EVENING',
  city: 'Bengaluru',
  categories: [{ category: 'MOVIE', openActivities: 5, people: 2 }],
  peopleNearby: [],
  activitiesNearby: [],
  tonight: [],
  pendingInvitations: 0,
  unreadMessages: 0,
};

/**
 * Home's greeting also reads the notification badge, so both calls are stubbed:
 * an unmocked one would reach the real axios client and, on failure, trip the
 * session-expiry path that clears the signed-in user mid-test.
 */
const mockFeed = (overrides: Record<string, unknown> = {}): HomeFeed => {
  const feed = parseHomeFeed({ ...baseFeed, ...overrides });
  jest.spyOn(discoveryService, 'fetchHomeFeed').mockResolvedValue(feed);
  jest.spyOn(notificationService, 'list').mockResolvedValue({ items: [], unreadCount: 0 });
  return feed;
};

beforeEach(() => {
  useAuthStore.setState({ stage: 'ready', user: me });
});

afterEach(() => {
  jest.restoreAllMocks();
});

describe('SplashScreen', () => {
  // The splash drives itself off requestAnimationFrame; fake timers let the
  // 1.5s timeline run to completion inside act rather than leaking past it.
  beforeEach(() => jest.useFakeTimers());
  afterEach(() => jest.useRealTimers());

  test('draws the wordmark and the tagline', async () => {
    const { getByText } = await renderWithProviders(<SplashScreen />);

    expect(getByText('Companion')).toBeTruthy();
    expect(getByText('Never do it alone.')).toBeTruthy();

    await act(async () => {
      jest.advanceTimersByTime(1600);
    });
  });
});

describe('HomeScreen', () => {
  test('greets by name and answers "what can I do today?" first', async () => {
    mockFeed();
    const { getByText } = await renderWithProviders(withShell(<HomeScreen />));

    await waitFor(() => expect(getByText('Nitish')).toBeTruthy());
    expect(getByText('Good evening')).toBeTruthy();
    expect(getByText('What are you up for?')).toBeTruthy();
    expect(getByText('Bengaluru')).toBeTruthy();
  });

  test('surfaces waiting invitations at the top', async () => {
    mockFeed({ pendingInvitations: 3 });
    const { getByText } = await renderWithProviders(withShell(<HomeScreen />));

    await waitFor(() => expect(getByText('3 people invited you')).toBeTruthy());
  });

  test('reads the singular when exactly one invitation is waiting', async () => {
    mockFeed({ pendingInvitations: 1 });
    const { getByText } = await renderWithProviders(withShell(<HomeScreen />));

    await waitFor(() => expect(getByText('Someone invited you')).toBeTruthy());
  });

  test('hides the invitation banner when nothing is waiting', async () => {
    mockFeed();
    const { getByText, queryByText } = await renderWithProviders(withShell(<HomeScreen />));

    await waitFor(() => expect(getByText('Nitish')).toBeTruthy());
    expect(queryByText(/invited you/)).toBeNull();
  });

  test('shows an empty state when nothing is on nearby', async () => {
    mockFeed();
    const { getByText } = await renderWithProviders(withShell(<HomeScreen />));

    await waitFor(() => expect(getByText('Quiet around here')).toBeTruthy());
  });
});

describe('ConversationsScreen', () => {
  test('says all caught up with an empty, read inbox', async () => {
    jest.spyOn(conversationService, 'list').mockResolvedValue([]);
    const { getByText } = await renderWithProviders(withShell(<ConversationsScreen />));

    await waitFor(() => expect(getByText('No conversations yet')).toBeTruthy());
    expect(getByText('All caught up.')).toBeTruthy();
  });
});

describe('InvitationsScreen', () => {
  test('leads with what is waiting on you', async () => {
    jest
      .spyOn(invitationService, 'counts')
      .mockResolvedValue({ pendingReceived: 2, pendingSent: 1, accepted: 4 });
    jest.spyOn(invitationService, 'list').mockResolvedValue([]);

    const { getByText } = await renderWithProviders(withShell(<InvitationsScreen />));

    await waitFor(() => expect(getByText('2 waiting on your answer.')).toBeTruthy());
    expect(getByText('Received')).toBeTruthy();
    expect(getByText('Sent')).toBeTruthy();
  });

  test('offers a way forward when there is nothing received', async () => {
    jest
      .spyOn(invitationService, 'counts')
      .mockResolvedValue({ pendingReceived: 0, pendingSent: 0, accepted: 0 });
    jest.spyOn(invitationService, 'list').mockResolvedValue([]);

    const { getByText } = await renderWithProviders(withShell(<InvitationsScreen />));

    await waitFor(() => expect(getByText('No invitations yet')).toBeTruthy());
    expect(getByText('Post a plan')).toBeTruthy();
  });
});
