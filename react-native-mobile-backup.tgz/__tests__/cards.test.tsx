import React from 'react';
import { fireEvent, screen } from '@testing-library/react-native';

import { ActivityCard, AppAvatar, AvatarStack, PersonCard, StateView } from '../src/components';
import { ApiException } from '../src/core/network/apiException';
import { errorStateProps } from '../src/components/StateViews';
import { makeActivity, makeProfile, renderWithProviders } from './helpers';

describe('PersonCard', () => {
  test('leads with name, then bio, then what they are up for', async () => {
    await renderWithProviders(<PersonCard profile={makeProfile()} />);

    expect(screen.getByText('Sara Mehta')).toBeTruthy();
    expect(screen.getByText(/Chronically early to films/)).toBeTruthy();
    expect(screen.getByText('UP FOR')).toBeTruthy();
    expect(screen.getByText('Movie')).toBeTruthy();
  });

  test('shows the presence pill only when online', async () => {
    const { rerender } = await renderWithProviders(<PersonCard profile={makeProfile()} />);
    expect(screen.getByText('Active now')).toBeTruthy();

    await rerender(<PersonCard profile={makeProfile({ isOnline: false })} />);
    expect(screen.queryByText('Active now')).toBeNull();
  });

  test('omits distance when the person hides it', async () => {
    await renderWithProviders(<PersonCard profile={makeProfile({ distanceKm: null })} />);
    expect(screen.queryByText('2.4km')).toBeNull();
  });

  test('falls back to initials with no photo', async () => {
    await renderWithProviders(<PersonCard profile={makeProfile({ avatarUrl: null, photos: [] })} />);
    expect(screen.getByText('SM')).toBeTruthy();
  });

  test('renders without a bio, activities or availability', async () => {
    await renderWithProviders(
      <PersonCard
        profile={makeProfile({ bio: '', preferredActivities: [], availability: [] })}
      />,
    );
    expect(screen.getByText('Sara Mehta')).toBeTruthy();
    expect(screen.queryByText('UP FOR')).toBeNull();
  });

  test('invite button reaches its callback', async () => {
    const onInvite = jest.fn();
    await renderWithProviders(<PersonCard profile={makeProfile()} onInvite={onInvite} />);

    fireEvent.press(screen.getByText('Invite'));
    expect(onInvite).toHaveBeenCalledTimes(1);
  });

  test('a very long name and bio still render', async () => {
    await renderWithProviders(
      <PersonCard
        profile={makeProfile({
          displayName: 'Anantapadmanabhan Venkataraghavan Subrahmanyam',
          bio: 'A '.repeat(400),
        })}
      />,
    );
    expect(screen.getByText(/Anantapadmanabhan/)).toBeTruthy();
  });
});

describe('ActivityCard', () => {
  test('puts the time above the title', async () => {
    await renderWithProviders(<ActivityCard activity={makeActivity()} />);

    expect(screen.getByText('The late show at PVR Orion')).toBeTruthy();
    // whenLabel uppercases into the eyebrow slot.
    expect(screen.getByText(/TONIGHT|TODAY|TOMORROW/)).toBeTruthy();
  });

  test('labels your own plan instead of offering Join', async () => {
    await renderWithProviders(<ActivityCard activity={makeActivity({ isHost: true })} />);

    expect(screen.getByText('Your plan')).toBeTruthy();
    expect(screen.queryByText('Join')).toBeNull();
  });

  test('replaces Join with a status once you have asked', async () => {
    await renderWithProviders(
      <ActivityCard activity={makeActivity({ viewerInvitationStatus: 'PENDING' })} />,
    );

    expect(screen.getByText('Waiting')).toBeTruthy();
    expect(screen.queryByText('Join')).toBeNull();
  });

  test('renders every category', async () => {
    const categories = ['MOVIE', 'DINNER', 'COFFEE', 'WALK', 'GAMING', 'OTHER'];
    for (const category of categories) {
      const view = await renderWithProviders(<ActivityCard activity={makeActivity({ category })} />);
      expect(view.getByText('The late show at PVR Orion')).toBeTruthy();
      await view.unmount();
    }
  });
});

describe('AppAvatar', () => {
  test('gives the same person the same fallback colour twice', async () => {
    const first = await renderWithProviders(<AppAvatar name="Sara Mehta" />);
    const firstInitials = first.getByText('SM');
    const firstColor = firstInitials.props.style.flat().find((s: { color?: string }) => s?.color);
    await first.unmount();

    const second = await renderWithProviders(<AppAvatar name="Sara Mehta" />);
    const secondInitials = second.getByText('SM');
    const secondColor = secondInitials.props.style.flat().find((s: { color?: string }) => s?.color);

    expect(firstColor).toEqual(secondColor);
  });

  test('AvatarStack collapses the overflow into a counter', async () => {
    await renderWithProviders(
      <AvatarStack
        entries={[
          { name: 'A A' },
          { name: 'B B' },
          { name: 'C C' },
          { name: 'D D' },
          { name: 'E E' },
        ]}
      />,
    );
    expect(screen.getByText('+2')).toBeTruthy();
  });
});

describe('StateView', () => {
  test('renders an empty state with its action', async () => {
    const onAction = jest.fn();
    await renderWithProviders(
      <StateView
        icon="event-busy"
        title="Quiet around here"
        message="No open plans nearby yet."
        actionLabel="Create a plan"
        onAction={onAction}
      />,
    );

    expect(screen.getByText('Quiet around here')).toBeTruthy();
    fireEvent.press(screen.getByText('Create a plan'));
    expect(onAction).toHaveBeenCalledTimes(1);
  });

  test('turns a network failure into plain language', async () => {
    const props = errorStateProps(
      new ApiException({ message: 'socket hang up', code: 'NETWORK_ERROR' }),
    );

    expect(props.title).toBe('No connection');
    expect(props.message).not.toContain('socket hang up');
    expect(props.tone).toBe('warning');
  });
});
