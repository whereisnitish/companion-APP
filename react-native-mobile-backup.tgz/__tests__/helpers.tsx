import React, { type ReactElement, type ReactNode } from 'react';
import { render, type RenderOptions } from '@testing-library/react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { SnackbarProvider } from '../src/components';
import { parseActivity, type Activity } from '../src/models/activity';
import { parseProfile, type Profile } from '../src/models/profile';
import { ThemeProvider } from '../src/theme';

const insets = { frame: { x: 0, y: 0, width: 390, height: 844 }, insets: { top: 47, left: 0, right: 0, bottom: 34 } };

function Providers({ children }: { children: ReactNode }) {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false, gcTime: 0 } },
  });

  return (
    <SafeAreaProvider initialMetrics={insets}>
      <QueryClientProvider client={client}>
        <ThemeProvider>
          <SnackbarProvider>{children}</SnackbarProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}

/**
 * Renders inside the same provider stack the real app mounts.
 *
 * RNTL 14's `render` is async (it awaits `act`), so every call site awaits.
 */
export function renderWithProviders(ui: ReactElement, options?: RenderOptions) {
  return render(ui, { wrapper: Providers, ...options });
}

/** A fully populated person, so a card has every element to lay out. */
export function makeProfile(overrides: Record<string, unknown> = {}): Profile {
  return parseProfile({
    id: 'u1',
    displayName: 'Sara Mehta',
    age: 24,
    gender: 'FEMALE',
    bio: 'Chronically early to films. Will debate the ending over coffee.',
    occupation: 'Product designer',
    city: 'Bengaluru',
    area: 'Indiranagar',
    avatarUrl: null,
    photos: [],
    interests: [{ slug: 'indie-films', label: 'Indie films', emoji: '🎞' }],
    preferredActivities: ['MOVIE', 'COFFEE'],
    availability: ['TONIGHT'],
    verification: 'VERIFIED',
    rating: { average: 4.9, count: 23 },
    distanceKm: 2.4,
    isOnline: true,
    lastActiveAt: new Date().toISOString(),
    ...overrides,
  });
}

export function makeActivity(overrides: Record<string, unknown> = {}): Activity {
  return parseActivity({
    id: 'a1',
    category: 'MOVIE',
    title: 'The late show at PVR Orion',
    description: 'Booked two tickets and my friend bailed.',
    startsAt: new Date(Date.now() + 3 * 3_600_000).toISOString(),
    locationName: 'PVR Orion Mall',
    area: 'Rajajinagar',
    city: 'Bengaluru',
    capacity: 2,
    participantCount: 1,
    status: 'OPEN',
    minAge: 18,
    maxAge: 99,
    lookingFor: 'ANYONE',
    distanceKm: 2.4,
    isHost: false,
    host: {
      id: 'u1',
      displayName: 'Sara Mehta',
      age: 24,
      verification: 'VERIFIED',
      isOnline: true,
    },
    ...overrides,
  });
}
