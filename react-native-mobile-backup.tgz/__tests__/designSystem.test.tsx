import React from 'react';
import { Text, View } from 'react-native';
import { fireEvent, screen } from '@testing-library/react-native';

import {
  AppButton,
  AppChip,
  AppTextField,
  CategoryChip,
  StatusPill,
  VerifiedBadge,
} from '../src/components';
import { ACTIVITY_CATEGORIES, categoryMeta } from '../src/models/enums';
import { darkColors, lightColors, buildTypography, type AppColors } from '../src/theme';
import { renderWithProviders } from './helpers';

describe('theme', () => {
  test('light and dark palettes define every token distinctly', () => {
    const keys = Object.keys(lightColors) as (keyof AppColors)[];

    for (const key of keys) {
      expect(lightColors[key]).toBeTruthy();
      expect(darkColors[key]).toBeTruthy();
      // Every token is genuinely re-tuned for dark rather than reused.
      expect(lightColors[key]).not.toBe(darkColors[key]);
    }
  });

  test('the type scale keeps its sizes and carries the ink colour', () => {
    const type = buildTypography('#16211C');

    expect(type.display.fontSize).toBe(34);
    expect(type.headline.fontSize).toBe(28);
    expect(type.body.fontSize).toBe(15);
    expect(type.overline.textTransform).toBe('uppercase');
    expect(type.numeric.fontVariant).toContain('tabular-nums');
    expect(type.body.color).toBe('#16211C');
  });
});

describe('AppButton', () => {
  test('fires onPress and shows its label', async () => {
    const onPress = jest.fn();
    await renderWithProviders(<AppButton label="Send invitation" onPress={onPress} />);

    expect(screen.getByText('Send invitation')).toBeTruthy();
    fireEvent.press(screen.getByText('Send invitation'));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  test('is inert while loading', async () => {
    const onPress = jest.fn();
    await renderWithProviders(<AppButton label="Send" onPress={onPress} isLoading />);

    // The label is swapped for a spinner, so there is nothing to press.
    expect(screen.queryByText('Send')).toBeNull();
    expect(onPress).not.toHaveBeenCalled();
  });

  test('is inert when disabled', async () => {
    const onPress = jest.fn();
    await renderWithProviders(<AppButton label="Continue" onPress={null} />);

    fireEvent.press(screen.getByText('Continue'));
    expect(onPress).not.toHaveBeenCalled();
  });

  test('renders every variant', async () => {
    for (const variant of ['primary', 'secondary', 'ghost', 'danger'] as const) {
      const view = await renderWithProviders(
        <AppButton label={variant} variant={variant} onPress={() => undefined} />,
      );
      expect(view.getByText(variant)).toBeTruthy();
      await view.unmount();
    }
  });
});

describe('chips', () => {
  test('CategoryChip shows the label and toggles', async () => {
    const onPress = jest.fn();
    await renderWithProviders(<CategoryChip category="MOVIE" onPress={onPress} />);

    fireEvent.press(screen.getByText('Movie'));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  test('every category has its own label and icon', () => {
    const labels = new Set<string>();
    const icons = new Set<string>();

    for (const category of ACTIVITY_CATEGORIES) {
      const meta = categoryMeta(category);
      labels.add(meta.label);
      icons.add(meta.icon as string);
      expect(meta.hue).toMatch(/^#[0-9A-F]{6}$/i);
    }

    expect(labels.size).toBe(ACTIVITY_CATEGORIES.length);
    expect(icons.size).toBe(ACTIVITY_CATEGORIES.length);
  });

  test('StatusPill carries the right words per status', async () => {
    const expected = {
      PENDING: 'Waiting',
      ACCEPTED: 'Accepted',
      DECLINED: 'Declined',
      CANCELLED: 'Withdrawn',
      EXPIRED: 'Expired',
    } as const;

    for (const [status, label] of Object.entries(expected)) {
      const view = await renderWithProviders(
        <StatusPill status={status as keyof typeof expected} />,
      );
      expect(view.getByText(label)).toBeTruthy();
      await view.unmount();
    }
  });

  test('VerifiedBadge is invisible unless verified', async () => {
    // Wrapped so the assertion is about the badge's own output, not the
    // provider tree the helper mounts around it.
    const unverified = await renderWithProviders(
      <View testID="slot">
        <VerifiedBadge status="UNVERIFIED" />
      </View>,
    );
    expect(unverified.getByTestId('slot').children).toHaveLength(0);
    await unverified.unmount();

    const verified = await renderWithProviders(
      <View testID="slot">
        <VerifiedBadge status="VERIFIED" />
      </View>,
    );
    expect(verified.getByTestId('slot').children.length).toBeGreaterThan(0);
  });

  test('AppChip renders a leading node when given one', async () => {
    await renderWithProviders(
      <AppChip label="Indie films" leading={<Text>🎞</Text>} dense />,
    );
    expect(screen.getByText('Indie films')).toBeTruthy();
    expect(screen.getByText('🎞')).toBeTruthy();
  });
});

describe('AppTextField', () => {
  test('reports changes and shows an error', async () => {
    const onChangeText = jest.fn();
    await renderWithProviders(
      <AppTextField
        testID="email"
        value=""
        label="Email"
        onChangeText={onChangeText}
        errorText="That address is already in use."
      />,
    );

    fireEvent.changeText(screen.getByTestId('email'), 'sara@example.com');
    expect(onChangeText).toHaveBeenCalledWith('sara@example.com');
    expect(screen.getByText('That address is already in use.')).toBeTruthy();
  });

  test('obscured fields start hidden and offer a reveal toggle', async () => {
    await renderWithProviders(
      <AppTextField testID="password" value="hunter2" secureTextEntry label="Password" />,
    );

    const input = screen.getByTestId('password');
    expect(input.props.secureTextEntry).toBe(true);
  });

  test('shows helper text when there is no error', async () => {
    await renderWithProviders(
      <AppTextField value="" label="Bio" helper="0/500" />,
    );
    expect(screen.getByText('0/500')).toBeTruthy();
  });
});
