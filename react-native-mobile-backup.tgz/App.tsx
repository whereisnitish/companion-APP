import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  useFonts,
  Inter_400Regular,
  Inter_600SemiBold,
  Inter_700Bold,
} from '@expo-google-fonts/inter';
import { Fraunces_600SemiBold } from '@expo-google-fonts/fraunces';

import { InviteSheetProvider } from './src/features/invitations/InviteSheet';
import { SafetyActionsProvider } from './src/features/settings/SafetyActionsSheet';
import { RootNavigator } from './src/navigation/RootNavigator';
import { connectRealtimeToQueryCache } from './src/queries';
import { socketClient } from './src/services';
import { SnackbarProvider } from './src/components';
import { useAuthStore } from './src/stores';
import { ThemeProvider, useTheme } from './src/theme';

void SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Realtime pushes the invalidations that matter, so polling on focus
      // would only duplicate work.
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 30_000,
    },
  },
});

export default function App() {
  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_600SemiBold,
    Inter_700Bold,
    Fraunces_600SemiBold,
  });

  const restore = useAuthStore((state) => state.restore);
  const [restored, setRestored] = useState(false);

  useEffect(() => {
    void restore().finally(() => setRestored(true));
  }, [restore]);

  useEffect(() => connectRealtimeToQueryCache(queryClient), []);

  useEffect(() => () => socketClient.dispose(), []);

  useEffect(() => {
    if (fontsLoaded && restored) void SplashScreen.hideAsync();
  }, [fontsLoaded, restored]);

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <ThemeProvider>
            <SnackbarProvider>
              <SafetyActionsProvider>
                <InviteSheetProvider>
                  <Shell />
                </InviteSheetProvider>
              </SafetyActionsProvider>
            </SnackbarProvider>
          </ThemeProvider>
        </QueryClientProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

/**
 * Sits inside ThemeProvider so the navigation container and the status bar can
 * read the same palette the rest of the app uses.
 */
function Shell() {
  const { colors, isDark } = useTheme();

  const navigationTheme = {
    ...(isDark ? DarkTheme : DefaultTheme),
    colors: {
      ...(isDark ? DarkTheme : DefaultTheme).colors,
      primary: colors.primary,
      background: colors.canvas,
      card: colors.surface,
      text: colors.ink,
      border: colors.border,
    },
  };

  return (
    <NavigationContainer theme={navigationTheme}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <RootNavigator />
    </NavigationContainer>
  );
}
