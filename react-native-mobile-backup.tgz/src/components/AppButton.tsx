import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import type { MaterialIconName } from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';
import { PressEffect } from './PressEffect';

export type AppButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type AppButtonSize = 'large' | 'medium' | 'small';

interface AppButtonProps {
  label: string;
  onPress?: (() => void) | null;
  variant?: AppButtonVariant;
  size?: AppButtonSize;
  icon?: MaterialIconName;
  trailingIcon?: MaterialIconName;
  isLoading?: boolean;
  expand?: boolean;
}

const HEIGHTS: Record<AppButtonSize, number> = { large: 54, medium: 46, small: 38 };
const PADDING: Record<AppButtonSize, number> = {
  large: AppSpacing.xxl,
  medium: AppSpacing.xl,
  small: AppSpacing.lg,
};

/**
 * The one button in the product. Four variants, three sizes, no exceptions —
 * which is why a screen never has to decide what a button looks like.
 */
export function AppButton({
  label,
  onPress,
  variant = 'primary',
  size = 'large',
  icon,
  trailingIcon,
  isLoading = false,
  expand = true,
}: AppButtonProps) {
  const { colors, type } = useTheme();

  const enabled = !!onPress && !isLoading;

  const palette: Record<AppButtonVariant, { background: string; foreground: string; border?: string }> =
    {
      primary: { background: colors.primary, foreground: colors.onPrimary },
      secondary: { background: colors.surface, foreground: colors.ink, border: colors.borderStrong },
      ghost: { background: 'transparent', foreground: colors.ink },
      danger: { background: colors.dangerSoft, foreground: colors.danger },
    };

  const { background, foreground, border } = palette[variant];
  const iconSize = size === 'small' ? 16 : 18;
  const textStyle = [size === 'small' ? type.label : type.button, { color: foreground }];

  return (
    <PressEffect onPress={onPress} enabled={enabled} scale={0.975}>
      <View
        style={[
          styles.container,
          {
            height: HEIGHTS[size],
            paddingHorizontal: PADDING[size],
            backgroundColor: background,
            opacity: enabled ? 1 : 0.4,
            alignSelf: expand ? 'stretch' : 'flex-start',
          },
          border ? { borderWidth: 1, borderColor: border } : null,
        ]}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color={foreground} />
        ) : (
          <View style={styles.row}>
            {icon ? (
              <MaterialIcons
                name={icon}
                size={iconSize}
                color={foreground}
                style={styles.leadingIcon}
              />
            ) : null}
            <Text style={textStyle} numberOfLines={1} ellipsizeMode="tail">
              {label}
            </Text>
            {trailingIcon ? (
              <MaterialIcons
                name={trailingIcon}
                size={iconSize}
                color={foreground}
                style={styles.trailingIcon}
              />
            ) : null}
          </View>
        )}
      </View>
    </PressEffect>
  );
}

interface AppIconButtonProps {
  icon: MaterialIconName;
  onPress?: (() => void) | null;
  size?: number;
  iconSize?: number;
  background?: string;
  foreground?: string;
  bordered?: boolean;
  accessibilityLabel?: string;
}

/** A round icon button — back arrows, overflow menus, the send key. */
export function AppIconButton({
  icon,
  onPress,
  size = 42,
  iconSize = 20,
  background,
  foreground,
  bordered = true,
  accessibilityLabel,
}: AppIconButtonProps) {
  const { colors } = useTheme();

  return (
    <PressEffect onPress={onPress} scale={0.9} accessibilityLabel={accessibilityLabel}>
      <View
        style={[
          styles.iconButton,
          {
            height: size,
            width: size,
            borderRadius: size / 2,
            backgroundColor: background ?? colors.surface,
          },
          bordered ? { borderWidth: 1, borderColor: colors.border } : null,
        ]}
      >
        <MaterialIcons name={icon} size={iconSize} color={foreground ?? colors.ink} />
      </View>
    </PressEffect>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: AppRadii.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 1,
  },
  leadingIcon: { marginRight: AppSpacing.sm },
  trailingIcon: { marginLeft: AppSpacing.sm },
  iconButton: { alignItems: 'center', justifyContent: 'center' },
});
