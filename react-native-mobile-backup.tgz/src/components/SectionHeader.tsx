import React from 'react';
import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import { AppSpacing, useTheme } from '../theme';
import { PressEffect } from './PressEffect';

interface SectionHeaderProps {
  title: string;
  eyebrow?: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: (() => void) | null;
  style?: StyleProp<ViewStyle>;
}

/**
 * The rhythm of every scrolling screen: an eyebrow, a title, an optional
 * action. Consistent vertical spacing here is most of what makes the app feel
 * like one product rather than a pile of screens.
 */
export function SectionHeader({
  title,
  eyebrow,
  subtitle,
  actionLabel,
  onAction,
  style,
}: SectionHeaderProps) {
  const { colors, type } = useTheme();

  return (
    <View style={[styles.container, style]}>
      <View style={styles.body}>
        {eyebrow ? (
          <Text style={[type.overline, { color: colors.inkFaint, marginBottom: AppSpacing.sm }]}>
            {eyebrow}
          </Text>
        ) : null}
        <Text style={type.title}>{title}</Text>
        {subtitle ? (
          <Text style={[type.bodySmall, { color: colors.inkMuted, marginTop: AppSpacing.xs }]}>
            {subtitle}
          </Text>
        ) : null}
      </View>

      {actionLabel && onAction ? (
        <PressEffect onPress={onAction} scale={0.94}>
          <View style={styles.action}>
            <Text style={[type.label, { color: colors.primary }]}>{actionLabel}</Text>
            <MaterialIcons name="chevron-right" size={18} color={colors.primary} />
          </View>
        </PressEffect>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xxxl,
    paddingBottom: AppSpacing.lg,
  },
  body: { flex: 1 },
  action: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: AppSpacing.md,
    marginBottom: 2,
  },
});
