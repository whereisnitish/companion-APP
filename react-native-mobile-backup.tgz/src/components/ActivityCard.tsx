import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import { Format } from '../core/utils/formatters';
import type { Activity } from '../models/activity';
import { categoryForeground, isVerified } from '../models/enums';
import { firstName } from '../models/profile';
import { AppRadii, AppSpacing, useTheme, withAlpha } from '../theme';
import { AppAvatar } from './AppAvatar';
import { AppButton } from './AppButton';
import { CategoryBadge, StatusPill, VerifiedBadge } from './AppChip';
import { PressEffect } from './PressEffect';

/**
 * A posted plan.
 *
 * The when is the loudest thing on the card — it is what decides whether the
 * plan is relevant at all — followed by what it is, then who is hosting.
 */
export function ActivityCard({
  activity,
  onPress,
  onInvite,
  showHost = true,
}: {
  activity: Activity;
  onPress?: () => void;
  onInvite?: () => void;
  showHost?: boolean;
}) {
  const { colors, type, shadows, isDark } = useTheme();

  const hue = categoryForeground(activity.category, isDark);
  const alreadyInvited = activity.viewerInvitationStatus !== null;

  const place = [
    activity.locationName,
    activity.distanceKm !== null ? Format.distanceShort(activity.distanceKm) : null,
  ]
    .filter((part): part is string => !!part && part.length > 0)
    .join(' · ');

  return (
    <PressEffect onPress={onPress} scale={0.99}>
      <View
        style={[
          styles.card,
          { backgroundColor: colors.surface, borderColor: colors.border },
          shadows.resting,
        ]}
      >
        <View style={styles.head}>
          <CategoryBadge category={activity.category} />
          <View style={styles.headBody}>
            <Text style={[type.overline, { color: hue }]}>
              {Format.whenLabel(activity.startsAt).toUpperCase()}
            </Text>
            <Text numberOfLines={2} style={[type.subtitle, styles.title]}>
              {activity.title}
            </Text>
            <View style={styles.placeRow}>
              <MaterialIcons name="place" size={13} color={colors.inkFaint} />
              <Text
                numberOfLines={1}
                style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.xs + 1, flex: 1 }]}
              >
                {place}
              </Text>
            </View>
          </View>
        </View>

        {activity.description.length > 0 ? (
          <Text
            numberOfLines={2}
            style={[type.bodySmall, styles.description, { color: colors.inkMuted }]}
          >
            {activity.description}
          </Text>
        ) : null}

        {showHost ? (
          <View
            style={[
              styles.hostBar,
              {
                backgroundColor: withAlpha(colors.surfaceSunken, 0.6),
                borderTopColor: colors.border,
              },
            ]}
          >
            <AppAvatar
              name={activity.host.displayName}
              imageUrl={activity.host.avatarUrl}
              size={30}
              isOnline={activity.host.isOnline}
              showPresence={activity.host.isOnline}
            />
            <View style={styles.hostName}>
              <Text numberOfLines={1} style={type.label}>
                {activity.isHost ? 'You' : firstName(activity.host)}
              </Text>
              {isVerified(activity.host.verification) ? (
                <View style={{ marginLeft: AppSpacing.xs }}>
                  <VerifiedBadge size={13} status={activity.host.verification} />
                </View>
              ) : null}
              {activity.host.age !== null ? (
                <Text
                  style={[type.caption, { color: colors.inkFaint, marginLeft: AppSpacing.sm }]}
                >
                  {activity.host.age}
                </Text>
              ) : null}
            </View>

            {activity.isHost ? (
              <Text style={[type.caption, { color: colors.inkFaint }]}>Your plan</Text>
            ) : alreadyInvited && activity.viewerInvitationStatus ? (
              <StatusPill status={activity.viewerInvitationStatus} />
            ) : (
              <AppButton label="Join" size="small" expand={false} onPress={onInvite} />
            )}
          </View>
        ) : null}
      </View>
    </PressEffect>
  );
}

/** The compact activity tile used in Home's "Happening tonight" rail. */
export function ActivityPreviewCard({
  activity,
  onPress,
  width = 260,
}: {
  activity: Activity;
  onPress?: () => void;
  width?: number;
}) {
  const { colors, type, shadows, isDark } = useTheme();
  const hue = categoryForeground(activity.category, isDark);

  return (
    <PressEffect onPress={onPress} scale={0.98}>
      <View
        style={[
          styles.previewCard,
          { width, backgroundColor: colors.surface, borderColor: colors.border },
          shadows.resting,
        ]}
      >
        <View style={styles.previewHead}>
          <CategoryBadge category={activity.category} size={32} radius={10} />
          <Text
            numberOfLines={1}
            style={[type.overline, { color: hue, marginLeft: AppSpacing.md, flex: 1 }]}
          >
            {Format.whenShort(activity.startsAt).toUpperCase()}
          </Text>
        </View>

        <View style={{ height: 44, marginTop: AppSpacing.md }}>
          <Text numberOfLines={2} style={[type.bodyStrong, { lineHeight: 21 }]}>
            {activity.title}
          </Text>
        </View>

        <View style={[styles.previewFooter, { marginTop: AppSpacing.sm }]}>
          <AppAvatar
            name={activity.host.displayName}
            imageUrl={activity.host.avatarUrl}
            size={22}
          />
          <Text
            numberOfLines={1}
            style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.sm, flex: 1 }]}
          >
            {activity.isHost ? 'Your plan' : firstName(activity.host)}
          </Text>
          {activity.distanceKm !== null ? (
            <Text style={[type.caption, { color: colors.inkFaint }]}>
              {Format.distanceShort(activity.distanceKm)}
            </Text>
          ) : null}
        </View>
      </View>
    </PressEffect>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: AppRadii.lg, borderWidth: 1, overflow: 'hidden' },
  head: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.lg,
    paddingTop: AppSpacing.lg,
    paddingBottom: AppSpacing.md,
  },
  headBody: { flex: 1, marginLeft: AppSpacing.lg },
  title: { lineHeight: 23, marginTop: AppSpacing.xs + 2 },
  placeRow: { flexDirection: 'row', alignItems: 'center', marginTop: AppSpacing.sm },
  description: {
    paddingHorizontal: AppSpacing.lg,
    paddingBottom: AppSpacing.md,
    lineHeight: 20,
  },
  hostBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
    borderTopWidth: 1,
  },
  hostName: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: AppSpacing.md,
    marginRight: AppSpacing.md,
  },
  previewCard: { borderRadius: AppRadii.lg, borderWidth: 1, padding: AppSpacing.lg },
  previewHead: { flexDirection: 'row', alignItems: 'center' },
  previewFooter: { flexDirection: 'row', alignItems: 'center' },
});
