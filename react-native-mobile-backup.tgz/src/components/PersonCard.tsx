import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';

import { Format } from '../core/utils/formatters';
import {
  availabilityLabel,
  categoryForeground,
  categoryMeta,
  categoryTint,
  isVerified,
} from '../models/enums';
import { gallery, type Profile } from '../models/profile';
import { AppMotion, AppRadii, AppSpacing, useTheme } from '../theme';
import { AppAvatar } from './AppAvatar';
import { AppButton, AppIconButton } from './AppButton';
import { CategoryChip } from './AppChip';
import { PressEffect } from './PressEffect';

/**
 * The full-width person card used in Discover.
 *
 * Reading order is deliberate: face, then who they are, then what they are up
 * for, then when — and only then the invite button. Someone should be able to
 * decide from the card alone, which is why the bio is here and not hidden
 * behind a tap.
 */
export function PersonCard({
  profile,
  onPress,
  onInvite,
  aspectRatio = 4 / 5,
}: {
  profile: Profile;
  onPress?: () => void;
  onInvite?: () => void;
  aspectRatio?: number;
}) {
  const { colors, type, shadows, isDark } = useTheme();

  return (
    <PressEffect onPress={onPress} scale={0.99}>
      <View
        style={[
          styles.card,
          { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: AppRadii.xl },
          shadows.resting,
        ]}
      >
        <View style={{ aspectRatio }}>
          <PhotoHeader profile={profile} />
        </View>

        <View style={styles.cardBody}>
          {profile.bio.length > 0 ? (
            <Text
              numberOfLines={2}
              style={[type.body, { color: colors.inkMuted, lineHeight: 22, marginBottom: AppSpacing.lg }]}
            >
              {profile.bio}
            </Text>
          ) : null}

          {profile.preferredActivities.length > 0 ? (
            <>
              <Text style={[type.overline, { color: colors.inkFaint }]}>UP FOR</Text>
              <View style={styles.chipWrap}>
                {profile.preferredActivities.slice(0, 4).map((category) => (
                  <View key={category} style={styles.chipItem}>
                    <CategoryChip category={category} selected dense />
                  </View>
                ))}
              </View>
            </>
          ) : null}

          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.footerRow}>
            <View style={styles.footerBody}>
              <AvailabilityLine profile={profile} />
            </View>
            <AppButton
              label="Invite"
              size="small"
              expand={false}
              icon="send"
              onPress={onInvite}
            />
          </View>
        </View>
      </View>
    </PressEffect>
  );
}

/**
 * Photo, scrim, and the identity line — shared by the card and the profile
 * screen's header so a name never sits differently in two places.
 */
export function PhotoHeader({ profile }: { profile: Profile }) {
  const { colors, type } = useTheme();
  const [failed, setFailed] = useState(false);

  const photos = gallery(profile);
  const photo = photos.length > 0 ? photos[0] : null;

  const identity = [
    profile.age !== null ? `${profile.age}` : null,
    profile.area && profile.area.length > 0 ? profile.area : null,
    profile.occupation && profile.occupation.length > 0 ? profile.occupation : null,
  ]
    .filter((part): part is string => part !== null)
    .join(' · ');

  return (
    <View style={StyleSheet.absoluteFill}>
      {photo && !failed ? (
        <Image
          source={{ uri: photo }}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          transition={AppMotion.base}
          placeholderContentFit="cover"
          onError={() => setFailed(true)}
        />
      ) : (
        <View
          style={[StyleSheet.absoluteFill, styles.center, { backgroundColor: colors.surfaceSunken }]}
        >
          <AppAvatar name={profile.displayName} size={92} />
        </View>
      )}

      {/* A scrim only where the text sits, so the photo stays a photo. */}
      <LinearGradient
        colors={['transparent', 'rgba(0, 0, 0, 0.7)']}
        style={styles.scrim}
        start={{ x: 0.5, y: 0.5 }}
        end={{ x: 0.5, y: 1 }}
      />

      {profile.isOnline ? (
        <View style={[styles.pillTopLeft]}>
          <GlassPill>
            <View style={styles.onlineDot} />
            <Text style={[type.caption, styles.glassText]}>Active now</Text>
          </GlassPill>
        </View>
      ) : null}

      {profile.distanceKm !== null ? (
        <View style={[styles.pillTopRight]}>
          <GlassPill>
            <Text style={[type.caption, styles.glassText]}>
              {Format.distanceShort(profile.distanceKm)}
            </Text>
          </GlassPill>
        </View>
      ) : null}

      <View style={styles.identity}>
        <View style={styles.nameRow}>
          <Text numberOfLines={1} style={[type.serifTitle, styles.nameText]}>
            {profile.displayName}
          </Text>
          {isVerified(profile.verification) ? (
            <MaterialIcons name="verified" size={17} color="#FFFFFF" style={styles.verified} />
          ) : null}
        </View>
        {identity.length > 0 ? (
          <Text numberOfLines={1} style={[type.bodySmall, styles.identityText]}>
            {identity}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

function GlassPill({ children }: { children: React.ReactNode }) {
  return <View style={styles.glassPill}>{children}</View>;
}

function AvailabilityLine({ profile }: { profile: Profile }) {
  const { colors, type } = useTheme();

  if (profile.availability.length === 0) {
    return (
      <Text style={[type.caption, { color: colors.inkFaint }]}>
        {Format.lastSeen(profile.lastActiveAt, profile.isOnline)}
      </Text>
    );
  }

  const slots = profile.availability
    .map((slot) => availabilityLabel(slot).toLowerCase())
    .join(' · ');

  return (
    <View style={styles.availabilityRow}>
      <MaterialIcons name="schedule" size={14} color={colors.inkFaint} />
      <Text
        numberOfLines={1}
        style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.sm, flex: 1 }]}
      >
        {`Free ${slots}`}
      </Text>
    </View>
  );
}

/** The narrow card used in Home's horizontal rails. */
export function PersonPreviewCard({
  profile,
  onPress,
  onInvite,
  width = 232,
}: {
  profile: Profile;
  onPress?: () => void;
  onInvite?: () => void;
  width?: number;
}) {
  const { colors, type, shadows, isDark } = useTheme();

  return (
    <PressEffect onPress={onPress} scale={0.98}>
      <View
        style={[
          styles.card,
          {
            width,
            backgroundColor: colors.surface,
            borderColor: colors.border,
            borderRadius: AppRadii.lg,
          },
          shadows.resting,
        ]}
      >
        <View style={{ height: width * 0.92 }}>
          <PhotoHeader profile={profile} />
        </View>

        <View style={{ padding: AppSpacing.lg }}>
          <View style={{ height: 36 }}>
            <Text
              numberOfLines={2}
              style={[type.bodySmall, { color: colors.inkMuted, lineHeight: 18 }]}
            >
              {profile.bio.length === 0 ? 'Up for something soon.' : profile.bio}
            </Text>
          </View>

          <View style={[styles.previewFooter, { marginTop: AppSpacing.md }]}>
            {profile.preferredActivities.slice(0, 3).map((category) => (
              <View
                key={category}
                style={[
                  styles.miniBadge,
                  { backgroundColor: categoryTint(category, isDark) },
                ]}
              >
                <MaterialIcons
                  name={categoryMeta(category).icon}
                  size={14}
                  color={categoryForeground(category, isDark)}
                />
              </View>
            ))}
            <View style={styles.spacer} />
            <AppIconButton
              icon="send"
              size={32}
              iconSize={15}
              background={colors.primary}
              foreground={colors.onPrimary}
              bordered={false}
              onPress={onInvite}
              accessibilityLabel={`Invite ${profile.displayName}`}
            />
          </View>
        </View>
      </View>
    </PressEffect>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, overflow: 'hidden' },
  cardBody: {
    paddingHorizontal: AppSpacing.xl,
    paddingVertical: AppSpacing.lg,
  },
  center: { alignItems: 'center', justifyContent: 'center' },
  scrim: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 },
  chipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: AppSpacing.sm,
    marginBottom: AppSpacing.lg - AppSpacing.sm,
  },
  chipItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  divider: { height: 1 },
  footerRow: { flexDirection: 'row', alignItems: 'center', marginTop: AppSpacing.lg },
  footerBody: { flex: 1, marginRight: AppSpacing.md },
  availabilityRow: { flexDirection: 'row', alignItems: 'center' },
  pillTopLeft: { position: 'absolute', top: AppSpacing.lg, left: AppSpacing.lg },
  pillTopRight: { position: 'absolute', top: AppSpacing.lg, right: AppSpacing.lg },
  glassPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.md,
    paddingVertical: 5,
    borderRadius: AppRadii.pill,
    backgroundColor: 'rgba(0, 0, 0, 0.34)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.16)',
  },
  glassText: { color: '#FFFFFF', fontWeight: '600' },
  onlineDot: {
    height: 6,
    width: 6,
    borderRadius: 3,
    backgroundColor: '#5DD39E',
    marginRight: AppSpacing.sm,
  },
  identity: {
    position: 'absolute',
    left: AppSpacing.xl,
    right: AppSpacing.xl,
    bottom: AppSpacing.xl,
  },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  nameText: { color: '#FFFFFF', flexShrink: 1 },
  verified: { marginLeft: AppSpacing.sm },
  identityText: { color: 'rgba(255, 255, 255, 0.82)', marginTop: 2 },
  previewFooter: { flexDirection: 'row', alignItems: 'center' },
  miniBadge: {
    height: 26,
    width: 26,
    borderRadius: AppRadii.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: AppSpacing.xs + 2,
  },
  spacer: { flex: 1 },
});
