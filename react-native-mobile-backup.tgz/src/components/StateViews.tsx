import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import { ApiException } from '../core/network/apiException';
import type { MaterialIconName } from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';
import { AppButton } from './AppButton';

export type StateTone = 'neutral' | 'warning' | 'danger';

interface StateViewProps {
  icon: MaterialIconName;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: (() => void) | null;
  compact?: boolean;
  tone?: StateTone;
}

/**
 * Nothing here is ever a blank screen.
 *
 * Empty, error and offline states all get the same treatment: a quiet mark, a
 * sentence that says what happened in plain words, and exactly one way forward.
 */
export function StateView({
  icon,
  title,
  message,
  actionLabel,
  onAction,
  compact = false,
  tone = 'neutral',
}: StateViewProps) {
  const { colors, type } = useTheme();

  const palette: Record<StateTone, { tint: string; mark: string }> = {
    neutral: { tint: colors.surfaceSunken, mark: colors.inkMuted },
    warning: { tint: colors.accentSoft, mark: colors.accent },
    danger: { tint: colors.dangerSoft, mark: colors.danger },
  };
  const { tint, mark } = palette[tone];
  const markSize = compact ? 52 : 64;

  return (
    <View
      style={[
        styles.container,
        { paddingVertical: compact ? AppSpacing.xxl : AppSpacing.giant },
      ]}
    >
      <View
        style={[
          styles.mark,
          { height: markSize, width: markSize, borderRadius: markSize / 2, backgroundColor: tint },
        ]}
      >
        <MaterialIcons name={icon} size={compact ? 24 : 28} color={mark} />
      </View>

      <Text
        style={[type.subtitle, styles.centered, { marginTop: compact ? AppSpacing.lg : AppSpacing.xl }]}
      >
        {title}
      </Text>
      <Text style={[type.body, styles.centered, { color: colors.inkMuted, marginTop: AppSpacing.sm }]}>
        {message}
      </Text>

      {actionLabel && onAction ? (
        <View style={{ marginTop: AppSpacing.xxl }}>
          <AppButton
            label={actionLabel}
            onPress={onAction}
            variant="secondary"
            size="medium"
            expand={false}
          />
        </View>
      ) : null}
    </View>
  );
}

/** Turns any thrown object into a state a person can act on. */
export function errorStateProps(error: unknown, onRetry?: () => void): StateViewProps {
  if (error instanceof ApiException) {
    if (error.isNetworkError) {
      return {
        icon: 'wifi-off',
        title: 'No connection',
        message: 'We could not reach Companion. Check your network and try again.',
        actionLabel: onRetry ? 'Try again' : undefined,
        onAction: onRetry,
        tone: 'warning',
      };
    }
    return {
      icon: 'error-outline',
      title: 'Something went wrong',
      message: error.message,
      actionLabel: onRetry ? 'Try again' : undefined,
      onAction: onRetry,
      tone: 'danger',
    };
  }

  return {
    icon: 'error-outline',
    title: 'Something went wrong',
    message: 'An unexpected error occurred. Please try again.',
    actionLabel: onRetry ? 'Try again' : undefined,
    onAction: onRetry,
    tone: 'danger',
  };
}

export function ErrorStateView({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return <StateView {...errorStateProps(error, onRetry)} />;
}

/** A slim inline error for the top of a list that already has content. */
export function InlineError({ message, onRetry }: { message: string; onRetry?: () => void }) {
  const { colors, type } = useTheme();

  return (
    <View style={[styles.inline, { backgroundColor: colors.dangerSoft }]}>
      <MaterialIcons name="error-outline" size={18} color={colors.danger} />
      <Text style={[type.bodySmall, styles.inlineText, { color: colors.danger }]}>{message}</Text>
      {onRetry ? (
        <AppButton label="Retry" variant="ghost" size="small" expand={false} onPress={onRetry} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: AppSpacing.xxxl,
  },
  mark: { alignItems: 'center', justifyContent: 'center' },
  centered: { textAlign: 'center' },
  inline: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: AppSpacing.screenX,
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
    borderRadius: AppRadii.md,
  },
  inlineText: { flex: 1, marginLeft: AppSpacing.md },
});
