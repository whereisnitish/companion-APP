import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';

import { Format } from '../core/utils/formatters';
import { AppMotion, useTheme, withAlpha } from '../theme';

const PALETTE = [
  '#4B5BA6',
  '#2F7A5E',
  '#C0603A',
  '#8C4A70',
  '#2B7683',
  '#6A4FA3',
  '#B0821F',
  '#5E7A2A',
] as const;

/** Deterministic, so the same person always gets the same colour. */
function fallbackHue(name: string): string {
  if (name.length === 0) return PALETTE[0];
  let hash = 0;
  for (let index = 0; index < name.length; index += 1) {
    hash = (hash * 31 + name.charCodeAt(index)) & 0x7fffffff;
  }
  return PALETTE[hash % PALETTE.length] as string;
}

/** Lightens a hex colour to the given HSL lightness, keeping hue and saturation. */
function lighten(hex: string, lightness: number): string {
  const value = hex.replace('#', '');
  const r = parseInt(value.slice(0, 2), 16) / 255;
  const g = parseInt(value.slice(2, 4), 16) / 255;
  const b = parseInt(value.slice(4, 6), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  const d = max - min;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));

  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }

  const c = (1 - Math.abs(2 * lightness - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = lightness - c / 2;

  let rgb: [number, number, number];
  if (h < 60) rgb = [c, x, 0];
  else if (h < 120) rgb = [x, c, 0];
  else if (h < 180) rgb = [0, c, x];
  else if (h < 240) rgb = [0, x, c];
  else if (h < 300) rgb = [x, 0, c];
  else rgb = [c, 0, x];

  const toHex = (v: number) =>
    Math.round((v + m) * 255)
      .toString(16)
      .padStart(2, '0');
  return `#${toHex(rgb[0])}${toHex(rgb[1])}${toHex(rgb[2])}`;
}

interface AppAvatarProps {
  name: string;
  imageUrl?: string | null;
  size?: number;
  isOnline?: boolean;
  showPresence?: boolean;
  ring?: string;
}

/**
 * An avatar that never looks broken.
 *
 * If the photo is missing or the network is down we fall back to initials on a
 * tint derived from the name — deterministic, so the same person always gets
 * the same colour. Empty grey circles are what make demo apps look unfinished.
 */
export function AppAvatar({
  name,
  imageUrl,
  size = 48,
  isOnline = false,
  showPresence = false,
  ring,
}: AppAvatarProps) {
  const { colors, type, isDark } = useTheme();
  const [failed, setFailed] = useState(false);

  const hue = fallbackHue(name);
  const showImage = !!imageUrl && imageUrl.length > 0 && !failed;

  const placeholder = (
    <View
      style={[
        styles.fill,
        styles.center,
        { backgroundColor: withAlpha(hue, isDark ? 0.28 : 0.14) },
      ]}
    >
      <Text
        style={[
          type.bodyStrong,
          { fontSize: size * 0.34, lineHeight: size * 0.44, color: isDark ? lighten(hue, 0.72) : hue },
        ]}
      >
        {Format.initials(name)}
      </Text>
    </View>
  );

  const avatar = (
    <View
      style={{
        height: size,
        width: size,
        borderRadius: size / 2,
        borderWidth: ring ? 2 : 1,
        borderColor: ring ?? colors.border,
        overflow: 'hidden',
      }}
    >
      {showImage ? (
        <Image
          source={{ uri: imageUrl }}
          style={styles.fill}
          contentFit="cover"
          transition={AppMotion.base}
          onError={() => setFailed(true)}
        />
      ) : (
        placeholder
      )}
    </View>
  );

  if (!showPresence) return avatar;

  const dotSize = Math.max(size * 0.26, 10);

  return (
    <View>
      {avatar}
      <View
        style={{
          position: 'absolute',
          right: 0,
          bottom: 0,
          height: dotSize,
          width: dotSize,
          borderRadius: dotSize / 2,
          backgroundColor: isOnline ? colors.success : colors.inkFaint,
          borderWidth: 2,
          borderColor: colors.surface,
        }}
      />
    </View>
  );
}

export interface AvatarEntry {
  name: string;
  imageUrl?: string | null;
}

interface AvatarStackProps {
  entries: AvatarEntry[];
  size?: number;
  maxVisible?: number;
}

/** Overlapping avatars for "3 people are in". */
export function AvatarStack({ entries, size = 28, maxVisible = 3 }: AvatarStackProps) {
  const { colors, type } = useTheme();

  const visible = entries.slice(0, maxVisible);
  const overflow = entries.length - visible.length;
  const overlap = size * 0.32;
  const step = size - overlap;

  if (visible.length === 0) return null;

  const width = size + (visible.length - 1) * step + (overflow > 0 ? step : 0);

  return (
    <View style={{ height: size, width }}>
      {visible.map((entry, index) => (
        <View key={`${entry.name}-${index}`} style={{ position: 'absolute', left: index * step }}>
          <AppAvatar
            name={entry.name}
            imageUrl={entry.imageUrl}
            size={size}
            ring={colors.surface}
          />
        </View>
      ))}
      {overflow > 0 ? (
        <View
          style={[
            styles.center,
            {
              position: 'absolute',
              left: visible.length * step,
              height: size,
              width: size,
              borderRadius: size / 2,
              backgroundColor: colors.surfaceSunken,
              borderWidth: 2,
              borderColor: colors.surface,
            },
          ]}
        >
          <Text
            style={[
              type.caption,
              { color: colors.inkMuted, fontSize: size * 0.32, lineHeight: size * 0.42 },
            ]}
          >
            {`+${overflow}`}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { width: '100%', height: '100%' },
  center: { alignItems: 'center', justifyContent: 'center' },
});
