import React, { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeInDown, FadeOutDown } from 'react-native-reanimated';

import type { MaterialIconName } from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';

export type SnackTone = 'neutral' | 'success' | 'danger';

interface SnackOptions {
  tone?: SnackTone;
  icon?: MaterialIconName;
  duration?: number;
}

interface Snack {
  id: number;
  message: string;
  tone: SnackTone;
  icon?: MaterialIconName;
}

interface SnackbarApi {
  show: (message: string, options?: SnackOptions) => void;
  success: (message: string) => void;
  error: (message: string) => void;
}

const SnackbarContext = createContext<SnackbarApi | null>(null);

/**
 * One-line feedback. Floating, inked, and short — anything that needs more
 * than a sentence belongs in a sheet, not here.
 *
 * Flutter routed this through `ScaffoldMessenger`; React Native has no
 * equivalent, so the host lives once at the root and hands out an imperative
 * API through context.
 */
export function SnackbarProvider({ children }: { children: ReactNode }) {
  const [snack, setSnack] = useState<Snack | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const nextId = useRef(0);

  const show = useCallback((message: string, options?: SnackOptions) => {
    if (timer.current) clearTimeout(timer.current);
    nextId.current += 1;
    setSnack({
      id: nextId.current,
      message,
      tone: options?.tone ?? 'neutral',
      icon: options?.icon,
    });
    timer.current = setTimeout(() => setSnack(null), options?.duration ?? 3000);
  }, []);

  const api = useMemo<SnackbarApi>(
    () => ({
      show,
      success: (message: string) => show(message, { tone: 'success' }),
      error: (message: string) => show(message, { tone: 'danger' }),
    }),
    [show],
  );

  return (
    <SnackbarContext.Provider value={api}>
      {children}
      <SnackbarHost snack={snack} />
    </SnackbarContext.Provider>
  );
}

function SnackbarHost({ snack }: { snack: Snack | null }) {
  const { colors, type } = useTheme();
  const insets = useSafeAreaInsets();

  if (!snack) return null;

  const palette: Record<SnackTone, { background: string; foreground: string; icon: MaterialIconName }> =
    {
      neutral: { background: colors.ink, foreground: colors.inkInverse, icon: 'info-outline' },
      success: { background: colors.success, foreground: '#FFFFFF', icon: 'check' },
      danger: { background: colors.danger, foreground: '#FFFFFF', icon: 'error-outline' },
    };

  const { background, foreground, icon } = palette[snack.tone];

  return (
    <Animated.View
      key={snack.id}
      entering={FadeInDown.duration(220)}
      exiting={FadeOutDown.duration(180)}
      pointerEvents="none"
      style={[styles.host, { bottom: insets.bottom + AppSpacing.lg }]}
    >
      <View style={[styles.snack, { backgroundColor: background }]}>
        <MaterialIcons name={snack.icon ?? icon} size={18} color={foreground} />
        <Text style={[type.bodySmall, styles.text, { color: foreground }]}>{snack.message}</Text>
      </View>
    </Animated.View>
  );
}

/** `const snackbar = useSnackbar(); snackbar.success('Invitation sent')`. */
export function useSnackbar(): SnackbarApi {
  const api = useContext(SnackbarContext);
  if (!api) throw new Error('useSnackbar must be used inside a SnackbarProvider');
  return api;
}

const styles = StyleSheet.create({
  host: { position: 'absolute', left: AppSpacing.lg, right: AppSpacing.lg },
  snack: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: AppRadii.md,
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
  },
  text: { flex: 1, marginLeft: AppSpacing.md },
});
