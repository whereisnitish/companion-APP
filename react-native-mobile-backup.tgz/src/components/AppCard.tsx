import React, { type ReactNode } from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';

import { AppRadii, AppSpacing, useTheme } from '../theme';
import { PressEffect } from './PressEffect';

interface AppCardProps {
  children: ReactNode;
  onPress?: (() => void) | null;
  padding?: number | ViewStyle;
  radius?: number;
  color?: string;
  borderColor?: string;
  elevated?: boolean;
  style?: StyleProp<ViewStyle>;
}

/**
 * The surface every piece of content sits on: hairline border, a shadow you
 * have to look for, generous radius. Depth comes from the border, not the blur.
 */
export function AppCard({
  children,
  onPress,
  padding = AppSpacing.lg,
  radius = AppRadii.lg,
  color,
  borderColor,
  elevated = true,
  style,
}: AppCardProps) {
  const { colors, shadows } = useTheme();

  const paddingStyle: ViewStyle =
    typeof padding === 'number' ? { padding } : padding;

  return (
    <PressEffect onPress={onPress} scale={0.985} style={style}>
      <View
        style={[
          {
            backgroundColor: color ?? colors.surface,
            borderRadius: radius,
            borderWidth: 1,
            borderColor: borderColor ?? colors.border,
            overflow: 'hidden',
          },
          elevated ? shadows.resting : null,
          paddingStyle,
        ]}
      >
        {children}
      </View>
    </PressEffect>
  );
}

interface AppTileProps {
  children: ReactNode;
  onPress?: (() => void) | null;
  style?: StyleProp<ViewStyle>;
}

/** A flat, borderless grouping used inside sheets and settings lists. */
export function AppTile({ children, onPress, style }: AppTileProps) {
  return (
    <PressEffect onPress={onPress} scale={0.99}>
      <View
        style={[
          { paddingHorizontal: AppSpacing.lg, paddingVertical: AppSpacing.md },
          style,
        ]}
      >
        {children}
      </View>
    </PressEffect>
  );
}
