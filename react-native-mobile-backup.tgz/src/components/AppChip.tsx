import React, { type ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import {
  categoryForeground,
  categoryMeta,
  categoryTint,
  invitationStatusLabel,
  isVerified,
  type ActivityCategory,
  type InvitationStatus,
  type MaterialIconName,
  type VerificationStatus,
} from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';
import { PressEffect } from './PressEffect';

interface AppChipProps {
  label: string;
  icon?: MaterialIconName;
  leading?: ReactNode;
  selected?: boolean;
  onPress?: (() => void) | null;
  tint?: string;
  foreground?: string;
  dense?: boolean;
}

/**
 * A pill. Selectable or static, tinted or neutral — used for interests,
 * filters, availability and status throughout.
 */
export function AppChip({
  label,
  icon,
  leading,
  selected = false,
  onPress,
  tint,
  foreground,
  dense = false,
}: AppChipProps) {
  const { colors, type } = useTheme();

  const background = selected ? tint ?? colors.ink : tint ?? 'transparent';
  const textColor = selected
    ? foreground ?? (tint ? colors.ink : colors.inkInverse)
    : foreground ?? colors.inkMuted;
  const borderColor = selected ? (tint ? 'transparent' : colors.ink) : colors.border;

  return (
    <PressEffect onPress={onPress} scale={0.95}>
      <View
        style={[
          styles.chip,
          {
            paddingHorizontal: dense ? AppSpacing.md : AppSpacing.lg - 2,
            paddingVertical: dense ? 6 : AppSpacing.sm + 1,
            backgroundColor: background,
            borderColor,
          },
        ]}
      >
        {leading ? (
          <View style={styles.leading}>{leading}</View>
        ) : icon ? (
          <MaterialIcons
            name={icon}
            size={dense ? 13 : 15}
            color={textColor}
            style={styles.leading}
          />
        ) : null}
        <Text style={[dense ? type.caption : type.label, styles.chipText, { color: textColor }]}>
          {label}
        </Text>
      </View>
    </PressEffect>
  );
}

interface CategoryChipProps {
  category: ActivityCategory;
  selected?: boolean;
  onPress?: (() => void) | null;
  dense?: boolean;
  showIcon?: boolean;
}

/**
 * A category chip carrying its own hue — the fastest way to read "this is a
 * movie plan" without reading at all.
 */
export function CategoryChip({
  category,
  selected = false,
  onPress,
  dense = false,
  showIcon = true,
}: CategoryChipProps) {
  const { isDark } = useTheme();
  const meta = categoryMeta(category);

  return (
    <AppChip
      label={meta.label}
      icon={showIcon ? meta.icon : undefined}
      selected={selected}
      onPress={onPress}
      dense={dense}
      tint={selected ? categoryTint(category, isDark) : undefined}
      foreground={selected ? categoryForeground(category, isDark) : undefined}
    />
  );
}

interface CategoryBadgeProps {
  category: ActivityCategory;
  size?: number;
  radius?: number;
}

/** A small square badge holding a category icon — used as list leading art. */
export function CategoryBadge({ category, size = 44, radius = 14 }: CategoryBadgeProps) {
  const { isDark } = useTheme();
  const meta = categoryMeta(category);

  return (
    <View
      style={[
        styles.center,
        {
          height: size,
          width: size,
          borderRadius: radius,
          backgroundColor: categoryTint(category, isDark),
        },
      ]}
    >
      <MaterialIcons
        name={meta.icon}
        size={size * 0.46}
        color={categoryForeground(category, isDark)}
      />
    </View>
  );
}

/** A status pill for invitations — the colour is the message. */
export function StatusPill({ status }: { status: InvitationStatus }) {
  const { colors, type } = useTheme();

  const palette: Record<InvitationStatus, { background: string; foreground: string }> = {
    PENDING: { background: colors.surfaceSunken, foreground: colors.inkMuted },
    ACCEPTED: { background: colors.successSoft, foreground: colors.success },
    DECLINED: { background: colors.dangerSoft, foreground: colors.danger },
    CANCELLED: { background: colors.surfaceSunken, foreground: colors.inkFaint },
    EXPIRED: { background: colors.surfaceSunken, foreground: colors.inkFaint },
  };

  const { background, foreground } = palette[status];

  return (
    <View style={[styles.statusPill, { backgroundColor: background }]}>
      <Text style={[type.caption, styles.chipText, { color: foreground }]}>
        {invitationStatusLabel(status)}
      </Text>
    </View>
  );
}

/**
 * The verification tick. A placeholder for a real identity check — the badge
 * and its plumbing exist so switching on the backend later is a data change.
 */
export function VerifiedBadge({
  size = 16,
  status = 'VERIFIED',
}: {
  size?: number;
  status?: VerificationStatus;
}) {
  const { colors } = useTheme();
  if (!isVerified(status)) return null;
  return <MaterialIcons name="verified" size={size} color={colors.primary} />;
}

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderRadius: AppRadii.pill,
    borderWidth: 1,
  },
  chipText: { fontWeight: '600' },
  leading: { marginRight: AppSpacing.xs + 2 },
  center: { alignItems: 'center', justifyContent: 'center' },
  statusPill: {
    alignSelf: 'flex-start',
    paddingHorizontal: AppSpacing.md,
    paddingVertical: 5,
    borderRadius: AppRadii.pill,
  },
});
