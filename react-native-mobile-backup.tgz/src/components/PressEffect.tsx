import React, { useCallback, type ReactNode } from 'react';
import { Pressable, type StyleProp, type ViewStyle } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

import { AppMotion } from '../theme';

interface PressEffectProps {
  children: ReactNode;
  onPress?: (() => void) | null;
  onLongPress?: (() => void) | null;
  scale?: number;
  enabled?: boolean;
  style?: StyleProp<ViewStyle>;
  hitSlop?: number;
  accessibilityLabel?: string;
}

/**
 * Touch feedback for the whole product: a 2% scale-down and a whisper of
 * opacity. Material's ink splash was disabled in the Flutter theme because a
 * ripple crossing a photo card looks cheap; this reads as physical instead.
 */
export function PressEffect({
  children,
  onPress,
  onLongPress,
  scale = 0.98,
  enabled = true,
  style,
  hitSlop,
  accessibilityLabel,
}: PressEffectProps) {
  const progress = useSharedValue(0);

  const interactive = enabled && (!!onPress || !!onLongPress);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: 1 - (1 - scale) * progress.value }],
    opacity: 1 - 0.06 * progress.value,
  }));

  const setPressed = useCallback(
    (pressed: boolean) => {
      if (!interactive) return;
      progress.value = withTiming(pressed ? 1 : 0, {
        duration: pressed ? AppMotion.instant : AppMotion.fast,
        easing: Easing.out(Easing.ease),
      });
    },
    [interactive, progress],
  );

  // With no handler we register nothing, so an inert wrapper never swallows a
  // tap meant for a button nested inside it.
  if (!interactive) {
    return <Animated.View style={style}>{children}</Animated.View>;
  }

  return (
    <Pressable
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onPress={enabled ? onPress ?? undefined : undefined}
      onLongPress={enabled ? onLongPress ?? undefined : undefined}
      hitSlop={hitSlop}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      style={style}
    >
      <Animated.View style={animatedStyle}>{children}</Animated.View>
    </Pressable>
  );
}
