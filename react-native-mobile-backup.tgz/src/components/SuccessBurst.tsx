import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  type SharedValue,
  Easing,
  runOnJS,
  useAnimatedProps,
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Circle, Path } from 'react-native-svg';

import { useTheme, withAlpha } from '../theme';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);
const AnimatedPath = Animated.createAnimatedComponent(Path);

interface SuccessBurstProps {
  size?: number;
  color?: string;
  onCompleted?: () => void;
}

const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max);

/** easeOutCubic, matching Curves.easeOutCubic in the Flutter original. */
function easeOutCubic(t: number): number {
  'worklet';
  return 1 - (1 - t) ** 3;
}

/**
 * The moment an invitation lands.
 *
 * A ring draws itself, a tick strokes on, and a few motes drift outward. It
 * runs once, for well under a second — celebration, not a cutscene.
 */
export function SuccessBurst({ size = 84, color, onCompleted }: SuccessBurstProps) {
  const { colors } = useTheme();
  const stroke = color ?? colors.primary;

  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withTiming(
      1,
      { duration: 900, easing: Easing.linear },
      (finished) => {
        if (finished && onCompleted) runOnJS(onCompleted)();
      },
    );
  }, [progress, onCompleted]);

  const centre = size / 2;
  const radius = size * 0.34;
  const circumference = 2 * Math.PI * radius;

  // The ring strokes on from the top.
  const ringProps = useAnimatedProps(() => {
    const ring = easeOutCubic(clamp(progress.value / 0.45, 0, 1));
    return { strokeDashoffset: circumference * (1 - ring) };
  });

  // The tick, drawn as two strokes revealed in sequence.
  const tickProps = useAnimatedProps(() => {
    const tick = easeOutCubic(clamp((progress.value - 0.32) / 0.38, 0, 1));
    if (tick <= 0) return { d: '' };

    const startX = centre - radius * 0.38;
    const startY = centre + radius * 0.02;
    const elbowX = centre - radius * 0.08;
    const elbowY = centre + radius * 0.34;
    const endX = centre + radius * 0.42;
    const endY = centre - radius * 0.3;

    if (tick <= 0.5) {
      const t = tick / 0.5;
      return {
        d: `M ${startX} ${startY} L ${startX + (elbowX - startX) * t} ${
          startY + (elbowY - startY) * t
        }`,
      };
    }
    const t = (tick - 0.5) / 0.5;
    return {
      d: `M ${startX} ${startY} L ${elbowX} ${elbowY} L ${elbowX + (endX - elbowX) * t} ${
        elbowY + (endY - elbowY) * t
      }`,
    };
  });

  // Soft halo.
  const haloProps = useAnimatedProps(() => {
    const motes = easeOutCubic(clamp((progress.value - 0.28) / 0.72, 0, 1));
    return { r: radius * (1 + 0.45 * motes), opacity: 0.12 * (1 - motes) };
  });

  return (
    <View style={{ height: size, width: size }}>
      <Svg width={size} height={size}>
        <AnimatedCircle cx={centre} cy={centre} fill={stroke} animatedProps={haloProps} />
        <AnimatedCircle
          cx={centre}
          cy={centre}
          r={radius}
          stroke={stroke}
          strokeWidth={2.6}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          // Start the sweep at 12 o'clock, as the Flutter arc did.
          transform={`rotate(-90 ${centre} ${centre})`}
          animatedProps={ringProps}
        />
        <AnimatedPath
          stroke={stroke}
          strokeWidth={3}
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
          animatedProps={tickProps}
        />
      </Svg>

      {/* Six motes drifting out and fading. */}
      {Array.from({ length: 6 }, (_, index) => (
        <Mote key={index} index={index} progress={progress} centre={centre} radius={radius} color={stroke} />
      ))}
    </View>
  );
}

function Mote({
  index,
  progress,
  centre,
  radius,
  color,
}: {
  index: number;
  progress: SharedValue<number>;
  centre: number;
  radius: number;
  color: string;
}) {
  const angle = (index / 6) * 2 * Math.PI - Math.PI / 3;

  const motes = useDerivedValue(() => easeOutCubic(clamp((progress.value - 0.28) / 0.72, 0, 1)));

  const style = useAnimatedStyle(() => {
    const distance = radius * (1.15 + 0.75 * motes.value);
    const dotSize = 4.8 * (1 - motes.value);
    return {
      position: 'absolute',
      left: centre + Math.cos(angle) * distance - dotSize / 2,
      top: centre + Math.sin(angle) * distance - dotSize / 2,
      height: dotSize,
      width: dotSize,
      borderRadius: dotSize / 2,
      opacity: 1 - motes.value,
    };
  });

  return <Animated.View style={[style, { backgroundColor: withAlpha(color, 0.55) }]} />;
}
