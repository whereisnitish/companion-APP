import React, { useState } from 'react';
import { Platform } from 'react-native';
import DateTimePicker, {
  type DateTimePickerEvent,
} from '@react-native-community/datetimepicker';

interface DateTimePickerFlowProps {
  /** Set to a Date to open the flow; null keeps it closed. */
  initial: Date | null;
  minimumDate?: Date;
  maximumDate?: Date;
  onDone: (value: Date) => void;
  onCancel: () => void;
}

/**
 * Flutter's `showDatePicker` then `showTimePicker` as one component: pick the
 * day, then the time, then hand back the combined moment.
 */
export function DateTimePickerFlow({
  initial,
  minimumDate,
  maximumDate,
  onDone,
  onCancel,
}: DateTimePickerFlowProps) {
  const [stage, setStage] = useState<'date' | 'time'>('date');
  const [draft, setDraft] = useState<Date>(initial ?? new Date());

  if (!initial) return null;

  const onChange = (event: DateTimePickerEvent, value?: Date) => {
    if (event.type === 'dismissed') {
      setStage('date');
      onCancel();
      return;
    }
    if (!value) return;

    if (stage === 'date') {
      // Carry the existing clock across, then ask for the time.
      const next = new Date(value);
      next.setHours(draft.getHours(), draft.getMinutes(), 0, 0);
      setDraft(next);
      setStage('time');
      return;
    }

    const combined = new Date(draft);
    combined.setHours(value.getHours(), value.getMinutes(), 0, 0);
    setStage('date');
    onDone(combined);
  };

  return (
    <DateTimePicker
      value={draft}
      mode={stage}
      display={Platform.OS === 'ios' ? 'spinner' : 'default'}
      minimumDate={stage === 'date' ? minimumDate : undefined}
      maximumDate={stage === 'date' ? maximumDate : undefined}
      onChange={onChange}
    />
  );
}
