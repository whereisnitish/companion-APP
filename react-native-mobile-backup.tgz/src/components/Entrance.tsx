import React, { useEffect, type ReactNode } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';

import { AppMotion } from '../theme';

interface EntranceProps {
  children: ReactNode;
  index?: number;
  offset?: number;
  delayStep?: number;
  maxSteps?: number;
  enabled?: boolean;
  style?: StyleProp<ViewStyle>;
}

/**
 * Content arrives rather than appearing: a 12px rise and a fade, staggered by
 * position in the list. Deliberately capped — after the sixth item the delay
 * stops growing, so a long list never feels like it is loading slowly.
 */
export function Entrance({
  children,
  index = 0,
  offset = 12,
  delayStep = 55,
  maxSteps = 6,
  enabled = true,
  style,
}: EntranceProps) {
  const progress = useSharedValue(enabled ? 0 : 1);

  useEffect(() => {
    if (!enabled) {
      progress.value = 1;
      return;
    }
    const steps = Math.min(Math.max(index, 0), maxSteps);
    progress.value = withDelay(
      steps * delayStep,
      // easeOutQuart — AppMotion.emphasized in the Flutter original.
      withTiming(1, { duration: AppMotion.entrance, easing: Easing.bezier(0.165, 0.84, 0.44, 1) }),
    );
  }, [enabled, index, delayStep, maxSteps, progress]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: progress.value,
    transform: [{ translateY: offset * (1 - progress.value) }],
  }));

  return <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>;
}

interface SoftSwitcherProps {
  children: ReactNode;
  /** Changing this key cross-fades to the new child. */
  switchKey: string | number;
  duration?: number;
  style?: StyleProp<ViewStyle>;
}

/**
 * Cross-fades between two children with a hair of vertical travel — used for
 * tab bodies and filter results where a hard swap would feel abrupt.
 */
export function SoftSwitcher({
  children,
  switchKey,
  duration = AppMotion.base,
  style,
}: SoftSwitcherProps) {
  return (
    <Animated.View
      key={switchKey}
      entering={FadeIn.duration(duration)}
      exiting={FadeOut.duration(duration / 2)}
      style={style}
    >
      {children}
    </Animated.View>
  );
}
