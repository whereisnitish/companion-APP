import React, { createContext, useContext, useEffect, type ReactNode } from 'react';
import { StyleSheet, View, type DimensionValue } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

import { AppRadii, AppSpacing, useTheme } from '../theme';

const ShimmerContext = createContext<SharedValue<number> | null>(null);

/**
 * A hand-rolled shimmer. One shared value drives every child through context,
 * so a screen full of placeholders costs a single animation.
 */
export function Shimmer({ children }: { children: ReactNode }) {
  const progress = useSharedValue(0);

  useEffect(() => {
    // Ping-pong the 0→1 driver into a 0→1→0 pulse.
    progress.value = withRepeat(
      withTiming(1, { duration: 700, easing: Easing.inOut(Easing.ease) }),
      -1,
      true,
    );
  }, [progress]);

  return <ShimmerContext.Provider value={progress}>{children}</ShimmerContext.Provider>;
}

interface SkeletonBoxProps {
  width?: DimensionValue;
  height?: number;
  radius?: number;
  circle?: boolean;
  size?: number;
}

/**
 * A single grey block that breathes. Compose these into screen-shaped
 * placeholders so a loading screen has the same silhouette as the real one.
 */
export function SkeletonBox({
  width,
  height = 14,
  radius = AppRadii.xs,
  circle = false,
  size,
}: SkeletonBoxProps) {
  const { colors } = useTheme();
  const progress = useContext(ShimmerContext);

  const resolvedWidth = circle && size !== undefined ? size : width;
  const resolvedHeight = circle && size !== undefined ? size : height;
  const resolvedRadius = circle && size !== undefined ? size / 2 : radius;

  const animatedStyle = useAnimatedStyle(() => ({
    // A soft pulse rather than a sweeping highlight — quieter, and it does not
    // fight the warm canvas.
    opacity: progress ? 0.55 + 0.45 * progress.value : 1,
  }));

  return (
    <Animated.View
      style={[
        {
          width: resolvedWidth,
          height: resolvedHeight,
          borderRadius: resolvedRadius,
          backgroundColor: colors.shimmerBase,
        },
        animatedStyle,
      ]}
    />
  );
}

/** The loading silhouette for a person card in Discover. */
export function PersonCardSkeleton() {
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <SkeletonBox height={190} radius={0} width="100%" />
      <View style={{ padding: AppSpacing.lg }}>
        <SkeletonBox width={130} height={16} />
        <View style={{ height: AppSpacing.sm }} />
        <SkeletonBox width={90} height={12} />
        <View style={{ height: AppSpacing.lg }} />
        <SkeletonBox height={12} width="100%" />
        <View style={{ height: AppSpacing.sm }} />
        <SkeletonBox width={180} height={12} />
      </View>
    </View>
  );
}

/** The loading silhouette for a list row. */
export function ListRowSkeleton({ leadingSize = 48 }: { leadingSize?: number }) {
  return (
    <View style={styles.row}>
      <SkeletonBox circle size={leadingSize} />
      <View style={styles.rowBody}>
        <SkeletonBox width={120} height={14} />
        <View style={{ height: AppSpacing.sm }} />
        <SkeletonBox height={12} width="100%" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: AppRadii.lg, borderWidth: 1, overflow: 'hidden' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.md,
  },
  rowBody: { flex: 1, marginLeft: AppSpacing.lg },
});
