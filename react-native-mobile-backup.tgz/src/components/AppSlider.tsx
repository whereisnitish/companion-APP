import React, { useCallback, useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { runOnJS, useAnimatedStyle, useSharedValue } from 'react-native-reanimated';

import { AppRadii, useTheme } from '../theme';

const TRACK_HEIGHT = 4;
const THUMB_SIZE = 24;

const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

function snap(value: number, min: number, max: number, step: number): number {
  const steps = Math.round((value - min) / step);
  return clamp(min + steps * step, min, max);
}

interface AppSliderProps {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
}

/** A single-thumb slider — distance, capacity. */
export function AppSlider({ value, min, max, step = 1, onChange }: AppSliderProps) {
  const { colors } = useTheme();
  const [width, setWidth] = useState(0);

  const usable = Math.max(width - THUMB_SIZE, 1);
  const ratio = (value - min) / (max - min || 1);

  const startRatio = useSharedValue(0);

  const emit = useCallback(
    (nextRatio: number) => {
      onChange(snap(min + nextRatio * (max - min), min, max, step));
    },
    [min, max, step, onChange],
  );

  const pan = Gesture.Pan()
    .onBegin(() => {
      startRatio.value = ratio;
    })
    .onUpdate((event) => {
      const next = clamp(startRatio.value + event.translationX / usable, 0, 1);
      runOnJS(emit)(next);
    });

  const onLayout = (event: LayoutChangeEvent) => setWidth(event.nativeEvent.layout.width);

  return (
    <View style={styles.container} onLayout={onLayout}>
      <View style={[styles.track, { backgroundColor: colors.surfaceSunken }]} />
      <View
        style={[
          styles.track,
          styles.fill,
          { backgroundColor: colors.primary, width: ratio * usable + THUMB_SIZE / 2 },
        ]}
      />
      <GestureDetector gesture={pan}>
        <View
          style={[
            styles.thumb,
            {
              left: ratio * usable,
              backgroundColor: colors.surface,
              borderColor: colors.primary,
            },
          ]}
        />
      </GestureDetector>
    </View>
  );
}

interface AppRangeSliderProps {
  low: number;
  high: number;
  min: number;
  max: number;
  step?: number;
  onChange: (low: number, high: number) => void;
}

/** A two-thumb range — the age filter. Thumbs cannot cross. */
export function AppRangeSlider({
  low,
  high,
  min,
  max,
  step = 1,
  onChange,
}: AppRangeSliderProps) {
  const { colors } = useTheme();
  const [width, setWidth] = useState(0);

  const usable = Math.max(width - THUMB_SIZE, 1);
  const span = max - min || 1;
  const lowRatio = (low - min) / span;
  const highRatio = (high - min) / span;

  const startLow = useSharedValue(0);
  const startHigh = useSharedValue(0);

  const emitLow = useCallback(
    (nextRatio: number) => {
      const next = snap(min + nextRatio * span, min, max, step);
      onChange(Math.min(next, high), high);
    },
    [min, max, span, step, high, onChange],
  );

  const emitHigh = useCallback(
    (nextRatio: number) => {
      const next = snap(min + nextRatio * span, min, max, step);
      onChange(low, Math.max(next, low));
    },
    [min, max, span, step, low, onChange],
  );

  const lowPan = Gesture.Pan()
    .onBegin(() => {
      startLow.value = lowRatio;
    })
    .onUpdate((event) => {
      runOnJS(emitLow)(clamp(startLow.value + event.translationX / usable, 0, 1));
    });

  const highPan = Gesture.Pan()
    .onBegin(() => {
      startHigh.value = highRatio;
    })
    .onUpdate((event) => {
      runOnJS(emitHigh)(clamp(startHigh.value + event.translationX / usable, 0, 1));
    });

  const onLayout = (event: LayoutChangeEvent) => setWidth(event.nativeEvent.layout.width);

  return (
    <View style={styles.container} onLayout={onLayout}>
      <View style={[styles.track, { backgroundColor: colors.surfaceSunken }]} />
      <View
        style={[
          styles.track,
          styles.fill,
          {
            backgroundColor: colors.primary,
            left: lowRatio * usable + THUMB_SIZE / 2,
            width: Math.max((highRatio - lowRatio) * usable, 0),
          },
        ]}
      />
      <GestureDetector gesture={lowPan}>
        <View
          style={[
            styles.thumb,
            { left: lowRatio * usable, backgroundColor: colors.surface, borderColor: colors.primary },
          ]}
        />
      </GestureDetector>
      <GestureDetector gesture={highPan}>
        <View
          style={[
            styles.thumb,
            { left: highRatio * usable, backgroundColor: colors.surface, borderColor: colors.primary },
          ]}
        />
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { height: THUMB_SIZE + 12, justifyContent: 'center' },
  track: {
    position: 'absolute',
    left: THUMB_SIZE / 2,
    right: THUMB_SIZE / 2,
    height: TRACK_HEIGHT,
    borderRadius: AppRadii.pill,
  },
  fill: { right: undefined, left: THUMB_SIZE / 2 },
  thumb: {
    position: 'absolute',
    height: THUMB_SIZE,
    width: THUMB_SIZE,
    borderRadius: THUMB_SIZE / 2,
    borderWidth: 2,
  },
});
