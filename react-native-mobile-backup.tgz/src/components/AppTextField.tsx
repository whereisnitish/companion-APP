import React, { forwardRef, useState, type ReactNode } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  type KeyboardTypeOptions,
  type ReturnKeyTypeOptions,
  type TextInputProps,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import type { MaterialIconName } from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';
import { PressEffect } from './PressEffect';

interface AppTextFieldProps {
  value?: string;
  label?: string;
  hint?: string;
  helper?: string;
  errorText?: string | null;
  keyboardType?: KeyboardTypeOptions;
  returnKeyType?: ReturnKeyTypeOptions;
  secureTextEntry?: boolean;
  multiline?: boolean;
  numberOfLines?: number;
  maxLength?: number;
  autoFocus?: boolean;
  editable?: boolean;
  prefixIcon?: MaterialIconName;
  suffix?: ReactNode;
  onChangeText?: (value: string) => void;
  onSubmitEditing?: () => void;
  autoCapitalize?: TextInputProps['autoCapitalize'];
  autoComplete?: TextInputProps['autoComplete'];
  testID?: string;
}

/**
 * A quiet input: no filled grey box, no floating label acrobatics. A label
 * above, a hairline field, and the border warms to the brand colour on focus.
 */
export const AppTextField = forwardRef<TextInput, AppTextFieldProps>(function AppTextField(
  {
    value,
    label,
    hint,
    helper,
    errorText,
    keyboardType,
    returnKeyType,
    secureTextEntry = false,
    multiline = false,
    numberOfLines = 1,
    maxLength,
    autoFocus = false,
    editable = true,
    prefixIcon,
    suffix,
    onChangeText,
    onSubmitEditing,
    autoCapitalize = 'none',
    autoComplete,
    testID,
  },
  ref,
) {
  const { colors, type } = useTheme();
  const [isFocused, setIsFocused] = useState(false);
  const [obscured, setObscured] = useState(secureTextEntry);

  const hasError = !!errorText && errorText.length > 0;
  const borderColor = hasError ? colors.danger : isFocused ? colors.primary : colors.border;

  return (
    <View>
      {label ? (
        <Text style={[type.label, { color: colors.inkMuted, marginBottom: AppSpacing.sm }]}>
          {label}
        </Text>
      ) : null}

      <View
        style={[
          styles.field,
          {
            backgroundColor: editable ? colors.surface : colors.surfaceSunken,
            borderColor,
            borderWidth: isFocused || hasError ? 1.5 : 1,
            alignItems: multiline ? 'flex-start' : 'center',
            paddingVertical: multiline ? AppSpacing.md : 0,
          },
        ]}
      >
        {prefixIcon ? (
          <MaterialIcons
            name={prefixIcon}
            size={19}
            color={isFocused ? colors.primary : colors.inkFaint}
            style={[styles.prefix, multiline ? { marginTop: 2 } : null]}
          />
        ) : null}

        <TextInput
          ref={ref}
          testID={testID}
          value={value}
          editable={editable}
          autoFocus={autoFocus}
          secureTextEntry={obscured}
          keyboardType={keyboardType}
          returnKeyType={returnKeyType}
          autoCapitalize={autoCapitalize}
          autoComplete={autoComplete}
          multiline={multiline && !obscured}
          numberOfLines={multiline ? numberOfLines : 1}
          maxLength={maxLength}
          onChangeText={onChangeText}
          onSubmitEditing={onSubmitEditing}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={hint}
          placeholderTextColor={colors.inkFaint}
          selectionColor={colors.primary}
          style={[
            type.body,
            styles.input,
            {
              color: colors.ink,
              paddingVertical: multiline ? 2 : AppSpacing.lg,
              textAlignVertical: multiline ? 'top' : 'center',
              minHeight: multiline ? numberOfLines * 22 : undefined,
            },
          ]}
        />

        {secureTextEntry ? (
          <PressEffect onPress={() => setObscured((current) => !current)} scale={0.9} hitSlop={8}>
            <MaterialIcons
              name={obscured ? 'visibility' : 'visibility-off'}
              size={19}
              color={colors.inkFaint}
              style={styles.suffix}
            />
          </PressEffect>
        ) : suffix ? (
          <View style={styles.suffix}>{suffix}</View>
        ) : null}
      </View>

      {hasError || helper ? (
        <Text
          style={[
            type.caption,
            styles.helper,
            { color: hasError ? colors.danger : colors.inkFaint },
          ]}
        >
          {hasError ? errorText : helper}
        </Text>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row',
    borderRadius: AppRadii.md,
    paddingHorizontal: AppSpacing.lg,
  },
  input: { flex: 1, padding: 0 },
  prefix: { marginRight: AppSpacing.md },
  suffix: { marginLeft: AppSpacing.md },
  helper: { marginTop: AppSpacing.sm, marginLeft: AppSpacing.xs },
});
