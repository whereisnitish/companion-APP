import React, { type ReactNode } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn, FadeOut, SlideInDown, SlideOutDown } from 'react-native-reanimated';
import { MaterialIcons } from '@expo/vector-icons';

import type { MaterialIconName } from '../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../theme';
import { AppButton } from './AppButton';

interface AppSheetProps {
  visible: boolean;
  onDismiss: () => void;
  children: ReactNode;
  title?: string;
  subtitle?: string;
  trailing?: ReactNode;
  footer?: ReactNode;
  dismissible?: boolean;
  /** Set false when the body manages its own scrolling (e.g. a long list). */
  scrollable?: boolean;
}

/**
 * Bottom sheets are the product's second surface — filters, pickers,
 * confirmations. They all share this chrome: a grab handle, an optional title
 * row, and content that scrolls without the sheet losing its rounded top.
 */
export function AppSheet({
  visible,
  onDismiss,
  children,
  title,
  subtitle,
  trailing,
  footer,
  dismissible = true,
  scrollable = true,
}: AppSheetProps) {
  const { colors, type } = useTheme();
  const insets = useSafeAreaInsets();

  const body = (
    <View style={styles.bodyPadding}>{children}</View>
  );

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onDismiss}>
      <Animated.View
        entering={FadeIn.duration(180)}
        exiting={FadeOut.duration(160)}
        style={[styles.scrim, { backgroundColor: colors.overlay }]}
      >
        <Pressable
          style={styles.scrimPress}
          onPress={dismissible ? onDismiss : undefined}
          accessibilityLabel="Dismiss"
        />
      </Animated.View>

      <View style={styles.anchor} pointerEvents="box-none">
        <Animated.View
          entering={SlideInDown.duration(280)}
          exiting={SlideOutDown.duration(200)}
          style={[
            styles.sheet,
            { backgroundColor: colors.surface, borderColor: colors.border },
          ]}
        >
          <View style={styles.handleRow}>
            <View style={[styles.handle, { backgroundColor: colors.borderStrong }]} />
          </View>

          {title ? (
            <View style={styles.titleRow}>
              <View style={styles.titleBody}>
                <Text style={type.title}>{title}</Text>
                {subtitle ? (
                  <Text
                    style={[type.bodySmall, { color: colors.inkMuted, marginTop: AppSpacing.xs }]}
                  >
                    {subtitle}
                  </Text>
                ) : null}
              </View>
              {trailing}
            </View>
          ) : null}

          {scrollable ? (
            <ScrollView
              style={styles.scroll}
              contentContainerStyle={styles.scrollContent}
              keyboardShouldPersistTaps="handled"
            >
              {body}
            </ScrollView>
          ) : (
            body
          )}

          {footer ? (
            <View
              style={[
                styles.footer,
                {
                  backgroundColor: colors.surface,
                  borderTopColor: colors.border,
                  paddingBottom: AppSpacing.lg + insets.bottom,
                },
              ]}
            >
              {footer}
            </View>
          ) : (
            <View style={{ height: insets.bottom }} />
          )}
        </Animated.View>
      </View>
    </Modal>
  );
}

interface ConfirmSheetProps {
  visible: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  icon?: MaterialIconName;
  onConfirm: () => void;
  onCancel: () => void;
}

/** A destructive-or-not confirmation. */
export function ConfirmSheet({
  visible,
  title,
  message,
  confirmLabel,
  cancelLabel = 'Cancel',
  isDestructive = false,
  icon = 'help-outline',
  onConfirm,
  onCancel,
}: ConfirmSheetProps) {
  const { colors, type } = useTheme();

  return (
    <AppSheet visible={visible} onDismiss={onCancel} scrollable={false}>
      <View style={styles.confirmMarkRow}>
        <View
          style={[
            styles.confirmMark,
            { backgroundColor: isDestructive ? colors.dangerSoft : colors.surfaceSunken },
          ]}
        >
          <MaterialIcons name={icon} size={26} color={isDestructive ? colors.danger : colors.ink} />
        </View>
      </View>

      <Text style={[type.title, styles.centered, { marginTop: AppSpacing.xl }]}>{title}</Text>
      <Text
        style={[type.body, styles.centered, { color: colors.inkMuted, marginTop: AppSpacing.sm }]}
      >
        {message}
      </Text>

      <View style={{ height: AppSpacing.xxl }} />
      <AppButton
        label={confirmLabel}
        variant={isDestructive ? 'danger' : 'primary'}
        onPress={onConfirm}
      />
      <View style={{ height: AppSpacing.md }} />
      <AppButton label={cancelLabel} variant="ghost" size="large" onPress={onCancel} />
    </AppSheet>
  );
}

const styles = StyleSheet.create({
  scrim: { ...StyleSheet.absoluteFillObject },
  scrimPress: { flex: 1 },
  anchor: { flex: 1, justifyContent: 'flex-end' },
  sheet: {
    borderTopLeftRadius: AppRadii.xl,
    borderTopRightRadius: AppRadii.xl,
    borderTopWidth: 1,
    maxHeight: '90%',
    overflow: 'hidden',
  },
  handleRow: { alignItems: 'center', paddingTop: AppSpacing.md },
  handle: { height: 4, width: 36, borderRadius: AppRadii.pill },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xl,
  },
  titleBody: { flex: 1 },
  scroll: { flexGrow: 0 },
  scrollContent: { paddingTop: AppSpacing.xl },
  bodyPadding: { paddingHorizontal: AppSpacing.screenX, paddingBottom: AppSpacing.xl },
  footer: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    borderTopWidth: 1,
  },
  centered: { textAlign: 'center' },
  confirmMarkRow: { alignItems: 'center', paddingTop: AppSpacing.xl },
  confirmMark: {
    height: 56,
    width: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
