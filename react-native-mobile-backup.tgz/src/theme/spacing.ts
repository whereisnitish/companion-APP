/** One spacing scale for the whole product. Screens never invent a number. */
export const AppSpacing = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 40,
  giant: 56,

  /** Horizontal breathing room shared by every screen. */
  screenX: 20,
} as const;

export const AppRadii = {
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 28,
  pill: 999,
} as const;

/** Motion tokens. Short, eased, and never decorative. */
export const AppMotion = {
  instant: 90,
  fast: 160,
  base: 260,
  slow: 420,
  entrance: 520,
} as const;

/**
 * Reanimated easing curves matching the Flutter originals.
 * `standard` is easeOutCubic, `emphasized` easeOutQuart, `spring` easeOutBack.
 */
export const AppEasing = {
  standard: [0.215, 0.61, 0.355, 1] as const,
  emphasized: [0.165, 0.84, 0.44, 1] as const,
  spring: [0.34, 1.56, 0.64, 1] as const,
};
