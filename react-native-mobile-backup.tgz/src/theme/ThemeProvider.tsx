import React, { createContext, useContext, useMemo, type ReactNode } from 'react';
import { useColorScheme } from 'react-native';

import { darkColors, lightColors, type AppColors } from './colors';
import { AppShadows } from './shadows';
import { buildTypography, type AppTypography } from './typography';

export interface Theme {
  colors: AppColors;
  type: AppTypography;
  shadows: {
    resting: ReturnType<typeof AppShadows.resting>;
    raised: ReturnType<typeof AppShadows.raised>;
    sheet: ReturnType<typeof AppShadows.sheet>;
  };
  isDark: boolean;
}

function buildTheme(isDark: boolean): Theme {
  const colors = isDark ? darkColors : lightColors;
  return {
    colors,
    type: buildTypography(colors.ink),
    shadows: {
      resting: AppShadows.resting(colors.ink),
      raised: AppShadows.raised(colors.ink),
      sheet: AppShadows.sheet(colors.ink),
    },
    isDark,
  };
}

const ThemeContext = createContext<Theme>(buildTheme(false));

export function ThemeProvider({ children }: { children: ReactNode }) {
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  const theme = useMemo(() => buildTheme(isDark), [isDark]);

  return <ThemeContext.Provider value={theme}>{children}</ThemeContext.Provider>;
}

/** `const { colors, type } = useTheme()` — the only way screens reach for tokens. */
export function useTheme(): Theme {
  return useContext(ThemeContext);
}
