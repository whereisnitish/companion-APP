import type { ViewStyle } from 'react-native';

import { withAlpha } from './colors';

/**
 * Shadows are almost invisible on purpose. Depth here comes from a hairline
 * border plus a wide, very soft ambient shadow — never a hard drop.
 *
 * React Native has no spread radius, so each Flutter shadow is expressed as
 * the nearest equivalent: the blur is scaled down to account for the negative
 * spread the original used to pull the shadow in.
 */
export const AppShadows = {
  resting: (ink: string): ViewStyle => ({
    shadowColor: withAlpha(ink, 0.04),
    shadowOpacity: 1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 2,
  }),

  raised: (ink: string): ViewStyle => ({
    shadowColor: withAlpha(ink, 0.05),
    shadowOpacity: 1,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 12 },
    elevation: 6,
  }),

  sheet: (ink: string): ViewStyle => ({
    shadowColor: withAlpha(ink, 0.12),
    shadowOpacity: 1,
    shadowRadius: 28,
    shadowOffset: { width: 0, height: -8 },
    elevation: 16,
  }),
} as const;
