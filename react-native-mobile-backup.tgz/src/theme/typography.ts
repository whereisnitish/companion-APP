import type { TextStyle } from 'react-native';

/**
 * Two faces, used with discipline.
 *
 *  * **Fraunces** — a soft-contrast serif, reserved for the few moments that
 *    should feel like a masthead: the home greeting, screen titles, a person's
 *    name on their profile. Nothing smaller than 20pt.
 *  * **Inter** — everything else. It is the voice of the interface.
 *
 * Mixing a serif display with a neutral UI face is what stops the product
 * reading like a template. Used everywhere it would read like a magazine, so
 * it is used in exactly four places.
 */
export const FontFamily = {
  serifSemiBold: 'Fraunces_600SemiBold',
  sansRegular: 'Inter_400Regular',
  sansSemiBold: 'Inter_600SemiBold',
  sansBold: 'Inter_700Bold',
} as const;

export interface AppTypography {
  /** Serif. 34/40 — one per screen at most. */
  display: TextStyle;
  /** Serif. 28/34 — screen titles. */
  headline: TextStyle;
  /** Serif. 22/28 — names on profile and activity detail. */
  serifTitle: TextStyle;
  /** Sans. 20/26 — section leads and card titles. */
  title: TextStyle;
  /** Sans. 17/24. */
  subtitle: TextStyle;
  /** Sans. 15/22 — the default reading size. */
  body: TextStyle;
  bodyStrong: TextStyle;
  /** Sans. 13/19. */
  bodySmall: TextStyle;
  /** Sans. 13/16, semibold — chips, tabs, metadata. */
  label: TextStyle;
  /** Sans. 12/16 — timestamps, helper text. */
  caption: TextStyle;
  /** Sans. 11/14, tracked and uppercase — section eyebrows. */
  overline: TextStyle;
  button: TextStyle;
  /** Tabular figures, for counts and distances that must not jitter. */
  numeric: TextStyle;
}

const serif = (
  fontSize: number,
  lineHeight: number,
  letterSpacing: number,
  color: string,
): TextStyle => ({
  fontFamily: FontFamily.serifSemiBold,
  fontSize,
  lineHeight,
  letterSpacing,
  color,
});

const sans = (
  fontSize: number,
  lineHeight: number,
  family: string,
  letterSpacing: number,
  color: string,
): TextStyle => ({ fontFamily: family, fontSize, lineHeight, letterSpacing, color });

export function buildTypography(ink: string): AppTypography {
  return {
    display: serif(34, 40, -0.6, ink),
    headline: serif(28, 34, -0.4, ink),
    serifTitle: serif(22, 28, -0.2, ink),
    title: sans(20, 26, FontFamily.sansSemiBold, -0.3, ink),
    subtitle: sans(17, 24, FontFamily.sansSemiBold, -0.2, ink),
    body: sans(15, 22, FontFamily.sansRegular, -0.1, ink),
    bodyStrong: sans(15, 22, FontFamily.sansSemiBold, -0.1, ink),
    bodySmall: sans(13, 19, FontFamily.sansRegular, 0, ink),
    label: sans(13, 16, FontFamily.sansSemiBold, -0.05, ink),
    caption: sans(12, 16, FontFamily.sansRegular, 0, ink),
    overline: { ...sans(11, 14, FontFamily.sansBold, 0.9, ink), textTransform: 'uppercase' },
    button: sans(15, 20, FontFamily.sansSemiBold, -0.1, ink),
    numeric: {
      ...sans(13, 16, FontFamily.sansSemiBold, 0, ink),
      fontVariant: ['tabular-nums'],
    },
  };
}
