/**
 * The palette. Two tuned sets — nothing is computed on the fly, so the product
 * looks the same in every screen and in both themes.
 *
 * Direction: warm paper, deep pine, a single clay accent used sparingly.
 * Colour carries meaning here; it is never decoration.
 */
export interface AppColors {
  canvas: string;
  surface: string;
  surfaceRaised: string;
  surfaceSunken: string;

  ink: string;
  inkMuted: string;
  inkFaint: string;
  inkInverse: string;

  primary: string;
  primaryPressed: string;
  onPrimary: string;
  primarySoft: string;

  accent: string;
  accentSoft: string;

  border: string;
  borderStrong: string;

  success: string;
  successSoft: string;
  warning: string;
  danger: string;
  dangerSoft: string;

  overlay: string;
  shimmerBase: string;
  shimmerHighlight: string;
}

export const lightColors: AppColors = {
  canvas: '#F7F5F1',
  surface: '#FFFFFF',
  surfaceRaised: '#FFFFFF',
  surfaceSunken: '#F0EDE7',
  ink: '#16211C',
  inkMuted: '#69736E',
  inkFaint: '#9BA39F',
  inkInverse: '#F7F5F1',
  primary: '#14453A',
  primaryPressed: '#0D2F27',
  onPrimary: '#F7F5F1',
  primarySoft: '#E2ECE7',
  accent: '#C0603A',
  accentSoft: '#F8E9E1',
  border: '#E7E2D9',
  borderStrong: '#D5CEC2',
  success: '#2C7A5B',
  successSoft: '#DFF0E7',
  warning: '#A97B1F',
  danger: '#B03E2E',
  dangerSoft: '#F8E4E0',
  overlay: 'rgba(16, 21, 18, 0.2)',
  shimmerBase: '#EDEAE3',
  shimmerHighlight: '#F6F4EF',
};

export const darkColors: AppColors = {
  canvas: '#0C110F',
  surface: '#141A17',
  surfaceRaised: '#1A211D',
  surfaceSunken: '#0F1512',
  ink: '#F0EEE8',
  inkMuted: '#9AA49F',
  inkFaint: '#6C7671',
  inkInverse: '#0C110F',
  primary: '#63B598',
  primaryPressed: '#4E9C81',
  onPrimary: '#07130E',
  primarySoft: '#172A23',
  accent: '#E0855C',
  accentSoft: '#2C1D16',
  border: '#232C27',
  borderStrong: '#33403A',
  success: '#5DBA92',
  successSoft: '#14261E',
  warning: '#D3A44D',
  danger: '#E1705C',
  dangerSoft: '#2B1815',
  overlay: 'rgba(0, 0, 0, 0.4)',
  shimmerBase: '#1A211D',
  shimmerHighlight: '#232C27',
};

/** `#RRGGBB` plus an alpha, as an `rgba()` string. */
export function withAlpha(hex: string, alpha: number): string {
  const value = hex.replace('#', '');
  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
