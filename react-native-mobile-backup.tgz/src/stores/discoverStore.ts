import { create } from 'zustand';

import { NO_FILTERS, type DiscoveryFilters } from '../services/discoveryService';

export type DiscoverMode = 'people' | 'activities';

interface DiscoverState {
  mode: DiscoverMode;
  filters: DiscoveryFilters;
  setMode: (mode: DiscoverMode) => void;
  setFilters: (filters: DiscoveryFilters) => void;
  resetFilters: () => void;
}

/**
 * The discover tab's UI state. Riverpod held these as two `StateProvider`s;
 * they live together here because every screen that reads one reads the other.
 */
export const useDiscoverStore = create<DiscoverState>((set) => ({
  mode: 'people',
  filters: NO_FILTERS,
  setMode: (mode) => set({ mode }),
  setFilters: (filters) => set({ filters }),
  resetFilters: () => set({ filters: NO_FILTERS }),
}));
