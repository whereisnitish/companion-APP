import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';

import type { CurrentUser } from '../models/profile';
import { apiClient, authService, profileService, socketClient, tokenStorage } from '../services';
import type { AuthSession } from '../services/authService';

/** Where the app is in its lifecycle. The navigator reads exactly this. */
export type AuthStage =
  /** Restoring a stored session — show the splash. */
  | 'loading'
  /** No session. Onboarding has not been seen yet. */
  | 'onboarding'
  /** No session, onboarding done. */
  | 'signedOut'
  /** Signed in but the profile has not been created. */
  | 'needsProfile'
  /** Fully set up. */
  | 'ready';

const ONBOARDING_SEEN_KEY = 'companion.onboarding_seen';

interface AuthState {
  stage: AuthStage;
  user: CurrentUser | null;

  restore: () => Promise<void>;
  completeOnboarding: () => Promise<void>;
  register: (params: { email?: string; phone?: string; password: string }) => Promise<void>;
  login: (params: { email?: string; phone?: string; password: string }) => Promise<void>;
  verifyOtp: (phone: string, code: string) => Promise<void>;
  setUser: (user: CurrentUser) => void;
  refreshUser: () => Promise<void>;
  signOut: () => Promise<void>;
}

export const isAuthenticated = (stage: AuthStage) =>
  stage === 'ready' || stage === 'needsProfile';

async function onboardingSeen(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(ONBOARDING_SEEN_KEY)) === 'true';
  } catch {
    return false;
  }
}

function connectRealtime(): void {
  const token = tokenStorage.cachedAccessToken;
  if (token) socketClient.connect(token);
}

export const useAuthStore = create<AuthState>((set, get) => ({
  stage: 'loading',
  user: null,

  /**
   * Reads the keychain and, if a session is there, revalidates it against
   * `/users/me` before letting anyone into the app.
   */
  async restore() {
    const tokens = await tokenStorage.read();
    if (!tokens) {
      set({ stage: (await onboardingSeen()) ? 'signedOut' : 'onboarding', user: null });
      return;
    }

    try {
      const user = await profileService.fetchMe();
      connectRealtime();
      set({ stage: user.isProfileComplete ? 'ready' : 'needsProfile', user });
    } catch {
      await tokenStorage.clear();
      set({ stage: (await onboardingSeen()) ? 'signedOut' : 'onboarding', user: null });
    }
  },

  async completeOnboarding() {
    await AsyncStorage.setItem(ONBOARDING_SEEN_KEY, 'true');
    if (get().stage === 'onboarding') set({ stage: 'signedOut' });
  },

  async register(params) {
    await adopt(await authService.register(params), set);
  },

  async login(params) {
    await adopt(await authService.login(params), set);
  },

  async verifyOtp(phone, code) {
    await adopt(await authService.verifyOtp(phone, code), set);
  },

  /** Called after profile creation and after any profile edit. */
  setUser(user) {
    set({ stage: user.isProfileComplete ? 'ready' : 'needsProfile', user });
  },

  async refreshUser() {
    try {
      get().setUser(await profileService.fetchMe());
    } catch {
      /* a failed refresh must never sign anyone out */
    }
  },

  async signOut() {
    const refreshToken = await tokenStorage.readRefreshToken();
    if (refreshToken) {
      try {
        await authService.logout(refreshToken);
      } catch {
        /* best effort — the local session goes either way */
      }
    }
    await tokenStorage.clear();
    socketClient.disconnect();
    set({ stage: 'signedOut', user: null });
  },
}));

async function adopt(
  session: AuthSession,
  set: (partial: Partial<AuthState>) => void,
): Promise<void> {
  await tokenStorage.save(session.tokens);
  await AsyncStorage.setItem(ONBOARDING_SEEN_KEY, 'true');
  connectRealtime();
  set({ stage: session.user.isProfileComplete ? 'ready' : 'needsProfile', user: session.user });
}

// A refresh that fails takes the session with it: drop the socket and fall
// back to the signed-out stage, exactly as the Riverpod controller did.
apiClient.onSessionExpired = () => {
  socketClient.disconnect();
  useAuthStore.setState({ stage: 'signedOut', user: null });
};

/** The signed-in user, or null. Most screens want this rather than the state. */
export const useCurrentUser = () => useAuthStore((state) => state.user);
