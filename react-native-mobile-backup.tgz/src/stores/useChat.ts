import { useCallback, useEffect, useRef, useState } from 'react';

import type { RealtimeEvent } from '../core/realtime/socketClient';
import { parseMessage, type Message } from '../models/conversation';
import { conversationService, socketClient } from '../services';

export interface ChatState {
  /** Newest first — the view renders an inverted list. */
  messages: Message[];
  isLoading: boolean;
  isLoadingMore: boolean;
  hasMore: boolean;
  error: unknown;
  isPeerTyping: boolean;
}

export interface ChatApi extends ChatState {
  load: () => Promise<void>;
  loadMore: () => Promise<void>;
  send: (body: string) => Promise<void>;
  retry: (failed: Message) => Promise<void>;
  markRead: () => Promise<void>;
  onComposerChanged: (value: string) => void;
}

/** Owns one conversation: history, paging, optimistic sends, typing and reads. */
export function useChat(conversationId: string): ChatApi {
  const [state, setState] = useState<ChatState>({
    messages: [],
    isLoading: true,
    isLoadingMore: false,
    hasMore: false,
    error: null,
    isPeerTyping: false,
  });

  const cursor = useRef<string | null>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingThrottle = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Read inside the socket handler, which must not be re-bound on every render.
  const messagesRef = useRef<Message[]>([]);
  messagesRef.current = state.messages;

  const markRead = useCallback(async () => {
    try {
      await conversationService.markRead(conversationId);
    } catch {
      /* the badge will settle on the next fetch */
    }
  }, [conversationId]);

  const load = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));
    try {
      const page = await conversationService.messages(conversationId);
      cursor.current = page.nextCursor;
      setState((prev) => ({
        ...prev,
        messages: page.messages,
        isLoading: false,
        hasMore: page.nextCursor !== null,
      }));
      void markRead();
    } catch (error) {
      setState((prev) => ({ ...prev, isLoading: false, error }));
    }
  }, [conversationId, markRead]);

  const loadMore = useCallback(async () => {
    if (state.isLoadingMore || !state.hasMore || cursor.current === null) return;
    setState((prev) => ({ ...prev, isLoadingMore: true }));
    try {
      const page = await conversationService.messages(conversationId, cursor.current);
      cursor.current = page.nextCursor;
      setState((prev) => ({
        ...prev,
        messages: [...prev.messages, ...page.messages],
        isLoadingMore: false,
        hasMore: page.nextCursor !== null,
      }));
    } catch {
      setState((prev) => ({ ...prev, isLoadingMore: false }));
    }
  }, [conversationId, state.isLoadingMore, state.hasMore]);

  const stopTyping = useCallback(() => {
    if (typingThrottle.current) {
      clearTimeout(typingThrottle.current);
      typingThrottle.current = null;
    }
    socketClient.sendTyping(conversationId, false);
  }, [conversationId]);

  /**
   * Shows the bubble immediately, then reconciles with the server's copy.
   * A failure marks the bubble rather than removing it, so nothing is lost.
   */
  const send = useCallback(
    async (body: string) => {
      const trimmed = body.trim();
      if (trimmed.length === 0) return;

      const temporaryId = `pending-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const optimistic: Message = {
        id: temporaryId,
        conversationId,
        senderId: 'me',
        body: trimmed,
        kind: 'text',
        createdAt: new Date(),
        readAt: null,
        isMine: true,
        isPending: true,
        hasFailed: false,
      };

      setState((prev) => ({ ...prev, messages: [optimistic, ...prev.messages] }));
      stopTyping();

      try {
        const saved = await conversationService.send(conversationId, trimmed);
        setState((prev) => ({
          ...prev,
          messages: prev.messages.map((message) => (message.id === temporaryId ? saved : message)),
        }));
      } catch {
        setState((prev) => ({
          ...prev,
          messages: prev.messages.map((message) =>
            message.id === temporaryId
              ? { ...message, isPending: false, hasFailed: true }
              : message,
          ),
        }));
      }
    },
    [conversationId, stopTyping],
  );

  const retry = useCallback(
    async (failed: Message) => {
      setState((prev) => ({
        ...prev,
        messages: prev.messages.filter((message) => message.id !== failed.id),
      }));
      await send(failed.body);
    },
    [send],
  );

  /** Throttled to one frame per second — a keystroke should not be a packet. */
  const onComposerChanged = useCallback(
    (value: string) => {
      if (value.trim().length === 0) {
        stopTyping();
        return;
      }
      if (typingThrottle.current) return;
      socketClient.sendTyping(conversationId, true);
      typingThrottle.current = setTimeout(() => {
        typingThrottle.current = null;
      }, 1000);
    },
    [conversationId, stopTyping],
  );

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const unsubscribe = socketClient.subscribe((event: RealtimeEvent) => {
      if (event.conversationId !== conversationId) return;

      switch (event.type) {
        case 'message:new': {
          const incoming = parseMessage(event.payload);
          if (messagesRef.current.some((message) => message.id === incoming.id)) return;
          setState((prev) => ({ ...prev, messages: [incoming, ...prev.messages] }));
          void markRead();
          break;
        }

        case 'message:read': {
          const now = new Date();
          setState((prev) => ({
            ...prev,
            messages: prev.messages.map((message) =>
              message.isMine && message.readAt === null ? { ...message, readAt: now } : message,
            ),
          }));
          break;
        }

        case 'typing': {
          const isTyping = event.payload.isTyping === true;
          setState((prev) => ({ ...prev, isPeerTyping: isTyping }));
          if (typingTimeout.current) clearTimeout(typingTimeout.current);
          if (isTyping) {
            typingTimeout.current = setTimeout(() => {
              setState((prev) => ({ ...prev, isPeerTyping: false }));
            }, 4000);
          }
          break;
        }
      }
    });

    return unsubscribe;
  }, [conversationId, markRead]);

  useEffect(
    () => () => {
      if (typingTimeout.current) clearTimeout(typingTimeout.current);
      if (typingThrottle.current) clearTimeout(typingThrottle.current);
    },
    [],
  );

  return { ...state, load, loadMore, send, retry, markRead, onComposerChanged };
}
