import { parseActivity, type Activity } from './activity';
import { ACTIVITY_CATEGORIES, categoryFromWire, type ActivityCategory } from './enums';
import { asInt, asString, parseList, type Json } from './json';
import { parseProfile, type Profile } from './profile';

export type Greeting = 'MORNING' | 'AFTERNOON' | 'EVENING';

const GREETING_LABELS: Record<Greeting, string> = {
  MORNING: 'Good morning',
  AFTERNOON: 'Good afternoon',
  EVENING: 'Good evening',
};

export const greetingLabel = (greeting: Greeting) => GREETING_LABELS[greeting];

export function greetingFromWire(value: unknown): Greeting {
  return value === 'MORNING' || value === 'AFTERNOON' ? value : 'EVENING';
}

export interface CategoryCount {
  category: ActivityCategory;
  openActivities: number;
  people: number;
}

export const parseCategoryCount = (json: Json): CategoryCount => ({
  category: categoryFromWire(json.category),
  openActivities: asInt(json.openActivities),
  people: asInt(json.people),
});

/**
 * One request, one screen. The home feed is assembled server-side so the
 * first paint after launch is a single round-trip.
 */
export interface HomeFeed {
  greeting: Greeting;
  city: string;
  categories: CategoryCount[];
  peopleNearby: Profile[];
  activitiesNearby: Activity[];
  tonight: Activity[];
  pendingInvitations: number;
  unreadMessages: number;
}

/** Every category, ordered so the ones with something happening come first. */
export function orderedCategories(feed: Pick<HomeFeed, 'categories'>): CategoryCount[] {
  const byCategory = new Map<ActivityCategory, CategoryCount>();
  for (const count of feed.categories) byCategory.set(count.category, count);

  return ACTIVITY_CATEGORIES.map(
    (category) =>
      byCategory.get(category) ?? { category, openActivities: 0, people: 0 },
  ).sort((a, b) => {
    const byActivity = b.openActivities - a.openActivities;
    if (byActivity !== 0) return byActivity;
    return b.people - a.people;
  });
}

export function parseHomeFeed(json: Json): HomeFeed {
  return {
    greeting: greetingFromWire(json.greeting),
    city: asString(json.city),
    categories: parseList(json.categories, parseCategoryCount),
    peopleNearby: parseList(json.peopleNearby, parseProfile),
    activitiesNearby: parseList(json.activitiesNearby, parseActivity),
    tonight: parseList(json.tonight, parseActivity),
    pendingInvitations: asInt(json.pendingInvitations),
    unreadMessages: asInt(json.unreadMessages),
  };
}
