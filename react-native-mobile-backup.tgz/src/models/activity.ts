import {
  categoryFromWire,
  genderPreferenceFromWire,
  invitationStatusFromWire,
  type ActivityCategory,
  type GenderPreference,
  type InvitationStatus,
} from './enums';
import { asBool, asDate, asInt, asObject, asOptionalDouble, asOptionalString, asString, type Json } from './json';
import { parseProfile, type Profile } from './profile';

/** A plan somebody has posted, waiting for company. */
export interface Activity {
  id: string;
  category: ActivityCategory;
  title: string;
  description: string;
  startsAt: Date;
  endsAt: Date | null;
  locationName: string;
  area: string | null;
  city: string;
  lookingFor: GenderPreference;
  minAge: number;
  maxAge: number;
  capacity: number;
  status: string;
  createdAt: Date | null;
  host: Profile;
  participantCount: number;
  distanceKm: number | null;
  isHost: boolean;
  viewerInvitationStatus: InvitationStatus | null;
}

export const isOpen = (activity: Pick<Activity, 'status'>): boolean => activity.status === 'OPEN';

export const spotsLeft = (activity: Pick<Activity, 'capacity' | 'participantCount'>): number => {
  const remaining = activity.capacity + 1 - activity.participantCount;
  return Math.min(Math.max(remaining, 0), activity.capacity);
};

export function parseActivity(json: Json): Activity {
  return {
    id: asString(json.id),
    category: categoryFromWire(json.category),
    title: asString(json.title),
    description: asString(json.description),
    startsAt: asDate(json.startsAt) ?? new Date(),
    endsAt: asDate(json.endsAt),
    locationName: asString(json.locationName),
    area: asOptionalString(json.area),
    city: asString(json.city),
    lookingFor: genderPreferenceFromWire(json.lookingFor),
    minAge: asInt(json.minAge, 18),
    maxAge: asInt(json.maxAge, 99),
    capacity: asInt(json.capacity, 1),
    status: asString(json.status, 'OPEN'),
    createdAt: asDate(json.createdAt),
    host: parseProfile(asObject(json.host)),
    participantCount: asInt(json.participantCount, 1),
    distanceKm: asOptionalDouble(json.distanceKm),
    isHost: asBool(json.isHost),
    viewerInvitationStatus:
      json.viewerInvitationStatus === null || json.viewerInvitationStatus === undefined
        ? null
        : invitationStatusFromWire(json.viewerInvitationStatus),
  };
}

/** The compact activity summary carried alongside a conversation. */
export interface ActivityContext {
  id: string;
  category: ActivityCategory;
  title: string;
  startsAt: Date;
  locationName: string;
}

export function parseActivityContext(json: Json): ActivityContext {
  return {
    id: asString(json.id),
    category: categoryFromWire(json.category),
    title: asString(json.title),
    startsAt: asDate(json.startsAt) ?? new Date(),
    locationName: asString(json.locationName),
  };
}
