import type { ComponentProps } from 'react';
import { MaterialIcons } from '@expo/vector-icons';

export type MaterialIconName = ComponentProps<typeof MaterialIcons>['name'];

/**
 * The twelve things people do together. Each one carries its own small visual
 * identity — an icon and a single hue — so a category is recognisable before
 * the label is read.
 */
export type ActivityCategory =
  | 'MOVIE'
  | 'DINNER'
  | 'COFFEE'
  | 'SHOPPING'
  | 'WALK'
  | 'EVENT'
  | 'TRAVEL'
  | 'SPORTS'
  | 'CONCERT'
  | 'STUDY'
  | 'GAMING'
  | 'OTHER';

interface CategoryMeta {
  label: string;
  icon: MaterialIconName;
  /**
   * The category's single colour. Tints are derived from it so a new category
   * only needs one value to slot in coherently.
   */
  hue: string;
  /** A short, human phrase — "for a movie", "for dinner". */
  phrase: string;
}

export const ACTIVITY_CATEGORIES: readonly ActivityCategory[] = [
  'MOVIE',
  'DINNER',
  'COFFEE',
  'SHOPPING',
  'WALK',
  'EVENT',
  'TRAVEL',
  'SPORTS',
  'CONCERT',
  'STUDY',
  'GAMING',
  'OTHER',
];

const CATEGORY_META: Record<ActivityCategory, CategoryMeta> = {
  MOVIE: { label: 'Movie', icon: 'local-movies', hue: '#4B5BA6', phrase: 'for a movie' },
  DINNER: { label: 'Dinner', icon: 'restaurant', hue: '#C0603A', phrase: 'for dinner' },
  COFFEE: { label: 'Coffee', icon: 'local-cafe', hue: '#8A5A3B', phrase: 'for coffee' },
  SHOPPING: { label: 'Shopping', icon: 'shopping-bag', hue: '#8C4A70', phrase: 'to go shopping' },
  WALK: { label: 'Walk', icon: 'directions-walk', hue: '#2F7A5E', phrase: 'for a walk' },
  EVENT: { label: 'Event', icon: 'celebration', hue: '#B0821F', phrase: 'for an event' },
  TRAVEL: { label: 'Travel', icon: 'luggage', hue: '#2B7683', phrase: 'to travel' },
  SPORTS: { label: 'Sports', icon: 'sports-tennis', hue: '#5E7A2A', phrase: 'to play' },
  CONCERT: { label: 'Concert', icon: 'music-note', hue: '#A43F5F', phrase: 'for a gig' },
  STUDY: { label: 'Study', icon: 'menu-book', hue: '#4C6274', phrase: 'to study' },
  GAMING: { label: 'Gaming', icon: 'sports-esports', hue: '#6A4FA3', phrase: 'to game' },
  OTHER: { label: 'Something else', icon: 'auto-awesome', hue: '#5D6A65', phrase: 'to hang out' },
};

export function categoryMeta(category: ActivityCategory): CategoryMeta {
  return CATEGORY_META[category];
}

export function categoryFromWire(value: unknown): ActivityCategory {
  return typeof value === 'string' && value in CATEGORY_META
    ? (value as ActivityCategory)
    : 'OTHER';
}

/** A soft background that stays legible in both themes. */
export function categoryTint(category: ActivityCategory, isDark: boolean): string {
  const hex = CATEGORY_META[category].hue.replace('#', '');
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${isDark ? 0.2 : 0.1})`;
}

/** The hue lifted just enough to read on a dark canvas. */
export function categoryForeground(category: ActivityCategory, isDark: boolean): string {
  const hue = CATEGORY_META[category].hue;
  if (!isDark) return hue;
  return liftForDark(hue);
}

/** Re-lights a hue to lightness 0.68 / saturation 0.52, as the Dart original did. */
function liftForDark(hex: string): string {
  const value = hex.replace('#', '');
  const r = parseInt(value.slice(0, 2), 16) / 255;
  const g = parseInt(value.slice(2, 4), 16) / 255;
  const b = parseInt(value.slice(4, 6), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let hueDeg = 0;
  if (max !== min) {
    const delta = max - min;
    if (max === r) hueDeg = ((g - b) / delta) % 6;
    else if (max === g) hueDeg = (b - r) / delta + 2;
    else hueDeg = (r - g) / delta + 4;
    hueDeg *= 60;
    if (hueDeg < 0) hueDeg += 360;
  }

  return hslToHex(hueDeg, 0.52, 0.68);
}

function hslToHex(h: number, s: number, l: number): string {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;

  let rgb: [number, number, number];
  if (h < 60) rgb = [c, x, 0];
  else if (h < 120) rgb = [x, c, 0];
  else if (h < 180) rgb = [0, c, x];
  else if (h < 240) rgb = [0, x, c];
  else if (h < 300) rgb = [x, 0, c];
  else rgb = [c, 0, x];

  const toHex = (v: number) =>
    Math.round((v + m) * 255)
      .toString(16)
      .padStart(2, '0');
  return `#${toHex(rgb[0])}${toHex(rgb[1])}${toHex(rgb[2])}`;
}

export type AvailabilitySlot = 'TONIGHT' | 'TOMORROW' | 'THIS_WEEK' | 'WEEKEND' | 'FLEXIBLE';

export const AVAILABILITY_SLOTS: readonly AvailabilitySlot[] = [
  'TONIGHT',
  'TOMORROW',
  'THIS_WEEK',
  'WEEKEND',
  'FLEXIBLE',
];

const AVAILABILITY_LABELS: Record<AvailabilitySlot, string> = {
  TONIGHT: 'Tonight',
  TOMORROW: 'Tomorrow',
  THIS_WEEK: 'This week',
  WEEKEND: 'Weekend',
  FLEXIBLE: 'Flexible',
};

export const availabilityLabel = (slot: AvailabilitySlot) => AVAILABILITY_LABELS[slot];

export function availabilityFromWire(value: unknown): AvailabilitySlot {
  return typeof value === 'string' && value in AVAILABILITY_LABELS
    ? (value as AvailabilitySlot)
    : 'FLEXIBLE';
}

export type Gender = 'MALE' | 'FEMALE' | 'NON_BINARY' | 'OTHER';

export const GENDERS: readonly Gender[] = ['MALE', 'FEMALE', 'NON_BINARY', 'OTHER'];

const GENDER_LABELS: Record<Gender, string> = {
  MALE: 'Man',
  FEMALE: 'Woman',
  NON_BINARY: 'Non-binary',
  OTHER: 'Prefer not to say',
};

export const genderLabel = (gender: Gender) => GENDER_LABELS[gender];

export function genderFromWire(value: unknown): Gender {
  return typeof value === 'string' && value in GENDER_LABELS ? (value as Gender) : 'OTHER';
}

export type GenderPreference = 'ANYONE' | 'MALE' | 'FEMALE';

export const GENDER_PREFERENCES: readonly GenderPreference[] = ['ANYONE', 'MALE', 'FEMALE'];

const GENDER_PREFERENCE_LABELS: Record<GenderPreference, string> = {
  ANYONE: 'Anyone',
  MALE: 'Men',
  FEMALE: 'Women',
};

export const genderPreferenceLabel = (value: GenderPreference) => GENDER_PREFERENCE_LABELS[value];

export function genderPreferenceFromWire(value: unknown): GenderPreference {
  return typeof value === 'string' && value in GENDER_PREFERENCE_LABELS
    ? (value as GenderPreference)
    : 'ANYONE';
}

export type InvitationStatus = 'PENDING' | 'ACCEPTED' | 'DECLINED' | 'CANCELLED' | 'EXPIRED';

const INVITATION_STATUS_LABELS: Record<InvitationStatus, string> = {
  PENDING: 'Waiting',
  ACCEPTED: 'Accepted',
  DECLINED: 'Declined',
  CANCELLED: 'Withdrawn',
  EXPIRED: 'Expired',
};

export const invitationStatusLabel = (status: InvitationStatus) =>
  INVITATION_STATUS_LABELS[status];

export const isInvitationOpen = (status: InvitationStatus) => status === 'PENDING';

export function invitationStatusFromWire(value: unknown): InvitationStatus {
  return typeof value === 'string' && value in INVITATION_STATUS_LABELS
    ? (value as InvitationStatus)
    : 'PENDING';
}

export type VerificationStatus = 'UNVERIFIED' | 'PENDING' | 'VERIFIED';

export function verificationFromWire(value: unknown): VerificationStatus {
  return value === 'VERIFIED' || value === 'PENDING' || value === 'UNVERIFIED'
    ? value
    : 'UNVERIFIED';
}

export const isVerified = (status: VerificationStatus) => status === 'VERIFIED';

export type AppNotificationType =
  | 'INVITATION_RECEIVED'
  | 'INVITATION_ACCEPTED'
  | 'INVITATION_DECLINED'
  | 'MESSAGE_RECEIVED'
  | 'ACTIVITY_REMINDER'
  | 'SYSTEM';

const NOTIFICATION_ICONS: Record<AppNotificationType, MaterialIconName> = {
  INVITATION_RECEIVED: 'mail-outline',
  INVITATION_ACCEPTED: 'check-circle-outline',
  INVITATION_DECLINED: 'do-not-disturb-alt',
  MESSAGE_RECEIVED: 'chat-bubble-outline',
  ACTIVITY_REMINDER: 'schedule',
  SYSTEM: 'info-outline',
};

export const notificationIcon = (type: AppNotificationType) => NOTIFICATION_ICONS[type];

export function notificationTypeFromWire(value: unknown): AppNotificationType {
  return typeof value === 'string' && value in NOTIFICATION_ICONS
    ? (value as AppNotificationType)
    : 'SYSTEM';
}
