import {
  categoryFromWire,
  invitationStatusFromWire,
  type ActivityCategory,
  type InvitationStatus,
} from './enums';
import { categoryMeta } from './enums';
import { parseActivity, type Activity } from './activity';
import { asDate, asInt, asObject, asOptionalString, asString, type Json } from './json';
import { parseProfile, type Profile } from './profile';

export type InvitationDirection = 'received' | 'sent';

export interface Invitation {
  id: string;
  direction: InvitationDirection;
  status: InvitationStatus;
  message: string;
  category: ActivityCategory | null;
  proposedAt: Date | null;
  locationName: string | null;
  createdAt: Date;
  respondedAt: Date | null;
  counterpart: Profile;
  activity: Activity | null;
  conversationId: string | null;
}

export const isReceived = (invitation: Pick<Invitation, 'direction'>) =>
  invitation.direction === 'received';

export const resolvedCategory = (
  invitation: Pick<Invitation, 'category' | 'activity'>,
): ActivityCategory => invitation.category ?? invitation.activity?.category ?? 'OTHER';

export const headline = (invitation: Pick<Invitation, 'category' | 'activity'>): string =>
  invitation.activity?.title ??
  `Up for something ${categoryMeta(resolvedCategory(invitation)).phrase}?`;

export function parseInvitation(json: Json): Invitation {
  return {
    id: asString(json.id),
    direction: json.direction === 'sent' ? 'sent' : 'received',
    status: invitationStatusFromWire(json.status),
    message: asString(json.message),
    category:
      json.category === null || json.category === undefined
        ? null
        : categoryFromWire(json.category),
    proposedAt: asDate(json.proposedAt),
    locationName: asOptionalString(json.locationName),
    createdAt: asDate(json.createdAt) ?? new Date(),
    respondedAt: asDate(json.respondedAt),
    counterpart: parseProfile(asObject(json.counterpart)),
    activity:
      json.activity === null || json.activity === undefined
        ? null
        : parseActivity(asObject(json.activity)),
    conversationId: asOptionalString(json.conversationId),
  };
}

export interface InvitationCounts {
  pendingReceived: number;
  pendingSent: number;
  accepted: number;
}

export const EMPTY_INVITATION_COUNTS: InvitationCounts = {
  pendingReceived: 0,
  pendingSent: 0,
  accepted: 0,
};

export function parseInvitationCounts(json: Json): InvitationCounts {
  return {
    pendingReceived: asInt(json.pendingReceived),
    pendingSent: asInt(json.pendingSent),
    accepted: asInt(json.accepted),
  };
}
