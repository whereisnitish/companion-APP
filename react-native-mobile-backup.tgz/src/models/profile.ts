import {
  availabilityFromWire,
  categoryFromWire,
  genderFromWire,
  verificationFromWire,
  type ActivityCategory,
  type AvailabilitySlot,
  type Gender,
  type VerificationStatus,
} from './enums';
import {
  asBool,
  asDate,
  asDouble,
  asInt,
  asObject,
  asOptionalDouble,
  asOptionalString,
  asString,
  asStrings,
  parseList,
  type Json,
} from './json';

export interface Interest {
  slug: string;
  label: string;
  emoji: string;
}

export const parseInterest = (json: Json): Interest => ({
  slug: asString(json.slug),
  label: asString(json.label),
  emoji: asString(json.emoji),
});

/** Somebody as everybody else sees them. */
export interface Profile {
  id: string;
  displayName: string;
  age: number | null;
  gender: Gender;
  bio: string;
  occupation: string | null;
  city: string;
  area: string | null;
  avatarUrl: string | null;
  photos: string[];
  interests: Interest[];
  preferredActivities: ActivityCategory[];
  availability: AvailabilitySlot[];
  verification: VerificationStatus;
  ratingAverage: number;
  ratingCount: number;
  distanceKm: number | null;
  isOnline: boolean;
  lastActiveAt: Date | null;
}

/** The first name only — the interface addresses people, it does not file them. */
export const firstName = (profile: Pick<Profile, 'displayName'>): string =>
  profile.displayName.split(' ')[0] ?? profile.displayName;

/** Every image we can show, avatar first, de-duplicated. */
export const gallery = (profile: Pick<Profile, 'avatarUrl' | 'photos'>): string[] => {
  const all = profile.avatarUrl ? [profile.avatarUrl, ...profile.photos] : [...profile.photos];
  return Array.from(new Set(all));
};

export function parseProfile(json: Json): Profile {
  const rating = asObject(json.rating);

  return {
    id: asString(json.id),
    displayName: asString(json.displayName, 'Someone'),
    age: json.age === null || json.age === undefined ? null : asInt(json.age),
    gender: genderFromWire(json.gender),
    bio: asString(json.bio),
    occupation: asOptionalString(json.occupation),
    city: asString(json.city),
    area: asOptionalString(json.area),
    avatarUrl: asOptionalString(json.avatarUrl),
    photos: asStrings(json.photos),
    interests: parseList(json.interests, parseInterest),
    preferredActivities: asStrings(json.preferredActivities).map(categoryFromWire),
    availability: asStrings(json.availability).map(availabilityFromWire),
    verification: verificationFromWire(json.verification),
    ratingAverage: asDouble(rating.average),
    ratingCount: asInt(rating.count),
    distanceKm: asOptionalDouble(json.distanceKm),
    isOnline: asBool(json.isOnline),
    lastActiveAt: asDate(json.lastActiveAt),
  };
}

/** The signed-in user: everything in `Profile` plus what only they may see. */
export interface CurrentUser extends Profile {
  email: string | null;
  phone: string | null;
  birthDate: Date | null;
  latitude: number | null;
  longitude: number | null;
  isDiscoverable: boolean;
  showDistance: boolean;
  showAge: boolean;
  isProfileComplete: boolean;
  createdAt: Date | null;
}

export function parseCurrentUser(json: Json): CurrentUser {
  return {
    ...parseProfile(json),
    email: asOptionalString(json.email),
    phone: asOptionalString(json.phone),
    birthDate: asDate(json.birthDate),
    latitude: asOptionalDouble(json.latitude),
    longitude: asOptionalDouble(json.longitude),
    isDiscoverable: asBool(json.isDiscoverable, true),
    showDistance: asBool(json.showDistance, true),
    showAge: asBool(json.showAge, true),
    isProfileComplete: asBool(json.isProfileComplete),
    createdAt: asDate(json.createdAt),
  };
}
