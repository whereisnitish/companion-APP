import { parseActivityContext, type ActivityContext } from './activity';
import { asDate, asInt, asObject, asString, type Json } from './json';
import { parseProfile, type Profile } from './profile';

export interface Conversation {
  id: string;
  lastMessageAt: Date;
  lastMessagePreview: string;
  unreadCount: number;
  participant: Profile;
  activity: ActivityContext | null;
}

export function parseConversation(json: Json): Conversation {
  return {
    id: asString(json.id),
    lastMessageAt: asDate(json.lastMessageAt) ?? new Date(),
    lastMessagePreview: asString(json.lastMessagePreview),
    unreadCount: asInt(json.unreadCount),
    participant: parseProfile(asObject(json.participant)),
    activity:
      json.activity === null || json.activity === undefined
        ? null
        : parseActivityContext(asObject(json.activity)),
  };
}

export type MessageKind = 'text' | 'system';

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  kind: MessageKind;
  createdAt: Date;
  readAt: Date | null;
  isMine: boolean;
  /** Set on the optimistic copy shown the instant you hit send. */
  isPending: boolean;
  hasFailed: boolean;
}

export const isSystem = (message: Pick<Message, 'kind'>) => message.kind === 'system';
export const isRead = (message: Pick<Message, 'readAt'>) => message.readAt !== null;

export function parseMessage(json: Json): Message {
  return {
    id: asString(json.id),
    conversationId: asString(json.conversationId),
    senderId: asString(json.senderId),
    body: asString(json.body),
    kind: json.type === 'SYSTEM' ? 'system' : 'text',
    createdAt: asDate(json.createdAt) ?? new Date(),
    readAt: asDate(json.readAt),
    isMine: json.isMine === true,
    isPending: false,
    hasFailed: false,
  };
}
