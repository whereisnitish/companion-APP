import { notificationTypeFromWire, type AppNotificationType } from './enums';
import { asDate, asObject, asString, type Json } from './json';

export interface AppNotification {
  id: string;
  type: AppNotificationType;
  title: string;
  body: string;
  data: Record<string, unknown>;
  readAt: Date | null;
  createdAt: Date;
}

export const isUnread = (notification: Pick<AppNotification, 'readAt'>) =>
  notification.readAt === null;

export function parseNotification(json: Json): AppNotification {
  return {
    id: asString(json.id),
    type: notificationTypeFromWire(json.type),
    title: asString(json.title),
    body: asString(json.body),
    data: asObject(json.data),
    readAt: asDate(json.readAt),
    createdAt: asDate(json.createdAt) ?? new Date(),
  };
}
