import axios, { type AxiosError } from 'axios';

/**
 * Every failure the UI can render, in one type.
 *
 * The backend already writes its `message` for humans, so screens can show it
 * verbatim; `fieldErrors` maps straight onto form fields.
 */
export class ApiException extends Error {
  readonly code: string;
  readonly statusCode?: number;
  readonly fieldErrors: Record<string, string>;

  constructor(params: {
    message: string;
    code: string;
    statusCode?: number;
    fieldErrors?: Record<string, string>;
  }) {
    super(params.message);
    this.name = 'ApiException';
    this.code = params.code;
    this.statusCode = params.statusCode;
    this.fieldErrors = params.fieldErrors ?? {};
  }

  get isUnauthorized(): boolean {
    return this.statusCode === 401;
  }

  get isNetworkError(): boolean {
    return this.code === 'NETWORK_ERROR' || this.code === 'TIMEOUT';
  }

  get isNotFound(): boolean {
    return this.statusCode === 404;
  }

  /** A short line for an inline error state — never a stack trace. */
  get shortMessage(): string {
    switch (this.code) {
      case 'NETWORK_ERROR':
        return 'No connection';
      case 'TIMEOUT':
        return 'That took too long';
      default:
        return this.message;
    }
  }

  static fromAxiosError(error: unknown): ApiException {
    if (error instanceof ApiException) return error;

    if (!axios.isAxiosError(error)) {
      return new ApiException({
        message: 'Something went wrong. Please try again.',
        code: 'UNKNOWN',
      });
    }

    const axiosError = error as AxiosError;

    if (axiosError.code === 'ECONNABORTED' || axiosError.code === 'ETIMEDOUT') {
      return new ApiException({
        message: 'The server is taking too long to respond. Try again in a moment.',
        code: 'TIMEOUT',
      });
    }

    if (axios.isCancel(error)) {
      return new ApiException({ message: 'Request cancelled.', code: 'CANCELLED' });
    }

    if (!axiosError.response) {
      return new ApiException({
        message: 'We could not reach the server. Check your connection and try again.',
        code: 'NETWORK_ERROR',
      });
    }

    return ApiException.fromResponse(axiosError.response.status, axiosError.response.data);
  }

  /** Builds from a `{ error: { code, message, details } }` envelope. */
  static fromResponse(status: number, data: unknown): ApiException {
    if (data && typeof data === 'object' && 'error' in data) {
      const envelope = (data as { error: unknown }).error;
      if (envelope && typeof envelope === 'object') {
        const shaped = envelope as { message?: string; code?: string; details?: unknown };
        const details = shaped.details;
        const fieldErrors: Record<string, string> = {};
        if (details && typeof details === 'object' && !Array.isArray(details)) {
          for (const [key, value] of Object.entries(details as Record<string, unknown>)) {
            fieldErrors[key] = String(value);
          }
        }
        return new ApiException({
          message: shaped.message ?? 'Something went wrong.',
          code: shaped.code ?? 'UNKNOWN',
          statusCode: status,
          fieldErrors,
        });
      }
    }

    return new ApiException({
      message: 'Something went wrong. Please try again.',
      code: 'UNKNOWN',
      statusCode: status,
    });
  }
}
