import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from 'axios';

import { AppConfig } from '../config/appConfig';
import type { TokenStorage } from '../storage/tokenStorage';
import { ApiException } from './apiException';

export type Json = Record<string, unknown>;

/** The `{ data, meta }` envelope every endpoint returns. */
export interface Envelope {
  data?: unknown;
  meta?: Json;
}

export function dataObject(envelope: Envelope): Json {
  const data = envelope.data;
  return data && typeof data === 'object' && !Array.isArray(data) ? (data as Json) : {};
}

export function dataList(envelope: Envelope): Json[] {
  const data = envelope.data;
  if (!Array.isArray(data)) return [];
  return data.filter((item): item is Json => !!item && typeof item === 'object');
}

export function meta(envelope: Envelope): Json {
  return envelope.meta ?? {};
}

interface SendOptions extends AxiosRequestConfig {
  skipAuth?: boolean;
}

/**
 * Thin, typed wrapper over axios.
 *
 * Two responsibilities beyond plain HTTP:
 *   1. attach the access token to every call;
 *   2. when one 401s, refresh once and replay — transparently, and only once
 *      even if ten requests fail at the same moment.
 */
export class ApiClient {
  private readonly http: AxiosInstance;
  private readonly tokens: TokenStorage;
  private refreshInFlight: Promise<boolean> | null = null;

  /** Invoked when a refresh fails — the session is gone and the app must sign out. */
  onSessionExpired?: () => void;

  constructor(tokenStorage: TokenStorage, instance?: AxiosInstance) {
    this.tokens = tokenStorage;
    this.http =
      instance ??
      axios.create({
        baseURL: AppConfig.apiRoot,
        timeout: AppConfig.receiveTimeout,
        headers: { 'Content-Type': 'application/json' },
        // We inspect status codes ourselves so the interceptor can refresh.
        validateStatus: (status) => status < 500,
      });

    this.http.interceptors.request.use((config) => {
      const token = this.tokens.cachedAccessToken;
      if (token && !(config as SendOptions).skipAuth) {
        config.headers.set('authorization', `Bearer ${token}`);
      }
      return config;
    });
  }

  get(path: string, query?: Json, signal?: AbortSignal): Promise<Envelope> {
    return this.send({ method: 'get', url: path, params: query, signal });
  }

  post(path: string, body?: unknown, options?: { skipAuth?: boolean; signal?: AbortSignal }): Promise<Envelope> {
    return this.send({
      method: 'post',
      url: path,
      data: body,
      skipAuth: options?.skipAuth,
      signal: options?.signal,
    });
  }

  put(path: string, body?: unknown): Promise<Envelope> {
    return this.send({ method: 'put', url: path, data: body });
  }

  delete(path: string, body?: unknown): Promise<Envelope> {
    return this.send({ method: 'delete', url: path, data: body });
  }

  /** Runs the request, refreshing the session once on a 401 before giving up. */
  private async send(options: SendOptions, allowRetry = true): Promise<Envelope> {
    let response: AxiosResponse<unknown>;
    try {
      response = await this.http.request<unknown>(options);
    } catch (error) {
      throw ApiException.fromAxiosError(error);
    }

    const status = response.status;

    if (status === 401 && allowRetry) {
      const refreshed = await this.refreshSession();
      if (refreshed) return this.send(options, false);
    }

    if (status >= 400) {
      throw ApiException.fromResponse(status, response.data);
    }

    const data = response.data;
    if (data && typeof data === 'object' && !Array.isArray(data)) return data as Envelope;
    return { data };
  }

  /** Coalesces concurrent refreshes into a single network call. */
  private refreshSession(): Promise<boolean> {
    const inFlight = this.refreshInFlight;
    if (inFlight) return inFlight;

    const attempt = (async (): Promise<boolean> => {
      try {
        const refreshToken = await this.tokens.readRefreshToken();
        if (!refreshToken) {
          this.onSessionExpired?.();
          return false;
        }

        const response = await this.http.request<unknown>({
          method: 'post',
          url: '/auth/refresh',
          data: { refreshToken },
          skipAuth: true,
        } as SendOptions);

        const body = response.data;
        if (response.status === 200 && body && typeof body === 'object') {
          const session = dataObject(body as Envelope);
          const accessToken = session.accessToken;
          const nextRefresh = session.refreshToken;
          if (typeof accessToken === 'string' && typeof nextRefresh === 'string') {
            await this.tokens.save({ accessToken, refreshToken: nextRefresh });
            return true;
          }
        }

        await this.tokens.clear();
        this.onSessionExpired?.();
        return false;
      } catch {
        await this.tokens.clear();
        this.onSessionExpired?.();
        return false;
      } finally {
        this.refreshInFlight = null;
      }
    })();

    this.refreshInFlight = attempt;
    return attempt;
  }
}
