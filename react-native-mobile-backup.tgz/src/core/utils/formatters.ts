import { format as formatDate } from 'date-fns';

/**
 * Every date, time and distance string in the product comes from here, so the
 * same moment never reads two different ways on two screens.
 */

/** Calendar-day difference, ignoring the clock. */
function dayDelta(from: Date, to: Date): number {
  const a = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  const b = new Date(to.getFullYear(), to.getMonth(), to.getDate());
  return Math.round((b.getTime() - a.getTime()) / 86_400_000);
}

const time = (when: Date) => formatDate(when, 'h:mm a');

export const Format = {
  /** "Tonight · 8:30 PM", "Tomorrow · 7:00 AM", "Saturday, 8:30 PM". */
  whenLabel(when: Date): string {
    const days = dayDelta(new Date(), when);

    if (days === 0) {
      const prefix = when.getHours() >= 17 ? 'Tonight' : 'Today';
      return `${prefix} · ${time(when)}`;
    }
    if (days === 1) return `Tomorrow · ${time(when)}`;
    if (days > 1 && days < 7) return formatDate(when, 'EEEE, h:mm a');
    return formatDate(when, 'EEE d MMM, h:mm a');
  },

  /** The compact form used inside dense cards. */
  whenShort(when: Date): string {
    const days = dayDelta(new Date(), when);
    if (days === 0) return time(when);
    if (days === 1) return `Tmrw ${time(when)}`;
    if (days > 1 && days < 7) return formatDate(when, 'EEE h:mm a');
    return `${formatDate(when, 'd MMM')} · ${time(when)}`;
  },

  time,

  fullDate: (when: Date) => formatDate(when, 'd MMMM yyyy'),

  messageDay(when: Date): string {
    const days = dayDelta(new Date(), when);
    if (days === 0) return 'Today';
    if (days === -1) return 'Yesterday';
    return formatDate(when, 'EEEE, d MMMM');
  },

  /** "just now", "12m", "3h", "2d", then a date. */
  relative(when: Date): string {
    const elapsedMs = Date.now() - when.getTime();
    const seconds = Math.floor(elapsedMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (seconds < 60) return 'just now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return formatDate(when, 'd MMM');
  },

  /** "Active now", "Active 2h ago". */
  lastSeen(when: Date | null, isOnline: boolean): string {
    if (isOnline) return 'Active now';
    if (!when) return 'Offline';

    const elapsedMs = Date.now() - when.getTime();
    const minutes = Math.floor(elapsedMs / 60_000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 5) return 'Active just now';
    if (minutes < 60) return `Active ${minutes}m ago`;
    if (hours < 24) return `Active ${hours}h ago`;
    if (days < 7) return `Active ${days}d ago`;
    return 'Active recently';
  },

  distance(km: number | null | undefined): string {
    if (km === null || km === undefined) return '';
    if (km < 1) return `${Math.round(km * 1000)} m away`;
    return `${km.toFixed(km < 10 ? 1 : 0)} km away`;
  },

  distanceShort(km: number | null | undefined): string {
    if (km === null || km === undefined) return '';
    if (km < 1) return `${Math.round(km * 1000)}m`;
    return `${km.toFixed(km < 10 ? 1 : 0)}km`;
  },

  initials(name: string): string {
    const parts = name.trim().split(/\s+/).filter((part) => part.length > 0);
    const first = parts[0];
    if (!first) return '?';
    if (parts.length === 1) return first.slice(0, 1).toUpperCase();
    const last = parts[parts.length - 1] as string;
    return (first.slice(0, 1) + last.slice(0, 1)).toUpperCase();
  },
} as const;
