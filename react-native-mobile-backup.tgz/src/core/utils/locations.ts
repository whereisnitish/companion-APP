/**
 * A small, hand-curated place list.
 *
 * A real build would put a geocoder behind this; for the MVP a fixed list of
 * neighbourhoods keeps discovery distances meaningful without asking for a
 * location permission on the very first screen, and without a maps API key.
 */
export interface Place {
  name: string;
  city: string;
  latitude: number;
  longitude: number;
}

export const DEFAULT_CITY = 'Bengaluru';

export const PLACES: readonly Place[] = [
  { name: 'Indiranagar', city: 'Bengaluru', latitude: 12.9784, longitude: 77.6408 },
  { name: 'Koramangala', city: 'Bengaluru', latitude: 12.9352, longitude: 77.6245 },
  { name: 'HSR Layout', city: 'Bengaluru', latitude: 12.9116, longitude: 77.6389 },
  { name: 'Jayanagar', city: 'Bengaluru', latitude: 12.925, longitude: 77.5938 },
  { name: 'Whitefield', city: 'Bengaluru', latitude: 12.9698, longitude: 77.75 },
  { name: 'MG Road', city: 'Bengaluru', latitude: 12.9756, longitude: 77.6068 },
  { name: 'Malleswaram', city: 'Bengaluru', latitude: 13.0035, longitude: 77.5647 },
  { name: 'JP Nagar', city: 'Bengaluru', latitude: 12.9063, longitude: 77.5857 },
  { name: 'Bellandur', city: 'Bengaluru', latitude: 12.926, longitude: 77.6762 },
  { name: 'Ulsoor', city: 'Bengaluru', latitude: 12.9822, longitude: 77.6222 },
  { name: 'Domlur', city: 'Bengaluru', latitude: 12.9611, longitude: 77.6387 },
  { name: 'Basavanagudi', city: 'Bengaluru', latitude: 12.9422, longitude: 77.5738 },
  { name: 'Hebbal', city: 'Bengaluru', latitude: 13.0358, longitude: 77.597 },
  { name: 'Frazer Town', city: 'Bengaluru', latitude: 13.0983, longitude: 77.618 },
  { name: 'Rajajinagar', city: 'Bengaluru', latitude: 12.9982, longitude: 77.5525 },
  { name: 'Sarjapur Road', city: 'Bengaluru', latitude: 12.901, longitude: 77.6874 },
];

export const Places = {
  defaultCity: DEFAULT_CITY,
  all: PLACES,

  get fallback(): Place {
    return PLACES[0] as Place;
  },

  byName(name: string | null | undefined): Place | null {
    if (!name) return null;
    return PLACES.find((place) => place.name === name) ?? null;
  },

  search(query: string): readonly Place[] {
    const needle = query.trim().toLowerCase();
    if (needle.length === 0) return PLACES;
    return PLACES.filter((place) => place.name.toLowerCase().includes(needle));
  },
} as const;

/**
 * Portraits offered during profile setup.
 *
 * Photo *upload* needs object storage, which is out of scope for the MVP, so
 * the flow offers a curated set and accepts any image URL. The field on the
 * profile is already `avatarUrl`, so wiring an uploader later changes only
 * this picker.
 */
export const STOCK_PORTRAITS: readonly string[] = [
  'https://randomuser.me/api/portraits/women/68.jpg',
  'https://randomuser.me/api/portraits/men/32.jpg',
  'https://randomuser.me/api/portraits/women/44.jpg',
  'https://randomuser.me/api/portraits/men/75.jpg',
  'https://randomuser.me/api/portraits/women/26.jpg',
  'https://randomuser.me/api/portraits/men/12.jpg',
  'https://randomuser.me/api/portraits/women/9.jpg',
  'https://randomuser.me/api/portraits/men/45.jpg',
  'https://randomuser.me/api/portraits/women/55.jpg',
  'https://randomuser.me/api/portraits/men/64.jpg',
  'https://randomuser.me/api/portraits/women/17.jpg',
  'https://randomuser.me/api/portraits/men/83.jpg',
];
