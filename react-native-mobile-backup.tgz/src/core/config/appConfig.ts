import { Platform } from 'react-native';
import Constants from 'expo-constants';

/**
 * Build-time configuration.
 *
 * Override the host by setting `apiBaseUrl` under `expo.extra` in app.json, or
 * by exporting `EXPO_PUBLIC_API_BASE_URL` before `expo start`:
 *   EXPO_PUBLIC_API_BASE_URL=http://192.168.1.20:4000 npx expo start
 *
 * Without an override we guess sensibly: the Android emulator reaches the
 * host machine at 10.0.2.2, everything else at localhost.
 */
function resolveBaseUrl(): string {
  const fromEnv = process.env.EXPO_PUBLIC_API_BASE_URL;
  if (fromEnv && fromEnv.length > 0) return fromEnv;

  const fromExtra = Constants.expoConfig?.extra?.apiBaseUrl as string | undefined | null;
  if (fromExtra && fromExtra.length > 0) return fromExtra;

  // Running from Expo Go / a dev client on a real device: the packager host is
  // the developer's machine, which is also where the API is.
  const hostUri = Constants.expoConfig?.hostUri ?? Constants.expoGoConfig?.debuggerHost;
  if (hostUri) {
    const host = hostUri.split(':')[0];
    if (host && host !== 'localhost' && host !== '127.0.0.1') return `http://${host}:4000`;
  }

  if (Platform.OS === 'android') return 'http://10.0.2.2:4000';
  return 'http://localhost:4000';
}

export const AppConfig = {
  get apiBaseUrl(): string {
    return resolveBaseUrl();
  },

  get apiRoot(): string {
    return `${resolveBaseUrl()}/api`;
  },

  get websocketUrl(): string {
    return `${resolveBaseUrl().replace(/^http/, 'ws')}/ws`;
  },

  /** Milliseconds. */
  connectTimeout: 12_000,
  receiveTimeout: 20_000,

  appName: 'Companion',
  supportEmail: 'safety@companion.app',
} as const;
