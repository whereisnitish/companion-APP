import * as SecureStore from 'expo-secure-store';

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

const ACCESS_KEY = 'companion_access_token';
const REFRESH_KEY = 'companion_refresh_token';

/** Tokens live in the platform keychain / keystore, never in async storage. */
export class TokenStorage {
  /** Cached in memory so the request interceptor never awaits the keychain. */
  private _cachedAccessToken: string | null = null;

  get cachedAccessToken(): string | null {
    return this._cachedAccessToken;
  }

  async read(): Promise<AuthTokens | null> {
    const [access, refresh] = await Promise.all([
      SecureStore.getItemAsync(ACCESS_KEY),
      SecureStore.getItemAsync(REFRESH_KEY),
    ]);
    if (!access || !refresh) return null;
    this._cachedAccessToken = access;
    return { accessToken: access, refreshToken: refresh };
  }

  readRefreshToken(): Promise<string | null> {
    return SecureStore.getItemAsync(REFRESH_KEY);
  }

  async save(tokens: AuthTokens): Promise<void> {
    this._cachedAccessToken = tokens.accessToken;
    await Promise.all([
      SecureStore.setItemAsync(ACCESS_KEY, tokens.accessToken),
      SecureStore.setItemAsync(REFRESH_KEY, tokens.refreshToken),
    ]);
  }

  async clear(): Promise<void> {
    this._cachedAccessToken = null;
    await Promise.all([
      SecureStore.deleteItemAsync(ACCESS_KEY),
      SecureStore.deleteItemAsync(REFRESH_KEY),
    ]);
  }
}
