import { AppConfig } from '../config/appConfig';

/** A frame from the server. `type` drives everything downstream. */
export interface RealtimeEvent {
  type: string;
  conversationId?: string;
  payload: Record<string, unknown>;
}

function parseEvent(raw: unknown): RealtimeEvent | null {
  if (!raw || typeof raw !== 'object') return null;
  const json = raw as Record<string, unknown>;
  return {
    type: typeof json.type === 'string' ? json.type : 'unknown',
    conversationId: typeof json.conversationId === 'string' ? json.conversationId : undefined,
    payload:
      json.payload && typeof json.payload === 'object'
        ? (json.payload as Record<string, unknown>)
        : {},
  };
}

export type RealtimeListener = (event: RealtimeEvent) => void;

/**
 * One socket per signed-in session, shared by chat, invites and notifications.
 *
 * Reconnects with a capped backoff and never throws at its callers: realtime
 * is an enhancement, and everything it delivers is also reachable over REST.
 */
export class SocketClient {
  private socket: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private token: string | null = null;
  private attempt = 0;
  private disposed = false;
  private readonly listeners = new Set<RealtimeListener>();

  get isConnected(): boolean {
    return this.socket !== null && this.socket.readyState === WebSocket.OPEN;
  }

  /** Every feature subscribes here; the returned function unsubscribes. */
  subscribe(listener: RealtimeListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  connect(accessToken: string): void {
    if (this.disposed) return;
    this.token = accessToken;
    this.attempt = 0;
    this.open();
  }

  private open(): void {
    const token = this.token;
    if (!token || this.disposed) return;

    this.teardownSocket();

    try {
      const socket = new WebSocket(`${AppConfig.websocketUrl}?token=${token}`);
      this.socket = socket;

      socket.onmessage = (event: WebSocketMessageEvent) => {
        this.attempt = 0;
        if (typeof event.data !== 'string') return;
        try {
          const parsed = parseEvent(JSON.parse(event.data));
          if (parsed) this.emit(parsed);
        } catch {
          /* a malformed frame is not worth taking the socket down for */
        }
      };

      socket.onerror = () => this.scheduleReconnect();
      socket.onclose = () => this.scheduleReconnect();
    } catch {
      this.scheduleReconnect();
    }
  }

  private emit(event: RealtimeEvent): void {
    for (const listener of Array.from(this.listeners)) {
      try {
        listener(event);
      } catch {
        /* one bad listener must not stop the others */
      }
    }
  }

  private scheduleReconnect(): void {
    if (this.disposed || this.token === null) return;
    this.teardownSocket();

    this.attempt = Math.min(Math.max(this.attempt + 1, 1), 6);
    const delay = 500 * 2 ** (this.attempt - 1);
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => this.open(), delay);
  }

  send(frame: Record<string, unknown>): void {
    const socket = this.socket;
    if (!socket || socket.readyState !== WebSocket.OPEN) return;
    try {
      socket.send(JSON.stringify(frame));
    } catch {
      /* dropped frames are acceptable for typing indicators */
    }
  }

  sendTyping(conversationId: string, isTyping: boolean): void {
    this.send({ type: 'typing', conversationId, isTyping });
  }

  private teardownSocket(): void {
    const socket = this.socket;
    this.socket = null;
    if (!socket) return;
    // Detach first: closing a socket we are replacing must not trigger backoff.
    socket.onmessage = null;
    socket.onerror = null;
    socket.onclose = null;
    try {
      socket.close();
    } catch {
      /* already gone */
    }
  }

  disconnect(): void {
    this.token = null;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.teardownSocket();
  }

  dispose(): void {
    this.disposed = true;
    this.disconnect();
    this.listeners.clear();
  }
}
