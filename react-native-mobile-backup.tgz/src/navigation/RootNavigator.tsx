import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { ActivityDetailScreen } from '../features/activities/ActivityDetailScreen';
import { CreateActivityScreen } from '../features/activities/CreateActivityScreen';
import { SignInScreen } from '../features/auth/SignInScreen';
import { SignUpScreen } from '../features/auth/SignUpScreen';
import { WelcomeScreen } from '../features/auth/WelcomeScreen';
import { ChatScreen } from '../features/chat/ChatScreen';
import { ConversationsScreen } from '../features/chat/ConversationsScreen';
import { DiscoverScreen } from '../features/discover/DiscoverScreen';
import { PersonProfileScreen } from '../features/discover/PersonProfileScreen';
import { HomeScreen } from '../features/home/HomeScreen';
import { InvitationsScreen } from '../features/invitations/InvitationsScreen';
import { NotificationsScreen } from '../features/notifications/NotificationsScreen';
import { OnboardingScreen } from '../features/onboarding/OnboardingScreen';
import { SplashScreen } from '../features/onboarding/SplashScreen';
import { EditProfileScreen } from '../features/profile/EditProfileScreen';
import { MyProfileScreen } from '../features/profile/MyProfileScreen';
import { ProfileSetupScreen } from '../features/profile_setup/ProfileSetupScreen';
import { BlockedUsersScreen } from '../features/settings/BlockedUsersScreen';
import { GuidelinesScreen } from '../features/settings/GuidelinesScreen';
import { PrivacyScreen } from '../features/settings/PrivacyScreen';
import { SafetyScreen } from '../features/settings/SafetyScreen';
import { SettingsScreen } from '../features/settings/SettingsScreen';
import { AppTabBar } from '../features/shell/AppTabBar';
import { useAuthStore } from '../stores';
import type { RootStackParamList, TabParamList } from './types';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

/** The five tabs keep independent navigation stacks. */
function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      tabBar={(props) => <AppTabBar {...props} />}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Discover" component={DiscoverScreen} />
      <Tab.Screen name="Invites" component={InvitationsScreen} />
      <Tab.Screen name="Messages" component={ConversationsScreen} />
      <Tab.Screen name="Me" component={MyProfileScreen} />
    </Tab.Navigator>
  );
}

/**
 * The auth gate.
 *
 * go_router expressed this as a `redirect` that ran on every navigation; React
 * Navigation's idiom is to mount only the routes the current stage allows, so
 * an unreachable screen cannot be pushed in the first place.
 */
export function RootNavigator() {
  const stage = useAuthStore((state) => state.stage);

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {stage === 'loading' ? (
        <Stack.Screen name="Splash" component={SplashScreen} />
      ) : stage === 'onboarding' ? (
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      ) : stage === 'signedOut' ? (
        <>
          {/* Let people move freely between welcome / sign-in / sign-up. */}
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="SignIn" component={SignInScreen} />
          <Stack.Screen name="SignUp" component={SignUpScreen} />
        </>
      ) : stage === 'needsProfile' ? (
        <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
      ) : (
        <>
          <Stack.Screen name="Tabs" component={Tabs} />

          {/* Everything below covers the tab bar. */}
          <Stack.Screen name="PersonProfile" component={PersonProfileScreen} />
          <Stack.Screen name="ActivityDetail" component={ActivityDetailScreen} />
          <Stack.Screen name="Chat" component={ChatScreen} />
          <Stack.Screen
            name="CreateActivity"
            component={CreateActivityScreen}
            options={{ presentation: 'modal' }}
          />
          <Stack.Screen name="Notifications" component={NotificationsScreen} />
          <Stack.Screen name="EditProfile" component={EditProfileScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="Privacy" component={PrivacyScreen} />
          <Stack.Screen name="Safety" component={SafetyScreen} />
          <Stack.Screen name="Guidelines" component={GuidelinesScreen} />
          <Stack.Screen name="Blocked" component={BlockedUsersScreen} />
        </>
      )}
    </Stack.Navigator>
  );
}
