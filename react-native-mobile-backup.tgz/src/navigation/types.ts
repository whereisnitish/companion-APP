import type { NavigatorScreenParams } from '@react-navigation/native';

/** The five tabs keep independent navigation stacks. */
export type TabParamList = {
  Home: undefined;
  Discover: undefined;
  Invites: undefined;
  Messages: undefined;
  Me: undefined;
};

/** Everything below the tabs covers the tab bar. */
export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Welcome: undefined;
  SignIn: undefined;
  SignUp: undefined;
  ProfileSetup: undefined;

  Tabs: NavigatorScreenParams<TabParamList>;

  PersonProfile: { userId: string };
  CreateActivity: undefined;
  ActivityDetail: { activityId: string };
  Chat: { conversationId: string };
  Notifications: undefined;
  EditProfile: undefined;
  Settings: undefined;
  Privacy: undefined;
  Safety: undefined;
  Guidelines: undefined;
  Blocked: undefined;
};

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
