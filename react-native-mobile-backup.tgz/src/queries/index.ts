import { useQuery, type UseQueryResult } from '@tanstack/react-query';

import type { Activity } from '../models/activity';
import type { Conversation } from '../models/conversation';
import type { HomeFeed } from '../models/homeFeed';
import type { Invitation, InvitationCounts } from '../models/invitation';
import type { Interest, Profile } from '../models/profile';
import {
  activityService,
  conversationService,
  discoveryService,
  invitationService,
  notificationService,
  profileService,
} from '../services';
import type { DiscoveryFilters } from '../services/discoveryService';
import type { NotificationPage } from '../services/notificationService';
import { queryKeys } from './keys';

// ------------------------------------------------------------------- home

/**
 * The home screen's single source. Cached so returning to the tab is instant;
 * `refetch` powers pull-to-refresh.
 */
export const useHomeFeed = (): UseQueryResult<HomeFeed> =>
  useQuery({ queryKey: queryKeys.homeFeed, queryFn: () => discoveryService.fetchHomeFeed() });

// --------------------------------------------------------------- discover

export const useDiscoverPeople = (filters: DiscoveryFilters): UseQueryResult<Profile[]> =>
  useQuery({
    queryKey: queryKeys.discoverPeople(filters),
    queryFn: async () => (await discoveryService.discoverPeople(filters, 1, 30)).items,
  });

export const useDiscoverActivities = (filters: DiscoveryFilters): UseQueryResult<Activity[]> =>
  useQuery({
    queryKey: queryKeys.discoverActivities(filters),
    queryFn: async () => (await discoveryService.discoverActivities(filters, 1, 30)).items,
  });

/** The interest catalog, fetched once and reused by filters and profile setup. */
export const useInterestCatalog = (): UseQueryResult<Interest[]> =>
  useQuery({
    queryKey: queryKeys.interestCatalog,
    queryFn: () => profileService.fetchInterests(),
    staleTime: 60 * 60 * 1000,
  });

// ------------------------------------------------------------- invitations

export const useReceivedInvitations = (): UseQueryResult<Invitation[]> =>
  useQuery({
    queryKey: queryKeys.receivedInvitations,
    queryFn: () => invitationService.list('received'),
  });

export const useSentInvitations = (): UseQueryResult<Invitation[]> =>
  useQuery({
    queryKey: queryKeys.sentInvitations,
    queryFn: () => invitationService.list('sent'),
  });

export const useInvitationCounts = (): UseQueryResult<InvitationCounts> =>
  useQuery({ queryKey: queryKeys.invitationCounts, queryFn: () => invitationService.counts() });

// ------------------------------------------------------------ conversations

/**
 * The inbox. Refetched on every inbound message so unread counts and ordering
 * change without the user pulling to refresh.
 */
export const useConversations = (): UseQueryResult<Conversation[]> =>
  useQuery({ queryKey: queryKeys.conversations, queryFn: () => conversationService.list() });

export const useConversationById = (conversationId: string): UseQueryResult<Conversation> =>
  useQuery({
    queryKey: queryKeys.conversationById(conversationId),
    queryFn: () => conversationService.fetch(conversationId),
    enabled: conversationId.length > 0,
  });

/** Total unread across every thread — the badge on the Messages tab. */
export function useUnreadMessages(): number {
  const { data } = useConversations();
  return (data ?? []).reduce((total, conversation) => total + conversation.unreadCount, 0);
}

// ----------------------------------------------------------- notifications

export const useNotifications = (): UseQueryResult<NotificationPage> =>
  useQuery({ queryKey: queryKeys.notifications, queryFn: () => notificationService.list() });

export function useUnreadNotifications(): number {
  const { data } = useNotifications();
  return data?.unreadCount ?? 0;
}

// ------------------------------------------------------------- my activity

export const useMyActivities = (): UseQueryResult<Activity[]> =>
  useQuery({ queryKey: queryKeys.myActivities, queryFn: () => activityService.list() });

/** A single person's public profile, cached per id for the duration of a visit. */
export const useProfileById = (userId: string): UseQueryResult<Profile> =>
  useQuery({
    queryKey: queryKeys.profileById(userId),
    queryFn: () => profileService.fetchProfile(userId),
    enabled: userId.length > 0,
  });

export const useActivityById = (activityId: string): UseQueryResult<Activity> =>
  useQuery({
    queryKey: queryKeys.activityById(activityId),
    queryFn: () => activityService.fetch(activityId),
    enabled: activityId.length > 0,
  });

export { queryKeys } from './keys';
export { connectRealtimeToQueryCache, invalidateSocialGraph } from './realtimeBridge';
