import type { DiscoveryFilters } from '../services/discoveryService';

/** Every query key in one place, so invalidation is never guesswork. */
export const queryKeys = {
  homeFeed: ['homeFeed'] as const,

  discoverPeople: (filters: DiscoveryFilters) => ['discover', 'people', filters] as const,
  discoverActivities: (filters: DiscoveryFilters) => ['discover', 'activities', filters] as const,
  interestCatalog: ['catalog', 'interests'] as const,

  receivedInvitations: ['invitations', 'received'] as const,
  sentInvitations: ['invitations', 'sent'] as const,
  invitationCounts: ['invitations', 'counts'] as const,

  conversations: ['conversations'] as const,
  conversationById: (conversationId: string) => ['conversations', conversationId] as const,
  messages: (conversationId: string) => ['conversations', conversationId, 'messages'] as const,

  notifications: ['notifications'] as const,

  myActivities: ['activities', 'mine'] as const,
  profileById: (userId: string) => ['profile', userId] as const,
  activityById: (activityId: string) => ['activity', activityId] as const,
} as const;
