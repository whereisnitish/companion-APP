import type { QueryClient } from '@tanstack/react-query';

import type { RealtimeEvent } from '../core/realtime/socketClient';
import { socketClient } from '../services';
import { queryKeys } from './keys';

/**
 * Riverpod expressed this as a `ref.listen` inside each provider; with a query
 * cache the mapping is better stated once, in one table: an event type on the
 * left, the queries it invalidates on the right.
 */
const INVALIDATIONS: Record<string, readonly (readonly unknown[])[]> = {
  'invitation:new': [
    queryKeys.homeFeed,
    queryKeys.receivedInvitations,
    queryKeys.invitationCounts,
  ],
  'invitation:updated': [
    queryKeys.homeFeed,
    queryKeys.sentInvitations,
    queryKeys.invitationCounts,
  ],
  'message:new': [queryKeys.conversations],
  'message:read': [queryKeys.conversations],
  notification: [queryKeys.notifications],
};

/**
 * Wires the socket into the query cache. Returns an unsubscribe function.
 *
 * Message *bodies* are not invalidated here — the chat store appends inbound
 * frames straight onto its list, so a refetch would only cause a flicker.
 */
export function connectRealtimeToQueryCache(client: QueryClient): () => void {
  return socketClient.subscribe((event: RealtimeEvent) => {
    const keys = INVALIDATIONS[event.type];
    if (!keys) return;
    for (const queryKey of keys) {
      void client.invalidateQueries({ queryKey });
    }
  });
}

/**
 * Refreshes everything the shell shows after a mutation somewhere else —
 * accepting an invitation touches the home feed, the invites list and the inbox.
 */
export function invalidateSocialGraph(client: QueryClient): void {
  void client.invalidateQueries({ queryKey: queryKeys.homeFeed });
  void client.invalidateQueries({ queryKey: queryKeys.receivedInvitations });
  void client.invalidateQueries({ queryKey: queryKeys.sentInvitations });
  void client.invalidateQueries({ queryKey: queryKeys.invitationCounts });
  void client.invalidateQueries({ queryKey: queryKeys.conversations });
}
