import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppButton,
  AppIconButton,
  CategoryBadge,
  ConfirmSheet,
  Entrance,
  ErrorStateView,
  PressEffect,
  Shimmer,
  SkeletonBox,
  VerifiedBadge,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Format } from '../../core/utils/formatters';
import { isOpen, spotsLeft, type Activity } from '../../models/activity';
import {
  categoryForeground,
  categoryMeta,
  categoryTint,
  genderPreferenceLabel,
  isVerified,
  type MaterialIconName,
} from '../../models/enums';
import { firstName } from '../../models/profile';
import type { RootStackParamList } from '../../navigation/types';
import { invalidateSocialGraph, queryKeys, useActivityById } from '../../queries';
import { activityService } from '../../services';
import { useDiscoverStore } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { useInviteSheet } from '../invitations/InviteSheet';

type Navigation = NativeStackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'ActivityDetail'>;

/**
 * One plan, in full.
 *
 * The header is coloured by the category so the screen announces what kind of
 * evening this is before a word is read. Everything else answers the four
 * questions that decide a yes: when, where, who with, and who they want.
 */
export function ActivityDetailScreen({ route }: { route: Route }) {
  const { colors } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const { activityId } = route.params;

  const { data: activity, isPending, error, refetch } = useActivityById(activityId);

  if (isPending) return <DetailSkeleton />;

  if (error || !activity) {
    return (
      <View style={[styles.container, { backgroundColor: colors.canvas, paddingTop: insets.top }]}>
        <View style={styles.backRow}>
          <AppIconButton
            icon="arrow-back"
            onPress={() => navigation.goBack()}
            accessibilityLabel="Go back"
          />
        </View>
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      </View>
    );
  }

  return <DetailBody activity={activity} />;
}

function DetailBody({ activity }: { activity: Activity }) {
  const { colors, type, isDark } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();

  const [confirmCancel, setConfirmCancel] = useState(false);
  const hue = categoryForeground(activity.category, isDark);
  const open = isOpen(activity);
  const spots = spotsLeft(activity);

  const cancel = async () => {
    setConfirmCancel(false);
    try {
      await activityService.cancel(activity.id);
      void queryClient.invalidateQueries({ queryKey: queryKeys.activityById(activity.id) });
      void queryClient.invalidateQueries({ queryKey: queryKeys.myActivities });
      invalidateSocialGraph(queryClient);
      snackbar.show('Your plan has been cancelled.');
      navigation.goBack();
    } catch (error) {
      snackbar.error(
        error instanceof ApiException ? error.message : 'We could not cancel that plan.',
      );
    }
  };

  const place = [
    activity.area,
    activity.distanceKm !== null ? Format.distance(activity.distanceKm) : null,
  ]
    .filter((part): part is string => !!part && part.length > 0)
    .join(' · ');

  const lookingForLabel = genderPreferenceLabel(activity.lookingFor);

  return (
    <View style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View
          style={[
            styles.hero,
            {
              backgroundColor: categoryTint(activity.category, isDark),
              paddingTop: insets.top + 70,
            },
          ]}
        >
          <Entrance>
            <View style={styles.heroHead}>
              <CategoryBadge category={activity.category} size={38} radius={12} />
              <Text style={[type.overline, { color: hue, marginLeft: AppSpacing.md }]}>
                {categoryMeta(activity.category).label.toUpperCase()}
              </Text>
              <View style={styles.spacer} />
              {!open ? <ActivityStatusPill status={activity.status} /> : null}
            </View>
          </Entrance>

          <Entrance index={1} style={{ marginTop: AppSpacing.xl }}>
            <Text style={type.headline}>{activity.title}</Text>
          </Entrance>

          <Entrance index={2} style={{ marginTop: AppSpacing.lg }}>
            <Text style={[type.subtitle, { color: hue }]}>
              {Format.whenLabel(activity.startsAt)}
            </Text>
          </Entrance>
        </View>

        <View style={styles.body}>
          <Entrance index={3}>
            <FactRow icon="place" label={activity.locationName} detail={place} />
          </Entrance>

          <Entrance index={4} style={{ marginTop: AppSpacing.lg }}>
            <FactRow
              icon="schedule"
              label={Format.fullDate(activity.startsAt)}
              detail={
                activity.endsAt === null
                  ? `Starts ${Format.time(activity.startsAt)}`
                  : `${Format.time(activity.startsAt)} – ${Format.time(activity.endsAt)}`
              }
            />
          </Entrance>

          <Entrance index={5} style={{ marginTop: AppSpacing.lg }}>
            <FactRow
              icon="people"
              label={
                lookingForLabel === 'Anyone'
                  ? 'Open to anyone'
                  : `Looking for ${lookingForLabel.toLowerCase()}`
              }
              detail={`${activity.minAge}–${activity.maxAge} · ${spots} ${
                spots === 1 ? 'spot' : 'spots'
              } left`}
            />
          </Entrance>

          {activity.description.length > 0 ? (
            <Entrance index={6} style={{ marginTop: AppSpacing.xxxl }}>
              <Text style={[type.overline, { color: colors.inkFaint }]}>THE PLAN</Text>
              <Text style={[type.body, { lineHeight: 25, marginTop: AppSpacing.md }]}>
                {activity.description}
              </Text>
            </Entrance>
          ) : null}

          <Entrance index={7} style={{ marginTop: AppSpacing.xxxl }}>
            <Text style={[type.overline, { color: colors.inkFaint }]}>
              {activity.isHost ? 'YOUR PLAN' : 'HOSTED BY'}
            </Text>
          </Entrance>

          <Entrance index={8} style={{ marginTop: AppSpacing.md }}>
            <HostCard activity={activity} />
          </Entrance>

          {activity.isHost ? (
            <Entrance index={9} style={styles.cancelRow}>
              <AppButton
                label="Cancel this plan"
                variant="ghost"
                icon="event-busy"
                size="small"
                expand={false}
                onPress={open ? () => setConfirmCancel(true) : null}
              />
            </Entrance>
          ) : null}
        </View>
      </ScrollView>

      <View style={[styles.floatingBack, { top: insets.top }]}>
        <AppIconButton
          icon="arrow-back"
          onPress={() => navigation.goBack()}
          accessibilityLabel="Go back"
        />
      </View>

      <ActionBar activity={activity} />

      <ConfirmSheet
        visible={confirmCancel}
        title="Cancel this plan?"
        message="Everyone you invited is told it is off, and any pending requests are withdrawn. This cannot be undone."
        confirmLabel="Cancel the plan"
        cancelLabel="Keep it"
        isDestructive
        icon="event-busy"
        onConfirm={cancel}
        onCancel={() => setConfirmCancel(false)}
      />
    </View>
  );
}

/**
 * Borrows the invitation pill's shape so a closed plan and a settled
 * invitation read the same way at a glance.
 */
function ActivityStatusPill({ status }: { status: string }) {
  const { colors, type } = useTheme();

  const palette: Record<string, { label: string; background: string; foreground: string }> = {
    CANCELLED: { label: 'Cancelled', background: colors.dangerSoft, foreground: colors.danger },
    CONFIRMED: { label: 'Confirmed', background: colors.successSoft, foreground: colors.success },
    COMPLETED: { label: 'Done', background: colors.surfaceSunken, foreground: colors.inkMuted },
  };
  const entry = palette[status] ?? {
    label: 'Closed',
    background: colors.surfaceSunken,
    foreground: colors.inkFaint,
  };

  return (
    <View style={[styles.statusPill, { backgroundColor: entry.background }]}>
      <Text style={[type.caption, { color: entry.foreground, fontWeight: '600' }]}>
        {entry.label}
      </Text>
    </View>
  );
}

function FactRow({
  icon,
  label,
  detail,
}: {
  icon: MaterialIconName;
  label: string;
  detail: string;
}) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.factRow}>
      <View style={[styles.factIcon, { backgroundColor: colors.surfaceSunken }]}>
        <MaterialIcons name={icon} size={17} color={colors.inkMuted} />
      </View>
      <View style={styles.factBody}>
        <Text style={type.bodyStrong}>{label}</Text>
        {detail.length > 0 ? (
          <Text style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>{detail}</Text>
        ) : null}
      </View>
    </View>
  );
}

function HostCard({ activity }: { activity: Activity }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();

  const meta = [
    activity.host.age !== null ? `${activity.host.age}` : null,
    activity.host.occupation,
  ]
    .filter((part): part is string => !!part && part.length > 0)
    .join(' · ');

  return (
    <PressEffect
      onPress={
        activity.isHost
          ? null
          : () => navigation.navigate('PersonProfile', { userId: activity.host.id })
      }
      scale={0.99}
    >
      <View
        style={[styles.hostCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
      >
        <AppAvatar
          name={activity.host.displayName}
          imageUrl={activity.host.avatarUrl}
          size={52}
          isOnline={activity.host.isOnline}
          showPresence
        />

        <View style={styles.hostBody}>
          <View style={styles.hostNameRow}>
            <Text numberOfLines={1} style={[type.bodyStrong, styles.hostName]}>
              {activity.isHost ? 'You' : activity.host.displayName}
            </Text>
            {isVerified(activity.host.verification) ? (
              <View style={{ marginLeft: AppSpacing.xs + 2 }}>
                <VerifiedBadge size={15} status={activity.host.verification} />
              </View>
            ) : null}
          </View>

          {meta.length > 0 ? (
            <Text numberOfLines={1} style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>
              {meta}
            </Text>
          ) : null}

          {activity.host.ratingCount > 0 ? (
            <View style={[styles.ratingRow, { marginTop: AppSpacing.sm }]}>
              <MaterialIcons name="star" size={14} color={colors.warning} />
              <Text style={[type.caption, { color: colors.inkMuted, marginLeft: 3 }]}>
                {`${activity.host.ratingAverage.toFixed(1)} · ${activity.host.ratingCount} meet-ups`}
              </Text>
            </View>
          ) : null}
        </View>

        {!activity.isHost ? (
          <MaterialIcons name="chevron-right" size={24} color={colors.inkFaint} />
        ) : null}
      </View>
    </PressEffect>
  );
}

function ActionBar({ activity }: { activity: Activity }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const { showInvite } = useInviteSheet();
  const setMode = useDiscoverStore((state) => state.setMode);

  const hostName = firstName(activity.host);

  const pendingLabels: Record<string, string> = {
    PENDING: `Request sent — waiting on ${hostName}`,
    ACCEPTED: 'You are in. See you there.',
    DECLINED: `${hostName} could not make this one`,
  };

  let action: React.ReactNode;
  if (activity.isHost) {
    action = (
      <AppButton
        label="Find people for this"
        variant="secondary"
        icon="person-search"
        onPress={() => {
          setMode('people');
          navigation.navigate('Tabs', { screen: 'Discover' });
        }}
      />
    );
  } else if (activity.viewerInvitationStatus !== null) {
    action = (
      <View style={[styles.notice, { backgroundColor: colors.surfaceSunken }]}>
        <Text style={[type.label, { color: colors.inkMuted }]}>
          {pendingLabels[activity.viewerInvitationStatus] ?? 'This request is closed'}
        </Text>
      </View>
    );
  } else if (!isOpen(activity)) {
    action = (
      <View style={[styles.notice, { backgroundColor: colors.surfaceSunken }]}>
        <Text style={[type.label, { color: colors.inkMuted }]}>This plan is closed</Text>
      </View>
    );
  } else {
    action = (
      <AppButton
        label="Ask to join"
        icon="send"
        onPress={() => showInvite({ profile: activity.host, activity })}
      />
    );
  }

  return (
    <View
      style={[
        styles.actionBar,
        {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          paddingBottom: insets.bottom + AppSpacing.lg,
        },
      ]}
    >
      {action}
    </View>
  );
}

function DetailSkeleton() {
  const { colors } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: colors.canvas }]}>
      <Shimmer>
        <SkeletonBox height={260} radius={0} width="100%" />
        <View style={{ padding: AppSpacing.screenX }}>
          <SkeletonBox height={40} width="100%" />
          <View style={{ height: AppSpacing.lg }} />
          <SkeletonBox height={40} width="100%" />
          <View style={{ height: AppSpacing.lg }} />
          <SkeletonBox height={40} width="100%" />
        </View>
      </Shimmer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  backRow: { padding: AppSpacing.lg, alignItems: 'flex-start' },
  hero: {
    paddingHorizontal: AppSpacing.screenX,
    paddingBottom: AppSpacing.xxxl,
  },
  heroHead: { flexDirection: 'row', alignItems: 'center' },
  spacer: { flex: 1 },
  body: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xxl,
    paddingBottom: 150,
  },
  statusPill: {
    paddingHorizontal: AppSpacing.md,
    paddingVertical: 5,
    borderRadius: AppRadii.pill,
  },
  factRow: { flexDirection: 'row', alignItems: 'flex-start' },
  factIcon: {
    height: 36,
    width: 36,
    borderRadius: AppRadii.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  factBody: { flex: 1, marginLeft: AppSpacing.lg },
  hostCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  hostBody: { flex: 1, marginLeft: AppSpacing.lg },
  hostNameRow: { flexDirection: 'row', alignItems: 'center' },
  hostName: { flexShrink: 1 },
  ratingRow: { flexDirection: 'row', alignItems: 'center' },
  cancelRow: { marginTop: AppSpacing.xxxl, alignItems: 'center' },
  floatingBack: { position: 'absolute', left: 0, padding: AppSpacing.lg },
  actionBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    borderTopWidth: 1,
  },
  notice: {
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
  },
});
