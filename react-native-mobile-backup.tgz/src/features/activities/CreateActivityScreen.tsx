import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppButton,
  AppChip,
  AppIconButton,
  AppSheet,
  AppTextField,
  CategoryBadge,
  CategoryChip,
  DateTimePickerFlow,
  Entrance,
  PressEffect,
  SuccessBurst,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Format } from '../../core/utils/formatters';
import { Places, type Place } from '../../core/utils/locations';
import type { Activity } from '../../models/activity';
import {
  ACTIVITY_CATEGORIES,
  GENDER_PREFERENCES,
  categoryForeground,
  categoryMeta,
  genderPreferenceLabel,
  type ActivityCategory,
  type MaterialIconName,
} from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { invalidateSocialGraph, queryKeys } from '../../queries';
import { activityService, emptyActivityDraft, type ActivityDraft } from '../../services';
import { useCurrentUser } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Posting a plan is the other half of the product, so it gets the same care
 * as discovery: four questions on one screen, a live preview of the card
 * other people will see, and a single commit.
 */
export function CreateActivityScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const me = useCurrentUser();

  const [draft, setDraft] = useState<ActivityDraft>(emptyActivityDraft);
  const [place, setPlace] = useState<Place>(() => Places.byName(me?.area) ?? Places.fallback);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [placeSheet, setPlaceSheet] = useState(false);
  const [pickerSeed, setPickerSeed] = useState<Date | null>(null);
  const [posted, setPosted] = useState<Activity | null>(null);

  const canPost =
    draft.category !== null &&
    draft.title.trim().length >= 3 &&
    draft.startsAt !== null &&
    draft.locationName.trim().length >= 2;

  const post = async () => {
    setIsSubmitting(true);

    const payload: ActivityDraft = {
      ...draft,
      title: draft.title.trim(),
      description: draft.description.trim(),
      locationName: draft.locationName.trim(),
      area: place.name,
      city: place.city,
      latitude: place.latitude,
      longitude: place.longitude,
    };

    try {
      const created = await activityService.create(payload);
      void queryClient.invalidateQueries({ queryKey: queryKeys.myActivities });
      void queryClient.invalidateQueries({ queryKey: ['discover'] });
      invalidateSocialGraph(queryClient);
      setPosted(created);
    } catch (error) {
      setIsSubmitting(false);
      snackbar.error(
        error instanceof ApiException
          ? error.message
          : 'We could not post that plan. Please try again.',
      );
    }
  };

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.appBar}>
        <AppIconButton
          icon="close"
          bordered={false}
          background="transparent"
          onPress={() => navigation.goBack()}
          accessibilityLabel="Close"
        />
        <Text style={[type.subtitle, styles.appBarTitle]}>New plan</Text>
        <View style={styles.appBarSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.body}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
      >
        <Entrance>
          <Text style={type.headline}>{'What do you\nwant to do?'}</Text>
        </Entrance>

        <Entrance index={1} style={{ marginTop: AppSpacing.xl }}>
          <View style={styles.wrap}>
            {ACTIVITY_CATEGORIES.map((category: ActivityCategory) => (
              <View key={category} style={styles.wrapItem}>
                <CategoryChip
                  category={category}
                  selected={draft.category === category}
                  onPress={() => setDraft({ ...draft, category })}
                />
              </View>
            ))}
          </View>
        </Entrance>

        <Entrance index={2} style={{ marginTop: AppSpacing.xxxl - AppSpacing.sm }}>
          <AppTextField
            value={draft.title}
            onChangeText={(title) => setDraft({ ...draft, title })}
            label="Give it a title"
            hint="The late show at PVR Orion"
            maxLength={80}
            autoCapitalize="sentences"
          />
        </Entrance>

        <Entrance index={3} style={{ marginTop: AppSpacing.xl }}>
          <PickerRow
            label="When"
            icon="schedule"
            value={
              draft.startsAt === null ? 'Pick a date and time' : Format.whenLabel(draft.startsAt)
            }
            isPlaceholder={draft.startsAt === null}
            onPress={() =>
              setPickerSeed(draft.startsAt ?? new Date(Date.now() + 86_400_000))
            }
          />
        </Entrance>

        <Entrance index={4} style={{ marginTop: AppSpacing.xl }}>
          <AppTextField
            value={draft.locationName}
            onChangeText={(locationName) => setDraft({ ...draft, locationName })}
            label="Where"
            hint="PVR Orion Mall"
            prefixIcon="place"
            maxLength={120}
            autoCapitalize="words"
          />
        </Entrance>

        <Entrance index={5} style={{ marginTop: AppSpacing.md }}>
          <PickerRow
            label="Area"
            icon="map"
            value={`${place.name}, ${place.city}`}
            isPlaceholder={false}
            onPress={() => setPlaceSheet(true)}
          />
        </Entrance>

        <Entrance index={6} style={{ marginTop: AppSpacing.xxxl }}>
          <Text style={[type.overline, { color: colors.inkFaint }]}>
            WHO ARE YOU LOOKING FOR?
          </Text>
        </Entrance>

        <Entrance index={7} style={{ marginTop: AppSpacing.md }}>
          <View style={styles.wrap}>
            {GENDER_PREFERENCES.map((preference) => (
              <View key={preference} style={styles.wrapItem}>
                <AppChip
                  label={genderPreferenceLabel(preference)}
                  selected={draft.lookingFor === preference}
                  onPress={() => setDraft({ ...draft, lookingFor: preference })}
                />
              </View>
            ))}
          </View>
        </Entrance>

        <Entrance index={8} style={{ marginTop: AppSpacing.lg }}>
          <SpotsStepper
            value={draft.capacity}
            onChange={(capacity) => setDraft({ ...draft, capacity })}
          />
        </Entrance>

        <Entrance index={9} style={{ marginTop: AppSpacing.xxxl }}>
          <AppTextField
            value={draft.description}
            onChangeText={(description) => setDraft({ ...draft, description })}
            label="Tell people about it"
            hint="Booked two tickets for the 9:40 screening and my friend bailed. I do not talk during films, I promise."
            multiline
            numberOfLines={5}
            maxLength={600}
            autoCapitalize="sentences"
          />
        </Entrance>

        <Entrance index={10} style={{ marginTop: AppSpacing.xxxl }}>
          <Text style={[type.overline, { color: colors.inkFaint }]}>PREVIEW</Text>
        </Entrance>

        <Entrance index={11} style={{ marginTop: AppSpacing.md }}>
          <PlanPreview draft={draft} area={place.name} />
        </Entrance>
      </ScrollView>

      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            paddingBottom: insets.bottom + AppSpacing.lg,
          },
        ]}
      >
        <AppButton
          label="Post this plan"
          isLoading={isSubmitting}
          onPress={canPost ? post : null}
        />
      </View>

      <DateTimePickerFlow
        initial={pickerSeed}
        minimumDate={new Date()}
        maximumDate={new Date(Date.now() + 90 * 86_400_000)}
        onDone={(startsAt) => {
          setDraft({ ...draft, startsAt });
          setPickerSeed(null);
        }}
        onCancel={() => setPickerSeed(null)}
      />

      <AppSheet
        visible={placeSheet}
        onDismiss={() => setPlaceSheet(false)}
        title="Which area?"
        subtitle="People nearby see your plan first."
      >
        <View style={styles.wrap}>
          {Places.all.map((option) => (
            <View key={option.name} style={styles.wrapItem}>
              <AppChip
                label={option.name}
                icon="place"
                selected={option.name === place.name}
                onPress={() => {
                  setPlace(option);
                  setPlaceSheet(false);
                }}
              />
            </View>
          ))}
        </View>
      </AppSheet>

      {posted ? (
        <PostedConfirmation
          activity={posted}
          onSeePlan={() => {
            const activityId = posted.id;
            setPosted(null);
            navigation.replace('ActivityDetail', { activityId });
          }}
          onDone={() => {
            setPosted(null);
            navigation.goBack();
          }}
        />
      ) : null}
    </SafeAreaView>
  );
}

function PickerRow({
  label,
  icon,
  value,
  isPlaceholder,
  onPress,
}: {
  label: string;
  icon: MaterialIconName;
  value: string;
  isPlaceholder: boolean;
  onPress: () => void;
}) {
  const { colors, type } = useTheme();

  return (
    <View>
      <Text style={[type.label, { color: colors.inkMuted, marginBottom: AppSpacing.sm }]}>
        {label}
      </Text>
      <PressEffect onPress={onPress} scale={0.99}>
        <View
          style={[styles.picker, { backgroundColor: colors.surface, borderColor: colors.border }]}
        >
          <MaterialIcons name={icon} size={19} color={colors.inkFaint} />
          <Text
            numberOfLines={1}
            style={[
              type.body,
              { color: isPlaceholder ? colors.inkFaint : colors.ink, flex: 1, marginHorizontal: AppSpacing.md },
            ]}
          >
            {value}
          </Text>
          <MaterialIcons name="chevron-right" size={20} color={colors.inkFaint} />
        </View>
      </PressEffect>
    </View>
  );
}

function SpotsStepper({
  value,
  onChange,
}: {
  value: number;
  onChange: (value: number) => void;
}) {
  const { colors, type } = useTheme();

  return (
    <View style={[styles.picker, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <MaterialIcons name="groups" size={19} color={colors.inkFaint} />
      <Text style={[type.body, { flex: 1, marginHorizontal: AppSpacing.md }]}>
        {value === 1 ? 'Space for one person' : `Space for ${value} people`}
      </Text>
      <AppIconButton
        icon="remove"
        size={32}
        iconSize={16}
        onPress={value > 1 ? () => onChange(value - 1) : null}
        accessibilityLabel="Fewer spots"
      />
      <View style={{ width: AppSpacing.sm }} />
      <AppIconButton
        icon="add"
        size={32}
        iconSize={16}
        onPress={value < 10 ? () => onChange(value + 1) : null}
        accessibilityLabel="More spots"
      />
    </View>
  );
}

/**
 * The card exactly as it will appear in other people's feeds. Seeing it while
 * writing is what stops the vague one-word plans nobody replies to.
 */
function PlanPreview({ draft, area }: { draft: ActivityDraft; area: string }) {
  const { colors, type, isDark } = useTheme();

  const resolved = draft.category ?? 'OTHER';
  const hue = categoryForeground(resolved, isDark);
  const title = draft.title.trim();
  const description = draft.description.trim();
  const locationName = draft.locationName.trim();

  return (
    <View
      style={[styles.preview, { backgroundColor: colors.surface, borderColor: colors.border }]}
    >
      <CategoryBadge category={resolved} />
      <View style={styles.previewBody}>
        <Text
          style={[type.overline, { color: draft.startsAt === null ? colors.inkFaint : hue }]}
        >
          {draft.startsAt === null ? 'WHEN?' : Format.whenLabel(draft.startsAt).toUpperCase()}
        </Text>
        <Text
          numberOfLines={2}
          style={[
            type.subtitle,
            {
              lineHeight: 23,
              marginTop: AppSpacing.xs + 2,
              color: title.length === 0 ? colors.inkFaint : colors.ink,
            },
          ]}
        >
          {title.length === 0 ? 'Your title appears here' : title}
        </Text>
        <Text
          numberOfLines={1}
          style={[type.caption, { color: colors.inkMuted, marginTop: AppSpacing.sm }]}
        >
          {locationName.length === 0 ? area : `${locationName} · ${area}`}
        </Text>
        {description.length > 0 ? (
          <Text
            numberOfLines={2}
            style={[
              type.bodySmall,
              { color: colors.inkMuted, lineHeight: 20, marginTop: AppSpacing.md },
            ]}
          >
            {description}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

function PostedConfirmation({
  activity,
  onSeePlan,
  onDone,
}: {
  activity: Activity;
  onSeePlan: () => void;
  onDone: () => void;
}) {
  const { colors, type } = useTheme();

  return (
    <AppSheet visible onDismiss={onDone} dismissible={false} scrollable={false}>
      <View style={styles.confirmation}>
        <View style={{ height: AppSpacing.lg }} />
        <SuccessBurst size={88} color={colors.primary} />
        <Text style={[type.title, { marginTop: AppSpacing.xxl }]}>Your plan is live</Text>
        <Text
          style={[
            type.body,
            styles.centered,
            { color: colors.inkMuted, lineHeight: 22, marginTop: AppSpacing.sm },
          ]}
        >
          {`People nearby who are up for ${categoryMeta(
            activity.category,
          ).label.toLowerCase()} can see it now. You will hear the moment someone asks to join.`}
        </Text>

        <View style={{ height: AppSpacing.xxxl }} />
        <View style={styles.fullWidth}>
          <AppButton label="See the plan" onPress={onSeePlan} />
          <View style={{ height: AppSpacing.md }} />
          <AppButton label="Back to home" variant="ghost" size="large" onPress={onDone} />
        </View>
      </View>
    </AppSheet>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.md,
    paddingVertical: AppSpacing.sm,
  },
  appBarTitle: { flex: 1, textAlign: 'center' },
  appBarSpacer: { width: 42 },
  body: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.md,
    paddingBottom: AppSpacing.giant,
  },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  picker: {
    height: 54,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    borderRadius: AppRadii.md,
    borderWidth: 1,
  },
  preview: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  previewBody: { flex: 1, marginLeft: AppSpacing.lg },
  footer: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    borderTopWidth: 1,
  },
  confirmation: { alignItems: 'center', paddingTop: AppSpacing.lg },
  centered: { textAlign: 'center' },
  fullWidth: { width: '100%' },
});
