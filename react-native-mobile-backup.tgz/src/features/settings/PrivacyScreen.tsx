import React, { useState } from 'react';
import { StyleSheet, Switch, Text } from 'react-native';
import { useQueryClient } from '@tanstack/react-query';

import { useSnackbar } from '../../components';
import { ApiException } from '../../core/network/apiException';
import { profileService } from '../../services';
import { useAuthStore, useCurrentUser } from '../../stores';
import { AppSpacing, useTheme } from '../../theme';
import { Passage, SettingsGroup, SettingsRow, SettingsScaffold } from './SettingsWidgets';

/**
 * Three switches, each one an honest description of what changes for other
 * people. Privacy copy that says "manage your preferences" says nothing.
 */
export function PrivacyScreen() {
  const { colors, type } = useTheme();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const me = useCurrentUser();
  const setUser = useAuthStore((state) => state.setUser);

  const [isSaving, setIsSaving] = useState(false);

  const update = async (field: string, value: boolean) => {
    setIsSaving(true);
    try {
      const updated = await profileService.updateProfile({ [field]: value });
      setUser(updated);
      void queryClient.invalidateQueries({ queryKey: ['discover'] });
    } catch (error) {
      snackbar.error(
        error instanceof ApiException ? error.message : 'We could not save that change.',
      );
    } finally {
      setIsSaving(false);
    }
  };

  const toggle = (value: boolean, field: string) => (
    <Switch
      value={value}
      disabled={isSaving}
      onValueChange={(next) => void update(field, next)}
      trackColor={{ true: colors.primary, false: colors.surfaceSunken }}
    />
  );

  return (
    <SettingsScaffold
      title="Privacy"
      subtitle="You decide how much of you is visible, and to whom."
    >
      <SettingsGroup label="Discovery">
        {[
          <SettingsRow
            key="discoverable"
            icon="explore"
            label="Show me in discovery"
            description="Turn this off and nobody new can find you. Existing conversations keep working."
            trailing={toggle(me?.isDiscoverable ?? true, 'isDiscoverable')}
          />,
          <SettingsRow
            key="distance"
            icon="near-me"
            label="Show my distance"
            description="Others see roughly how far away you are, never where."
            trailing={toggle(me?.showDistance ?? true, 'showDistance')}
          />,
          <SettingsRow
            key="age"
            icon="cake"
            label="Show my age"
            description="Your age still counts towards other people’s filters."
            trailing={toggle(me?.showAge ?? true, 'showAge')}
          />,
        ]}
      </SettingsGroup>

      <Passage
        icon="place"
        title="What we know about where you are"
        body="Companion stores the neighbourhood you picked, not a live location. We never track you in the background and never show anyone an address. Distances are calculated from area centres, so “2.4 km away” means roughly, not exactly."
      />

      <Passage
        icon="visibility-off"
        title="What other people never see"
        body="Your email address, your phone number, your filters, and every profile you looked at but did not invite. Blocking is silent — the other person is never told."
      />

      <Text style={[type.caption, styles.footnote, { color: colors.inkFaint }]}>
        A full data export and account deletion are planned for the next release.
      </Text>
    </SettingsScaffold>
  );
}

const styles = StyleSheet.create({
  footnote: { lineHeight: 19, paddingHorizontal: AppSpacing.screenX },
});
