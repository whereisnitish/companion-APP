import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { Passage, SettingsScaffold } from './SettingsWidgets';

/** Short, specific rules. A long policy nobody reads protects nobody. */
export function GuidelinesScreen() {
  const { colors, type } = useTheme();

  return (
    <SettingsScaffold
      title="Community guidelines"
      subtitle="Companion is for doing things with people. Five rules keep it that way."
    >
      <Passage
        icon="event-available"
        title="1. Show up"
        body="If you accept an invitation, go. If your plans change, say so as early as you can. Repeatedly leaving people waiting is the fastest way to lose your account."
      />
      <Passage
        icon="face"
        title="2. Be who you say you are"
        body="Your real name, your real age, a recent photo of you. Impersonation and catfishing get removed on the first report."
      />
      <Passage
        icon="handshake"
        title="3. This is not a dating app"
        body="People are here for the activity. Anyone can say yes to a film and no to anything else. Sexual, aggressive or persistent messages after a clear no are grounds for removal."
      />
      <Passage
        icon="currency-rupee"
        title="4. No selling, no soliciting"
        body="No promotion, no recruiting, no asking for money, no crypto, no “investment opportunities”. Every account doing this gets removed."
      />
      <Passage
        icon="diversity-3"
        title="5. Everyone is welcome"
        body="Harassment or hate on the basis of gender, caste, religion, sexuality, disability, race or anything else is not tolerated once."
      />

      <View style={styles.wrap}>
        <View style={[styles.card, { backgroundColor: colors.surfaceSunken }]}>
          <Text style={type.bodyStrong}>How we enforce this</Text>
          <Text
            style={[
              type.bodySmall,
              { color: colors.inkMuted, lineHeight: 21, marginTop: AppSpacing.sm },
            ]}
          >
            Every report is read by a person. Depending on what happened we warn, restrict, or
            remove the account — and we tell you what we did with your report. Serious cases are
            escalated to the authorities.
          </Text>
        </View>
      </View>
    </SettingsScaffold>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: AppSpacing.screenX, paddingTop: AppSpacing.sm },
  card: { padding: AppSpacing.lg, borderRadius: AppRadii.lg },
});
