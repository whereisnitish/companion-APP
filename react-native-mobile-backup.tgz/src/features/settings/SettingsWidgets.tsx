import React, { type ReactNode } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

import { PressEffect } from '../../components';
import type { MaterialIconName } from '../../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

/**
 * Chrome shared by every settings-family screen: a back button, a serif
 * title, and a body that scrolls under it. Written once so Privacy, Safety and
 * Guidelines cannot drift apart.
 */
export function SettingsScaffold({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { colors, type } = useTheme();
  const navigation = useNavigation();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <PressEffect
            onPress={() => navigation.goBack()}
            scale={0.9}
            accessibilityLabel="Go back"
          >
            <View style={{ padding: AppSpacing.sm }}>
              <MaterialIcons name="arrow-back" size={24} color={colors.ink} />
            </View>
          </PressEffect>

          <Text style={[type.headline, styles.title]}>{title}</Text>
          {subtitle ? (
            <Text style={[type.body, styles.subtitle, { color: colors.inkMuted }]}>
              {subtitle}
            </Text>
          ) : null}
        </View>

        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function SettingsGroup({
  label,
  children,
}: {
  label: string;
  children: ReactNode[];
}) {
  const { colors, type } = useTheme();
  const rows = React.Children.toArray(children);

  return (
    <View style={styles.group}>
      <Text style={[type.overline, styles.groupLabel, { color: colors.inkFaint }]}>
        {label.toUpperCase()}
      </Text>

      <View
        style={[styles.groupBody, { backgroundColor: colors.surface, borderColor: colors.border }]}
      >
        {rows.map((row, index) => (
          <View key={index}>
            {row}
            {index !== rows.length - 1 ? (
              <View style={styles.dividerWrap}>
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
              </View>
            ) : null}
          </View>
        ))}
      </View>
    </View>
  );
}

export function SettingsRow({
  icon,
  label,
  description,
  trailing,
  onPress,
  tone,
}: {
  icon: MaterialIconName;
  label: string;
  description?: string;
  trailing?: ReactNode;
  onPress?: (() => void) | null;
  tone?: string;
}) {
  const { colors, type } = useTheme();
  const foreground = tone ?? colors.ink;

  return (
    <PressEffect onPress={onPress} scale={0.995}>
      <View style={styles.row}>
        <MaterialIcons name={icon} size={19} color={foreground} />
        <View style={styles.rowBody}>
          <Text style={[type.body, { color: foreground }]}>{label}</Text>
          {description ? (
            <Text style={[type.caption, { color: colors.inkMuted, lineHeight: 17, marginTop: 2 }]}>
              {description}
            </Text>
          ) : null}
        </View>
        {trailing ?? (
          onPress ? <MaterialIcons name="chevron-right" size={20} color={colors.inkFaint} /> : null
        )}
      </View>
    </PressEffect>
  );
}

/** A prose block for the guidelines and safety screens. */
export function Passage({
  title,
  body,
  icon,
}: {
  title: string;
  body: string;
  icon?: MaterialIconName;
}) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.passage}>
      {icon ? (
        <View style={[styles.passageIcon, { backgroundColor: colors.primarySoft }]}>
          <MaterialIcons name={icon} size={16} color={colors.primary} />
        </View>
      ) : null}
      <View style={styles.passageBody}>
        <Text style={type.bodyStrong}>{title}</Text>
        <Text
          style={[type.body, { color: colors.inkMuted, lineHeight: 24, marginTop: AppSpacing.sm }]}
        >
          {body}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingBottom: AppSpacing.giant },
  header: {
    paddingLeft: AppSpacing.md,
    paddingRight: AppSpacing.screenX,
    paddingTop: AppSpacing.sm,
    paddingBottom: AppSpacing.xxl,
  },
  title: { marginTop: AppSpacing.lg, marginLeft: AppSpacing.sm },
  subtitle: { marginTop: AppSpacing.sm, marginLeft: AppSpacing.sm, lineHeight: 23 },
  group: { marginBottom: AppSpacing.xxl },
  groupLabel: { marginLeft: AppSpacing.screenX, marginBottom: AppSpacing.md },
  groupBody: {
    marginHorizontal: AppSpacing.screenX,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
    overflow: 'hidden',
  },
  dividerWrap: { paddingLeft: AppSpacing.giant },
  divider: { height: 1 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.lg - 2,
  },
  rowBody: { flex: 1, marginHorizontal: AppSpacing.lg },
  passage: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.screenX,
    paddingBottom: AppSpacing.xxl,
  },
  passageIcon: {
    height: 34,
    width: 34,
    borderRadius: AppRadii.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: AppSpacing.lg,
  },
  passageBody: { flex: 1 },
});
