import React, { useState } from 'react';
import { StyleSheet, Switch, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { ConfirmSheet } from '../../components';
import { AppConfig } from '../../core/config/appConfig';
import { isVerified, type MaterialIconName } from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { useAuthStore, useCurrentUser } from '../../stores';
import { AppSpacing, useTheme } from '../../theme';
import { SettingsGroup, SettingsRow, SettingsScaffold } from './SettingsWidgets';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

export function SettingsScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const me = useCurrentUser();
  const signOut = useAuthStore((state) => state.signOut);

  const [confirmSignOut, setConfirmSignOut] = useState(false);
  const verified = isVerified(me?.verification ?? 'UNVERIFIED');

  return (
    <SettingsScaffold title="Settings">
      <SettingsGroup label="Account">
        {[
          <SettingsRow
            key="edit"
            icon="person"
            label="Edit profile"
            description="Photo, bio, interests and availability"
            onPress={() => navigation.navigate('EditProfile')}
          />,
          <SettingsRow
            key="account"
            icon="alternate-email"
            label={me?.email ?? me?.phone ?? 'Your account'}
            description="Sign-in details"
          />,
          <SettingsRow
            key="verify"
            icon="verified"
            label="Get verified"
            description={
              verified ? 'Your profile is verified' : 'Coming soon — a badge people can trust'
            }
            trailing={
              <Text style={[type.caption, { color: colors.inkFaint }]}>
                {verified ? 'Verified' : 'Soon'}
              </Text>
            }
          />,
        ]}
      </SettingsGroup>

      <SettingsGroup label="Privacy and safety">
        {[
          <SettingsRow
            key="privacy"
            icon="lock"
            label="Privacy"
            description="Who can find you, and what they see"
            onPress={() => navigation.navigate('Privacy')}
          />,
          <SettingsRow
            key="safety"
            icon="shield"
            label="Safety centre"
            description="Meeting someone new, sensibly"
            onPress={() => navigation.navigate('Safety')}
          />,
          <SettingsRow
            key="blocked"
            icon="block"
            label="Blocked people"
            description="Manage who you have blocked"
            onPress={() => navigation.navigate('Blocked')}
          />,
          <SettingsRow
            key="guidelines"
            icon="menu-book"
            label="Community guidelines"
            description="What we expect from everyone here"
            onPress={() => navigation.navigate('Guidelines')}
          />,
        ]}
      </SettingsGroup>

      <SettingsGroup label="Notifications">
        {[
          <NotificationToggle key="invitations" icon="mail-outline" label="New invitations" />,
          <NotificationToggle key="messages" icon="chat-bubble-outline" label="Messages" />,
          <NotificationToggle key="reminders" icon="schedule" label="Plan reminders" />,
        ]}
      </SettingsGroup>

      <SettingsGroup label="About">
        {[
          <SettingsRow
            key="about"
            icon="info"
            label="About Companion"
            description="Version 0.1.0 · MVP"
          />,
          <SettingsRow
            key="contact"
            icon="mail-outline"
            label="Contact us"
            description={AppConfig.supportEmail}
          />,
          <SettingsRow
            key="signout"
            icon="logout"
            label="Sign out"
            tone={colors.danger}
            onPress={() => setConfirmSignOut(true)}
          />,
        ]}
      </SettingsGroup>

      <Text style={[type.caption, styles.footnote, { color: colors.inkFaint }]}>
        Companion is an MVP. Verification, photo uploads and push delivery are stubbed —
        everything else here is real, and talks to your own server.
      </Text>

      <ConfirmSheet
        visible={confirmSignOut}
        title="Sign out?"
        message="Your plans and conversations stay exactly where they are."
        confirmLabel="Sign out"
        icon="logout"
        onConfirm={() => {
          setConfirmSignOut(false);
          void signOut();
        }}
        onCancel={() => setConfirmSignOut(false)}
      />
    </SettingsScaffold>
  );
}

/**
 * Local-only for the MVP: the switch is real, the delivery channel is not yet.
 * Wiring it to a `/users/me/notification-preferences` endpoint later is a
 * change to this component alone.
 */
function NotificationToggle({ icon, label }: { icon: MaterialIconName; label: string }) {
  const { colors } = useTheme();
  const [enabled, setEnabled] = useState(true);

  return (
    <SettingsRow
      icon={icon}
      label={label}
      onPress={() => setEnabled((current) => !current)}
      trailing={
        <Switch
          value={enabled}
          onValueChange={setEnabled}
          trackColor={{ true: colors.primary, false: colors.surfaceSunken }}
        />
      }
    />
  );
}

const styles = StyleSheet.create({
  footnote: {
    textAlign: 'center',
    lineHeight: 19,
    paddingHorizontal: AppSpacing.screenX,
  },
});
