import React, { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppButton,
  AppSheet,
  AppTextField,
  ConfirmSheet,
  PressEffect,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import type { MaterialIconName } from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { invalidateSocialGraph, queryKeys } from '../../queries';
import { safetyService } from '../../services';
import { REPORT_REASONS, reportReasonLabel, type ReportReason } from '../../services/safetyService';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

interface SafetyTarget {
  userId: string;
  displayName: string;
  /** Called after a successful block — usually to leave the blocked person's screen. */
  onBlocked?: () => void;
}

interface SafetyApi {
  showSafetyActions: (target: SafetyTarget) => void;
}

const SafetyContext = createContext<SafetyApi | null>(null);

/**
 * The safety menu behind every "…" on a person.
 *
 * Kept one tap from anywhere someone appears — a profile, a chat, an
 * invitation — because a safety control that is hard to find is not one.
 */
export function SafetyActionsProvider({ children }: { children: ReactNode }) {
  const [target, setTarget] = useState<SafetyTarget | null>(null);
  const [stage, setStage] = useState<'menu' | 'confirmBlock' | 'report'>('menu');

  const api = useMemo<SafetyApi>(
    () => ({
      showSafetyActions: (next: SafetyTarget) => {
        setStage('menu');
        setTarget(next);
      },
    }),
    [],
  );

  const dismiss = useCallback(() => {
    setTarget(null);
    setStage('menu');
  }, []);

  return (
    <SafetyContext.Provider value={api}>
      {children}
      {target ? (
        <SafetyFlow target={target} stage={stage} setStage={setStage} onDismiss={dismiss} />
      ) : null}
    </SafetyContext.Provider>
  );
}

/** `const { showSafetyActions } = useSafetyActions()`. */
export function useSafetyActions(): SafetyApi {
  const api = useContext(SafetyContext);
  if (!api) throw new Error('useSafetyActions must be used inside a SafetyActionsProvider');
  return api;
}

function SafetyFlow({
  target,
  stage,
  setStage,
  onDismiss,
}: {
  target: SafetyTarget;
  stage: 'menu' | 'confirmBlock' | 'report';
  setStage: (stage: 'menu' | 'confirmBlock' | 'report') => void;
  onDismiss: () => void;
}) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();

  const { userId, displayName } = target;

  const block = async () => {
    try {
      await safetyService.block(userId);
      invalidateSocialGraph(queryClient);
      void queryClient.invalidateQueries({ queryKey: ['discover'] });
      onDismiss();
      snackbar.success(`${displayName} has been blocked.`);
      // Their profile no longer exists for us; step back to somewhere real.
      target.onBlocked?.();
    } catch (error) {
      onDismiss();
      snackbar.error(
        error instanceof ApiException ? error.message : 'We could not block them just now.',
      );
    }
  };

  if (stage === 'confirmBlock') {
    return (
      <ConfirmSheet
        visible
        title={`Block ${displayName}?`}
        message="They will not see you in discovery, cannot invite or message you, and any pending invitations between you are withdrawn. They are not told."
        confirmLabel={`Block ${displayName}`}
        isDestructive
        icon="block"
        onConfirm={block}
        onCancel={onDismiss}
      />
    );
  }

  if (stage === 'report') {
    return <ReportSheet userId={userId} displayName={displayName} onDismiss={onDismiss} />;
  }

  return (
    <AppSheet
      visible
      onDismiss={onDismiss}
      title={displayName}
      subtitle="Your safety comes before anyone’s feelings."
      scrollable={false}
    >
      <ActionRow
        icon="flag"
        label={`Report ${displayName}`}
        description="Tell our team something is wrong here."
        onPress={() => setStage('report')}
      />
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      <ActionRow
        icon="block"
        label={`Block ${displayName}`}
        description="Remove them from your app entirely."
        tone={colors.danger}
        onPress={() => setStage('confirmBlock')}
      />
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      <ActionRow
        icon="menu-book"
        label="Safety tips"
        description="How to meet someone new sensibly."
        onPress={() => {
          onDismiss();
          navigation.navigate('Safety');
        }}
      />

      <Text
        style={[
          type.caption,
          styles.footnote,
          { color: colors.inkFaint, marginTop: AppSpacing.xl },
        ]}
      >
        Reports are confidential. Blocking is silent — nobody is told.
      </Text>
    </AppSheet>
  );
}

function ActionRow({
  icon,
  label,
  description,
  onPress,
  tone,
}: {
  icon: MaterialIconName;
  label: string;
  description: string;
  onPress: () => void;
  tone?: string;
}) {
  const { colors, type } = useTheme();
  const foreground = tone ?? colors.ink;

  return (
    <PressEffect onPress={onPress} scale={0.99}>
      <View style={styles.actionRow}>
        <MaterialIcons name={icon} size={20} color={foreground} />
        <View style={styles.actionBody}>
          <Text style={[type.bodyStrong, { color: foreground }]}>{label}</Text>
          <Text style={[type.caption, { color: colors.inkMuted, marginTop: 1 }]}>
            {description}
          </Text>
        </View>
        <MaterialIcons name="chevron-right" size={20} color={colors.inkFaint} />
      </View>
    </PressEffect>
  );
}

function ReportSheet({
  userId,
  displayName,
  onDismiss,
}: {
  userId: string;
  displayName: string;
  onDismiss: () => void;
}) {
  const { colors, type } = useTheme();
  const snackbar = useSnackbar();

  const [reason, setReason] = useState<ReportReason | null>(null);
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submit = async () => {
    if (!reason) return;
    setIsSubmitting(true);
    try {
      const message = await safetyService.report(userId, reason, details.trim());
      onDismiss();
      snackbar.show(message, { icon: 'shield' });
    } catch (error) {
      setIsSubmitting(false);
      snackbar.error(
        error instanceof ApiException ? error.message : 'We could not send that report.',
      );
    }
  };

  return (
    <AppSheet
      visible
      onDismiss={onDismiss}
      title={`Report ${displayName}`}
      subtitle="What happened? This goes straight to our safety team."
      footer={
        <AppButton
          label="Submit report"
          variant="danger"
          isLoading={isSubmitting}
          onPress={reason ? submit : null}
        />
      }
    >
      {REPORT_REASONS.map((option) => {
        const isSelected = reason === option;
        return (
          <View key={option} style={{ marginBottom: AppSpacing.sm }}>
            <PressEffect onPress={() => setReason(option)} scale={0.99}>
              <View
                style={[
                  styles.reason,
                  {
                    backgroundColor: isSelected ? colors.dangerSoft : colors.surface,
                    borderColor: isSelected ? colors.danger : colors.border,
                  },
                ]}
              >
                <Text style={[type.body, styles.reasonLabel]}>{reportReasonLabel(option)}</Text>
                {isSelected ? (
                  <MaterialIcons name="check-circle" size={18} color={colors.danger} />
                ) : null}
              </View>
            </PressEffect>
          </View>
        );
      })}

      <View style={{ height: AppSpacing.lg }} />
      <AppTextField
        value={details}
        onChangeText={setDetails}
        label="Anything else? (optional)"
        hint="Details help us act faster."
        multiline
        numberOfLines={4}
        maxLength={1000}
        autoCapitalize="sentences"
      />
    </AppSheet>
  );
}

const styles = StyleSheet.create({
  actionRow: { flexDirection: 'row', alignItems: 'center' },
  actionBody: { flex: 1, marginHorizontal: AppSpacing.lg },
  divider: { height: 1, marginVertical: AppSpacing.lg },
  footnote: { textAlign: 'center', lineHeight: 18 },
  reason: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md + 2,
    borderRadius: AppRadii.md,
    borderWidth: 1,
  },
  reasonLabel: { flex: 1 },
});
