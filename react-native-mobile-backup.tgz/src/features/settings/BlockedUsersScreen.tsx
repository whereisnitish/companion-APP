import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppButton,
  ConfirmSheet,
  ErrorStateView,
  ListRowSkeleton,
  Shimmer,
  StateView,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { safetyService, type BlockedUser } from '../../services';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { SettingsScaffold } from './SettingsWidgets';

const BLOCKED_KEY = ['safety', 'blocked'] as const;

export function BlockedUsersScreen() {
  const { colors, type } = useTheme();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();

  const { data, isPending, error, refetch } = useQuery({
    queryKey: BLOCKED_KEY,
    queryFn: () => safetyService.listBlocked(),
  });

  const [pending, setPending] = useState<BlockedUser | null>(null);

  const unblock = async (user: BlockedUser) => {
    setPending(null);
    try {
      await safetyService.unblock(user.id);
      void queryClient.invalidateQueries({ queryKey: BLOCKED_KEY });
      void queryClient.invalidateQueries({ queryKey: ['discover'] });
      snackbar.show(`${user.displayName} has been unblocked.`);
    } catch (thrown) {
      snackbar.error(
        thrown instanceof ApiException ? thrown.message : 'We could not unblock them just now.',
      );
    }
  };

  return (
    <SettingsScaffold
      title="Blocked people"
      subtitle="Blocking is silent and reversible. Nobody is ever told."
    >
      {isPending ? (
        <Shimmer>
          <ListRowSkeleton leadingSize={44} />
          <ListRowSkeleton leadingSize={44} />
        </Shimmer>
      ) : error ? (
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      ) : (data ?? []).length === 0 ? (
        <StateView
          icon="block"
          title="Nobody blocked"
          message="When you block someone they disappear from your app entirely."
          compact
        />
      ) : (
        (data ?? []).map((user) => (
          <View key={user.id} style={styles.rowWrap}>
            <View
              style={[styles.row, { backgroundColor: colors.surface, borderColor: colors.border }]}
            >
              <AppAvatar name={user.displayName} imageUrl={user.avatarUrl} size={42} />
              <Text style={[type.body, styles.name]}>{user.displayName}</Text>
              <AppButton
                label="Unblock"
                variant="secondary"
                size="small"
                expand={false}
                onPress={() => setPending(user)}
              />
            </View>
          </View>
        ))
      )}

      <ConfirmSheet
        visible={pending !== null}
        title={`Unblock ${pending?.displayName ?? ''}?`}
        message="They will be able to see you in discovery again and send you invitations. They are not told anything."
        confirmLabel="Unblock"
        icon="lock-open"
        onConfirm={() => {
          if (pending) void unblock(pending);
        }}
        onCancel={() => setPending(null)}
      />
    </SettingsScaffold>
  );
}

const styles = StyleSheet.create({
  rowWrap: { paddingHorizontal: AppSpacing.screenX, marginBottom: AppSpacing.sm },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.md,
    borderRadius: AppRadii.md,
    borderWidth: 1,
  },
  name: { flex: 1, marginHorizontal: AppSpacing.md },
});
