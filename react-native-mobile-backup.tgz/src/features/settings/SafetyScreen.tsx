import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import type { RootStackParamList } from '../../navigation/types';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { Passage, SettingsGroup, SettingsRow, SettingsScaffold } from './SettingsWidgets';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/** Safety advice written as advice, not as a liability disclaimer. */
export function SafetyScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();

  return (
    <SettingsScaffold
      title="Safety centre"
      subtitle="Meeting a stranger should be exciting, not risky. A few habits make almost all of the difference."
    >
      <View style={styles.alertWrap}>
        <View style={[styles.alert, { backgroundColor: colors.dangerSoft }]}>
          <MaterialIcons name="emergency" size={20} color={colors.danger} />
          <Text
            style={[
              type.bodySmall,
              { color: colors.danger, lineHeight: 20, marginLeft: AppSpacing.lg, flex: 1 },
            ]}
          >
            If you feel unsafe right now, leave first and report afterwards. Nothing here is more
            important than that.
          </Text>
        </View>
      </View>

      <Passage
        icon="storefront"
        title="Meet somewhere public, the first few times"
        body="A cafe, a cinema foyer, a busy park. Save the quiet places for when you already know each other. Arrange to arrive and leave separately."
      />
      <Passage
        icon="share"
        title="Tell one person where you are going"
        body="A friend, a flatmate, a sibling. Share the plan, the place and roughly when you expect to be done. It costs one message."
      />
      <Passage
        icon="chat-bubble-outline"
        title="Keep the conversation in the app"
        body="Moving to another app early removes the record, and the record is what lets us act if something goes wrong. There is no rush."
      />
      <Passage
        icon="directions-car"
        title="Make your own way there and back"
        body="Being able to leave whenever you want is the single most useful thing you can arrange in advance."
      />
      <Passage
        icon="psychology"
        title="Trust the feeling before the evidence"
        body="If something is off, you do not owe anyone an explanation or a polite goodbye. Leave, block, and tell us. We would rather hear about ten things that turned out fine than miss one that did not."
      />

      <SettingsGroup label="If something goes wrong">
        {[
          <SettingsRow
            key="report"
            icon="flag"
            label="Report someone"
            description="Open their profile and tap the ⋯ menu."
          />,
          <SettingsRow
            key="blocked"
            icon="block"
            label="Blocked people"
            description="Review or undo a block"
            onPress={() => navigation.navigate('Blocked')}
          />,
          <SettingsRow
            key="guidelines"
            icon="menu-book"
            label="Community guidelines"
            description="What gets someone removed"
            onPress={() => navigation.navigate('Guidelines')}
          />,
        ]}
      </SettingsGroup>
    </SettingsScaffold>
  );
}

const styles = StyleSheet.create({
  alertWrap: { paddingHorizontal: AppSpacing.screenX, paddingBottom: AppSpacing.xxl },
  alert: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
  },
});
