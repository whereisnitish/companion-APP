import React, { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppButton,
  AppChip,
  AppSheet,
  AppTextField,
  CategoryBadge,
  CategoryChip,
  DateTimePickerFlow,
  PressEffect,
  SuccessBurst,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Format } from '../../core/utils/formatters';
import type { Activity } from '../../models/activity';
import {
  categoryForeground,
  categoryTint,
  type ActivityCategory,
} from '../../models/enums';
import { firstName, type Profile } from '../../models/profile';
import { invalidateSocialGraph } from '../../queries';
import { invitationService } from '../../services';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

interface InviteTarget {
  profile: Profile;
  activity?: Activity | null;
}

interface InviteApi {
  showInvite: (target: InviteTarget) => void;
}

const InviteContext = createContext<InviteApi | null>(null);

/**
 * The invitation composer, hosted once at the root.
 *
 * Flutter pushed this as a modal route from wherever the tap happened; React
 * Native has no imperative sheet, so the host lives here and screens ask for it
 * through context. The sheet itself is unchanged: two shapes, one surface.
 */
export function InviteSheetProvider({ children }: { children: ReactNode }) {
  const [target, setTarget] = useState<InviteTarget | null>(null);

  const api = useMemo<InviteApi>(
    () => ({ showInvite: (next: InviteTarget) => setTarget(next) }),
    [],
  );

  return (
    <InviteContext.Provider value={api}>
      {children}
      {target ? (
        <InviteSheet
          profile={target.profile}
          activity={target.activity ?? null}
          onDismiss={() => setTarget(null)}
        />
      ) : null}
    </InviteContext.Provider>
  );
}

/** `const { showInvite } = useInviteSheet()`. */
export function useInviteSheet(): InviteApi {
  const api = useContext(InviteContext);
  if (!api) throw new Error('useInviteSheet must be used inside an InviteSheetProvider');
  return api;
}

interface QuickTime {
  label: string;
  value: Date;
}

function quickTimes(): QuickTime[] {
  const now = new Date();

  const tonight = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 20, 0, 0, 0);
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 19, 30, 0, 0);

  // JS weekday: 0 = Sunday, 6 = Saturday.
  const daysToSaturday = (6 - now.getDay() + 7) % 7;
  const weekend = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + (daysToSaturday === 0 ? 7 : daysToSaturday),
    11,
    0,
    0,
    0,
  );

  return [
    ...(tonight.getTime() > now.getTime() ? [{ label: 'Tonight', value: tonight }] : []),
    { label: 'Tomorrow', value: tomorrow },
    { label: 'This weekend', value: weekend },
  ];
}

/** Their preferences first, then the everyday ones — never all twelve. */
function suggestedCategories(profile: Profile): ActivityCategory[] {
  const ordered: ActivityCategory[] = [
    ...profile.preferredActivities,
    'COFFEE',
    'DINNER',
    'MOVIE',
    'WALK',
  ];
  return Array.from(new Set(ordered)).slice(0, 6);
}

function InviteSheet({
  profile,
  activity,
  onDismiss,
}: {
  profile: Profile;
  activity: Activity | null;
  onDismiss: () => void;
}) {
  const { colors, type } = useTheme();
  const queryClient = useQueryClient();

  const isJoiningPlan = activity !== null;

  // Default to something they are already up for — one less decision.
  const [category, setCategory] = useState<ActivityCategory | null>(
    activity?.category ?? profile.preferredActivities[0] ?? 'COFFEE',
  );
  const [proposedAt, setProposedAt] = useState<Date | null>(activity?.startsAt ?? null);
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pickerSeed, setPickerSeed] = useState<Date | null>(null);

  const times = useMemo(quickTimes, []);
  const categories = useMemo(() => suggestedCategories(profile), [profile]);

  const isQuickTime = useCallback(
    (value: Date) => times.some((option) => option.value.getTime() === value.getTime()),
    [times],
  );

  const canSend = isJoiningPlan || (category !== null && proposedAt !== null);

  const send = async () => {
    setIsSending(true);
    setError(null);

    try {
      await invitationService.send({
        recipientId: profile.id,
        activityId: activity?.id ?? null,
        category: activity === null ? category : null,
        proposedAt: activity === null ? proposedAt : null,
        locationName: activity?.locationName ?? null,
        message: message.trim(),
      });

      invalidateSocialGraph(queryClient);
      setIsSending(false);
      setIsSent(true);
    } catch (thrown) {
      setIsSending(false);
      setError(
        thrown instanceof ApiException
          ? thrown.message
          : 'We could not send that invitation. Please try again.',
      );
    }
  };

  if (isSent) {
    return <SentConfirmation profile={profile} onDismiss={onDismiss} />;
  }

  const customLabel =
    proposedAt !== null && !isQuickTime(proposedAt) ? Format.whenShort(proposedAt) : 'Pick a time';

  return (
    <>
      <AppSheet
        visible
        onDismiss={onDismiss}
        title={isJoiningPlan ? 'Ask to join' : `Invite ${firstName(profile)}`}
        subtitle={isJoiningPlan ? activity.title : 'Suggest something, keep it simple.'}
        footer={
          <View>
            {error ? (
              <View style={styles.errorRow}>
                <MaterialIcons name="error-outline" size={16} color={colors.danger} />
                <Text
                  style={[type.caption, { color: colors.danger, marginLeft: AppSpacing.sm, flex: 1 }]}
                >
                  {error}
                </Text>
              </View>
            ) : null}
            <AppButton
              label={isJoiningPlan ? 'Send request' : 'Send invitation'}
              icon="send"
              isLoading={isSending}
              onPress={canSend ? send : null}
            />
          </View>
        }
      >
        <RecipientRow profile={profile} />

        <View style={{ height: AppSpacing.xxl }} />

        {isJoiningPlan ? (
          <PlanSummary activity={activity} />
        ) : (
          <>
            <Text style={[type.overline, { color: colors.inkFaint }]}>WHAT</Text>
            <View style={styles.wrap}>
              {categories.map((option) => (
                <View key={option} style={styles.wrapItem}>
                  <CategoryChip
                    category={option}
                    selected={category === option}
                    dense
                    onPress={() => setCategory(option)}
                  />
                </View>
              ))}
            </View>

            <View style={{ height: AppSpacing.xxl - AppSpacing.sm }} />
            <Text style={[type.overline, { color: colors.inkFaint }]}>WHEN</Text>
            <View style={styles.wrap}>
              {times.map((option) => (
                <View key={option.label} style={styles.wrapItem}>
                  <AppChip
                    label={option.label}
                    dense
                    selected={proposedAt?.getTime() === option.value.getTime()}
                    onPress={() => setProposedAt(option.value)}
                  />
                </View>
              ))}
              <View style={styles.wrapItem}>
                <AppChip
                  label={customLabel}
                  icon="calendar-today"
                  dense
                  selected={proposedAt !== null && !isQuickTime(proposedAt)}
                  onPress={() => setPickerSeed(proposedAt ?? new Date(Date.now() + 86_400_000))}
                />
              </View>
            </View>

            {proposedAt ? (
              <Text style={[type.caption, { color: colors.inkMuted, marginTop: AppSpacing.md }]}>
                {Format.whenLabel(proposedAt)}
              </Text>
            ) : null}
          </>
        )}

        <View style={{ height: AppSpacing.xxl }} />
        <AppTextField
          value={message}
          onChangeText={setMessage}
          label="Add a note"
          hint={
            isJoiningPlan
              ? 'Say why you would be good company.'
              : 'Keep it short and specific.'
          }
          multiline
          numberOfLines={4}
          maxLength={500}
          autoCapitalize="sentences"
        />
      </AppSheet>

      <DateTimePickerFlow
        initial={pickerSeed}
        minimumDate={new Date()}
        maximumDate={new Date(Date.now() + 60 * 86_400_000)}
        onDone={(value) => {
          setProposedAt(value);
          setPickerSeed(null);
        }}
        onCancel={() => setPickerSeed(null)}
      />
    </>
  );
}

function RecipientRow({ profile }: { profile: Profile }) {
  const { colors, type } = useTheme();

  const meta = [
    profile.age !== null ? `${profile.age}` : null,
    profile.area,
    Format.distance(profile.distanceKm),
  ]
    .filter((part): part is string => !!part && part.length > 0)
    .join(' · ');

  return (
    <View style={[styles.recipient, { backgroundColor: colors.surfaceSunken }]}>
      <AppAvatar
        name={profile.displayName}
        imageUrl={profile.avatarUrl}
        size={40}
        isOnline={profile.isOnline}
        showPresence
      />
      <View style={styles.recipientBody}>
        <Text style={type.bodyStrong}>{profile.displayName}</Text>
        {meta.length > 0 ? (
          <Text style={[type.caption, { color: colors.inkMuted, marginTop: 1 }]}>{meta}</Text>
        ) : null}
      </View>
    </View>
  );
}

function PlanSummary({ activity }: { activity: Activity }) {
  const { colors, type, isDark } = useTheme();

  return (
    <View
      style={[styles.plan, { backgroundColor: categoryTint(activity.category, isDark) }]}
    >
      <CategoryBadge category={activity.category} size={38} radius={12} />
      <View style={styles.planBody}>
        <Text style={[type.label, { color: categoryForeground(activity.category, isDark) }]}>
          {Format.whenLabel(activity.startsAt)}
        </Text>
        <Text
          numberOfLines={1}
          style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}
        >
          {activity.locationName}
        </Text>
      </View>
    </View>
  );
}

function SentConfirmation({ profile, onDismiss }: { profile: Profile; onDismiss: () => void }) {
  const { colors, type } = useTheme();

  return (
    <AppSheet visible onDismiss={onDismiss} scrollable={false}>
      <View style={styles.confirmation}>
        <View style={{ height: AppSpacing.lg }} />
        <SuccessBurst size={88} color={colors.primary} />
        <Text style={[type.title, { marginTop: AppSpacing.xxl }]}>Invitation sent</Text>
        <Text
          style={[
            type.body,
            styles.centered,
            { color: colors.inkMuted, lineHeight: 22, marginTop: AppSpacing.sm },
          ]}
        >
          {`${firstName(profile)} has 3 days to reply. You will get a message the moment they do.`}
        </Text>

        <View style={{ height: AppSpacing.xxxl, width: '100%' }} />
        <View style={styles.fullWidth}>
          <AppButton label="Done" onPress={onDismiss} />
        </View>
        <PressEffect onPress={onDismiss}>
          <View style={{ padding: AppSpacing.md }}>
            <Text style={[type.label, { color: colors.inkMuted }]}>Keep browsing</Text>
          </View>
        </PressEffect>
      </View>
    </AppSheet>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginTop: AppSpacing.md },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  errorRow: { flexDirection: 'row', alignItems: 'center', marginBottom: AppSpacing.md },
  recipient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.md,
    borderRadius: AppRadii.md,
  },
  recipientBody: { flex: 1, marginLeft: AppSpacing.md },
  plan: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.md,
  },
  planBody: { flex: 1, marginLeft: AppSpacing.lg },
  confirmation: { alignItems: 'center', paddingTop: AppSpacing.lg },
  centered: { textAlign: 'center' },
  fullWidth: { width: '100%' },
});
