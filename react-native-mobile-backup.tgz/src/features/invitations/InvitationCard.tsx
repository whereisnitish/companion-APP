import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppButton,
  AppSheet,
  ConfirmSheet,
  PressEffect,
  StatusPill,
  SuccessBurst,
  VerifiedBadge,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Format } from '../../core/utils/formatters';
import {
  categoryForeground,
  categoryMeta,
  categoryTint,
  isInvitationOpen,
  isVerified,
} from '../../models/enums';
import {
  headline,
  isReceived as isReceivedInvitation,
  resolvedCategory,
  type Invitation,
} from '../../models/invitation';
import { firstName } from '../../models/profile';
import type { RootStackParamList } from '../../navigation/types';
import { invalidateSocialGraph } from '../../queries';
import { invitationService } from '../../services';
import { AppRadii, AppSpacing, useTheme, withAlpha } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * One invitation, with its answer built in.
 *
 * Accept and Decline live on the card itself: making someone open a detail
 * screen to say yes is the surest way to lose the yes.
 */
export function InvitationCard({ invitation }: { invitation: Invitation }) {
  const { colors, type, isDark } = useTheme();
  const navigation = useNavigation<Navigation>();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();

  const [isBusy, setIsBusy] = useState(false);
  const [confirm, setConfirm] = useState<'decline' | 'withdraw' | null>(null);
  const [connected, setConnected] = useState<Invitation | null>(null);

  const category = resolvedCategory(invitation);
  const meta = categoryMeta(category);
  const isPending = isInvitationOpen(invitation.status);
  const isReceived = isReceivedInvitation(invitation);
  const counterpartName = firstName(invitation.counterpart);

  const run = async (action: () => Promise<void>) => {
    setIsBusy(true);
    try {
      await action();
    } catch (error) {
      snackbar.error(
        error instanceof ApiException ? error.message : 'Something went wrong. Please try again.',
      );
    } finally {
      setIsBusy(false);
    }
  };

  const accept = () =>
    run(async () => {
      const updated = await invitationService.accept(invitation.id);
      invalidateSocialGraph(queryClient);
      setConnected(updated);
    });

  const decline = () =>
    run(async () => {
      await invitationService.decline(invitation.id);
      invalidateSocialGraph(queryClient);
      snackbar.show('Invitation declined.');
    });

  const withdraw = () =>
    run(async () => {
      await invitationService.cancel(invitation.id);
      invalidateSocialGraph(queryClient);
      snackbar.show('Invitation withdrawn.');
    });

  const planMeta = [
    invitation.proposedAt ? Format.whenLabel(invitation.proposedAt) : null,
    invitation.locationName,
  ]
    .filter((part): part is string => !!part && part.length > 0)
    .join(' · ');

  return (
    <>
      <View
        style={[
          styles.card,
          {
            backgroundColor: colors.surface,
            borderColor:
              isPending && isReceived ? withAlpha(colors.accent, 0.35) : colors.border,
          },
        ]}
      >
        <View style={{ padding: AppSpacing.lg }}>
          <View style={styles.head}>
            <PressEffect
              onPress={() =>
                navigation.navigate('PersonProfile', { userId: invitation.counterpart.id })
              }
              scale={0.94}
            >
              <AppAvatar
                name={invitation.counterpart.displayName}
                imageUrl={invitation.counterpart.avatarUrl}
                size={44}
                isOnline={invitation.counterpart.isOnline}
                showPresence
              />
            </PressEffect>

            <View style={styles.headBody}>
              <View style={styles.nameRow}>
                <Text numberOfLines={1} style={[type.bodyStrong, styles.name]}>
                  {invitation.counterpart.displayName}
                </Text>
                {isVerified(invitation.counterpart.verification) ? (
                  <View style={{ marginLeft: AppSpacing.xs + 2 }}>
                    <VerifiedBadge size={14} status={invitation.counterpart.verification} />
                  </View>
                ) : null}
              </View>
              <Text style={[type.caption, { color: colors.inkMuted, marginTop: 1 }]}>
                {`${isReceived ? 'Invited you' : 'You invited them'} · ${Format.relative(
                  invitation.createdAt,
                )}`}
              </Text>
            </View>

            {!isPending ? <StatusPill status={invitation.status} /> : null}
          </View>

          <View
            style={[
              styles.plan,
              { backgroundColor: categoryTint(category, isDark), marginTop: AppSpacing.lg },
            ]}
          >
            <MaterialIcons
              name={meta.icon}
              size={17}
              color={categoryForeground(category, isDark)}
            />
            <View style={styles.planBody}>
              <Text numberOfLines={2} style={[type.label, { color: colors.ink }]}>
                {headline(invitation)}
              </Text>
              {planMeta.length > 0 ? (
                <Text
                  numberOfLines={1}
                  style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}
                >
                  {planMeta}
                </Text>
              ) : null}
            </View>
            {invitation.activity ? (
              <PressEffect
                onPress={() =>
                  navigation.navigate('ActivityDetail', {
                    activityId: invitation.activity?.id ?? '',
                  })
                }
                scale={0.9}
              >
                <MaterialIcons
                  name="chevron-right"
                  size={20}
                  color={categoryForeground(category, isDark)}
                />
              </PressEffect>
            ) : null}
          </View>

          {invitation.message.length > 0 ? (
            <Text
              numberOfLines={3}
              style={[
                type.body,
                { color: colors.inkMuted, lineHeight: 22, marginTop: AppSpacing.md },
              ]}
            >
              {`“${invitation.message}”`}
            </Text>
          ) : null}
        </View>

        {isPending && isReceived ? (
          <View style={[styles.footer, { borderTopColor: colors.border }]}>
            <View style={styles.footerHalf}>
              <AppButton
                label="Decline"
                variant="secondary"
                size="medium"
                onPress={isBusy ? null : () => setConfirm('decline')}
              />
            </View>
            <View style={styles.footerWide}>
              <AppButton
                label="Accept"
                size="medium"
                icon="check"
                isLoading={isBusy}
                onPress={isBusy ? null : accept}
              />
            </View>
          </View>
        ) : isPending && !isReceived ? (
          <View style={[styles.footerRow, { borderTopColor: colors.border }]}>
            <MaterialIcons name="schedule" size={15} color={colors.inkFaint} />
            <Text
              style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.sm, flex: 1 }]}
            >
              {`Waiting on ${counterpartName}`}
            </Text>
            <AppButton
              label="Withdraw"
              variant="ghost"
              size="small"
              expand={false}
              onPress={isBusy ? null : () => setConfirm('withdraw')}
            />
          </View>
        ) : invitation.status === 'ACCEPTED' && invitation.conversationId ? (
          <View style={[styles.footerRow, { borderTopColor: colors.border }]}>
            <MaterialIcons name="check-circle" size={15} color={colors.success} />
            <Text
              style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.sm, flex: 1 }]}
            >
              You are connected
            </Text>
            <AppButton
              label="Open chat"
              size="small"
              expand={false}
              variant="secondary"
              onPress={() =>
                navigation.navigate('Chat', { conversationId: invitation.conversationId ?? '' })
              }
            />
          </View>
        ) : null}
      </View>

      <ConfirmSheet
        visible={confirm === 'decline'}
        title="Decline this invitation?"
        message={`${counterpartName} is told you are not free for this one. Nothing else is shared.`}
        confirmLabel="Decline"
        cancelLabel="Not yet"
        icon="do-not-disturb-alt"
        onConfirm={() => {
          setConfirm(null);
          void decline();
        }}
        onCancel={() => setConfirm(null)}
      />

      <ConfirmSheet
        visible={confirm === 'withdraw'}
        title="Withdraw this invitation?"
        message={`It disappears from ${counterpartName}’s list.`}
        confirmLabel="Withdraw"
        isDestructive
        icon="undo"
        onConfirm={() => {
          setConfirm(null);
          void withdraw();
        }}
        onCancel={() => setConfirm(null)}
      />

      {connected ? (
        <ConnectedSheet
          invitation={connected}
          onDismiss={() => setConnected(null)}
          onOpenChat={
            connected.conversationId
              ? () => {
                  const conversationId = connected.conversationId ?? '';
                  setConnected(null);
                  navigation.navigate('Chat', { conversationId });
                }
              : null
          }
        />
      ) : null}
    </>
  );
}

/** The payoff moment. Both faces, the plan, and one obvious next step. */
function ConnectedSheet({
  invitation,
  onDismiss,
  onOpenChat,
}: {
  invitation: Invitation;
  onDismiss: () => void;
  onOpenChat: (() => void) | null;
}) {
  const { colors, type } = useTheme();

  return (
    <AppSheet visible onDismiss={onDismiss} dismissible={false} scrollable={false}>
      <View style={styles.connected}>
        <View style={{ height: AppSpacing.lg }} />
        <SuccessBurst size={88} color={colors.success} />
        <Text style={[type.title, { marginTop: AppSpacing.xxl }]}>You’re connected</Text>
        <Text
          style={[
            type.body,
            styles.centered,
            { color: colors.inkMuted, lineHeight: 22, marginTop: AppSpacing.sm },
          ]}
        >
          {`You and ${firstName(invitation.counterpart)} are in for ${headline(
            invitation,
          ).toLowerCase()}. The chat is open — sort out the details.`}
        </Text>

        <View style={{ marginTop: AppSpacing.xxl }}>
          <AppAvatar
            name={invitation.counterpart.displayName}
            imageUrl={invitation.counterpart.avatarUrl}
            size={56}
            ring={colors.surface}
          />
        </View>

        <View style={{ height: AppSpacing.xxxl }} />
        <View style={styles.fullWidth}>
          {onOpenChat ? (
            <AppButton label="Say hello" icon="chat-bubble-outline" onPress={onOpenChat} />
          ) : null}
          <View style={{ height: AppSpacing.md }} />
          <AppButton label="Later" variant="ghost" size="large" onPress={onDismiss} />
        </View>
      </View>
    </AppSheet>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: AppRadii.lg, borderWidth: 1, overflow: 'hidden' },
  head: { flexDirection: 'row', alignItems: 'center' },
  headBody: { flex: 1, marginHorizontal: AppSpacing.md },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  name: { flexShrink: 1 },
  plan: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.md,
    borderRadius: AppRadii.md,
  },
  planBody: { flex: 1, marginHorizontal: AppSpacing.md },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingTop: AppSpacing.md,
    paddingBottom: AppSpacing.lg,
    borderTopWidth: 1,
  },
  footerHalf: { flex: 1, marginRight: AppSpacing.md },
  footerWide: { flex: 2 },
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
    borderTopWidth: 1,
  },
  connected: { alignItems: 'center', paddingTop: AppSpacing.lg },
  centered: { textAlign: 'center' },
  fullWidth: { width: '100%' },
});
