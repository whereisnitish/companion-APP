import React, { useState } from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  Entrance,
  ErrorStateView,
  PressEffect,
  Shimmer,
  SkeletonBox,
  StateView,
} from '../../components';
import { isInvitationOpen } from '../../models/enums';
import { EMPTY_INVITATION_COUNTS, type InvitationDirection } from '../../models/invitation';
import type { RootStackParamList } from '../../navigation/types';
import {
  queryKeys,
  useInvitationCounts,
  useReceivedInvitations,
  useSentInvitations,
} from '../../queries';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { InvitationCard } from './InvitationCard';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Received and sent, in that order — what people came here to answer sits
 * first, and the pending ones float to the top of each list.
 */
export function InvitationsScreen() {
  const { colors, type } = useTheme();
  const [direction, setDirection] = useState<InvitationDirection>('received');

  const { data } = useInvitationCounts();
  const counts = data ?? EMPTY_INVITATION_COUNTS;

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <Text style={type.headline}>Invitations</Text>
        <Text style={[type.bodySmall, { color: colors.inkMuted, marginTop: AppSpacing.xs }]}>
          {counts.pendingReceived === 0
            ? 'Nothing waiting on you right now.'
            : `${counts.pendingReceived} waiting on your answer.`}
        </Text>

        <View style={{ height: AppSpacing.lg }} />
        <Tabs
          direction={direction}
          onChange={setDirection}
          receivedBadge={counts.pendingReceived}
          sentBadge={counts.pendingSent}
        />
      </View>

      <View style={styles.body}>
        <InvitationList direction={direction} />
      </View>
    </SafeAreaView>
  );
}

function Tabs({
  direction,
  onChange,
  receivedBadge,
  sentBadge,
}: {
  direction: InvitationDirection;
  onChange: (direction: InvitationDirection) => void;
  receivedBadge: number;
  sentBadge: number;
}) {
  const { colors, type } = useTheme();

  const tab = (value: InvitationDirection, label: string, badge: number) => {
    const isSelected = direction === value;
    return (
      <View style={styles.tab}>
        <PressEffect onPress={() => onChange(value)} scale={0.97}>
          <View
            style={[
              styles.tabBody,
              {
                backgroundColor: isSelected ? colors.surface : 'transparent',
                borderColor: isSelected ? colors.border : 'transparent',
              },
            ]}
          >
            <Text
              numberOfLines={1}
              style={[type.label, { color: isSelected ? colors.ink : colors.inkFaint }]}
            >
              {label}
            </Text>
            {badge > 0 ? (
              <View style={[styles.badge, { backgroundColor: colors.accent }]}>
                <Text style={[type.caption, styles.badgeText]}>{badge}</Text>
              </View>
            ) : null}
          </View>
        </PressEffect>
      </View>
    );
  };

  return (
    <View style={[styles.tabs, { backgroundColor: colors.surfaceSunken }]}>
      {tab('received', 'Received', receivedBadge)}
      {tab('sent', 'Sent', sentBadge)}
    </View>
  );
}

function InvitationList({ direction }: { direction: InvitationDirection }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const queryClient = useQueryClient();

  const isReceived = direction === 'received';
  const received = useReceivedInvitations();
  const sent = useSentInvitations();
  const query = isReceived ? received : sent;

  const { data, isPending, error, refetch, isRefetching } = query;

  if (isPending) {
    return (
      <Shimmer>
        <ScrollView contentContainerStyle={styles.listContent}>
          {[0, 1, 2, 3].map((index) => (
            <View key={index} style={{ marginBottom: AppSpacing.md }}>
              <SkeletonBox height={148} radius={AppRadii.lg} width="100%" />
            </View>
          ))}
        </ScrollView>
      </Shimmer>
    );
  }

  if (error) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      </ScrollView>
    );
  }

  const items = data ?? [];

  if (items.length === 0) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <StateView
          icon={isReceived ? 'mark-email-unread' : 'send'}
          title={isReceived ? 'No invitations yet' : 'You have not invited anyone'}
          message={
            isReceived
              ? 'When someone asks you to join them, it lands here. Posting a plan is the fastest way to get one.'
              : 'Find someone who is up for the same thing and send the first invitation.'
          }
          actionLabel={isReceived ? 'Post a plan' : 'Discover people'}
          onAction={() =>
            navigation.navigate('Tabs', { screen: isReceived ? 'Home' : 'Discover' })
          }
        />
      </ScrollView>
    );
  }

  // Pending first — everything else is history.
  const pending = items.filter((item) => isInvitationOpen(item.status));
  const settled = items.filter((item) => !isInvitationOpen(item.status));

  return (
    <ScrollView
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={isRefetching}
          onRefresh={() => {
            void refetch();
            void queryClient.invalidateQueries({ queryKey: queryKeys.invitationCounts });
          }}
          tintColor={colors.primary}
        />
      }
    >
      {pending.map((invitation, index) => (
        <View key={invitation.id} style={{ marginBottom: AppSpacing.md }}>
          <Entrance index={index}>
            <InvitationCard invitation={invitation} />
          </Entrance>
        </View>
      ))}

      {settled.length > 0 ? (
        <>
          <Text
            style={[
              type.overline,
              {
                color: colors.inkFaint,
                marginLeft: AppSpacing.xs,
                marginTop: AppSpacing.xl,
                marginBottom: AppSpacing.md,
              },
            ]}
          >
            EARLIER
          </Text>
          {settled.map((invitation) => (
            <View key={invitation.id} style={{ marginBottom: AppSpacing.md }}>
              <InvitationCard invitation={invitation} />
            </View>
          ))}
        </>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: AppSpacing.screenX, paddingVertical: AppSpacing.lg },
  body: { flex: 1 },
  listContent: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.sm,
    paddingBottom: AppSpacing.giant,
  },
  stateBody: { flexGrow: 1, paddingTop: 30 },
  tabs: { flexDirection: 'row', padding: 3, borderRadius: AppRadii.pill },
  tab: { flex: 1 },
  tabBody: {
    height: 38,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
    borderWidth: 1,
  },
  badge: {
    minWidth: 18,
    height: 18,
    paddingHorizontal: 5,
    marginLeft: AppSpacing.sm,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
  },
  badgeText: { color: '#FFFFFF', fontSize: 10.5, lineHeight: 14, fontWeight: '700' },
});
