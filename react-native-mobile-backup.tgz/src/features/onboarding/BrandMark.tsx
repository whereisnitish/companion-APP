import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, Defs, ClipPath, G } from 'react-native-svg';

import { useTheme, withAlpha } from '../../theme';

const easeOutCubic = (t: number) => 1 - (1 - t) ** 3;
const lerp = (from: number, to: number, t: number) => from + (to - from) * easeOutCubic(t);

interface BrandMarkProps {
  size?: number;
  progress?: number;
  color?: string;
  accentColor?: string;
  strokeWidth?: number;
}

/**
 * The Companion mark: two rings that overlap.
 *
 * Not a heart, not a flame, not a chat bubble — two separate circles that
 * choose to intersect. `progress` drives them from apart to together, which is
 * the entire brand argument in one gesture.
 */
export function BrandMark({
  size = 72,
  progress = 1,
  color,
  accentColor,
  strokeWidth = 2.4,
}: BrandMarkProps) {
  const { colors } = useTheme();
  const primary = color ?? colors.primary;
  const accent = accentColor ?? colors.accent;

  const t = Math.min(Math.max(progress, 0), 1);
  const centre = size / 2;
  const radius = size * 0.28;

  // Apart at 0, overlapping by a third of a radius at 1.
  const separation = lerp(radius * 1.6, radius * 0.62, t);
  const overlapping = separation < radius;

  return (
    <View style={{ height: size, width: size }}>
      <Svg width={size} height={size}>
        {/* The overlap fills in only once the rings actually meet. */}
        {overlapping ? (
          <Defs>
            <ClipPath id="brand-lens">
              <Circle cx={centre - separation} cy={centre} r={radius} />
            </ClipPath>
          </Defs>
        ) : null}

        {overlapping ? (
          <G clipPath="url(#brand-lens)">
            <Circle
              cx={centre + separation}
              cy={centre}
              r={radius}
              fill={withAlpha(primary, 0.12 * t)}
            />
          </G>
        ) : null}

        <Circle
          cx={centre - separation}
          cy={centre}
          r={radius}
          stroke={primary}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
        />
        <Circle
          cx={centre + separation}
          cy={centre}
          r={radius}
          stroke={withAlpha(accent, 0.55 + 0.45 * t)}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
        />
      </Svg>
    </View>
  );
}
