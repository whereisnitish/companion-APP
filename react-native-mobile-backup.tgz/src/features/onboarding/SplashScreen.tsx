import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { BrandMark } from './BrandMark';
import { AppSpacing, useTheme } from '../../theme';

const DURATION = 1500;

const clamp01 = (value: number) => Math.min(Math.max(value, 0), 1);
const easeOutCubic = (t: number) => 1 - (1 - t) ** 3;

/** Maps the shared 0→1 timeline onto one segment of it, eased. */
const segment = (progress: number, start: number, end: number) =>
  easeOutCubic(clamp01((progress - start) / (end - start)));

/**
 * The mark draws itself together, the wordmark settles under it. Roughly a
 * second — long enough to register, short enough that nobody waits for it.
 * Routing happens independently, so a fast session restore is never blocked.
 *
 * Driven from JS rather than the UI thread: `BrandMark` recomputes its geometry
 * in JS on every frame anyway, so a worklet would have to cross back on each
 * one.
 */
export function SplashScreen() {
  const { colors, type } = useTheme();
  const [progress, setProgress] = useState(0);
  const frame = useRef<number | null>(null);

  useEffect(() => {
    const startedAt = Date.now();
    let cancelled = false;

    const tick = () => {
      if (cancelled) return;
      const elapsed = (Date.now() - startedAt) / DURATION;
      setProgress(clamp01(elapsed));
      if (elapsed < 1) frame.current = requestAnimationFrame(tick);
    };

    frame.current = requestAnimationFrame(tick);
    return () => {
      // The flag matters as well as the cancel: a frame already queued must not
      // set state on an unmounted splash.
      cancelled = true;
      if (frame.current !== null) cancelAnimationFrame(frame.current);
    };
  }, []);

  const mark = segment(progress, 0.05, 0.62);
  const wordmark = segment(progress, 0.42, 0.9);
  const tagline = segment(progress, 0.6, 1);

  return (
    <View style={[styles.container, { backgroundColor: colors.canvas }]}>
      <BrandMark
        size={96}
        progress={mark}
        color={colors.primary}
        accentColor={colors.accent}
        strokeWidth={2.6}
      />

      <View
        style={{
          marginTop: AppSpacing.xxxl,
          opacity: wordmark,
          transform: [{ translateY: 10 * (1 - wordmark) }],
        }}
      >
        <Text style={type.headline}>Companion</Text>
      </View>

      <View style={{ marginTop: AppSpacing.md, opacity: tagline * 0.9 }}>
        <Text style={[type.body, { color: colors.inkMuted }]}>Never do it alone.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
