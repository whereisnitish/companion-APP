import React from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import Svg, { Circle, G, Rect } from 'react-native-svg';

import { useTheme, withAlpha } from '../../theme';

const easeOutCubic = (t: number) => 1 - (1 - t) ** 3;
const clamp01 = (value: number) => Math.min(Math.max(value, 0), 1);

interface OnboardingArtProps {
  variant: number;
  progress: number;
  palette: string[];
}

/**
 * The abstract compositions behind each onboarding page.
 *
 * Drawn rather than shipped as assets: they scale to any screen, they pick up
 * the theme, and they cannot look like stock illustration.
 */
export function OnboardingArt({ variant, progress, palette }: OnboardingArtProps) {
  const { colors } = useTheme();
  const [size, setSize] = React.useState({ width: 0, height: 0 });

  const onLayout = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setSize({ width, height });
  };

  const t = easeOutCubic(clamp01(progress));
  const ready = size.width > 0 && size.height > 0;

  return (
    <View style={{ flex: 1 }} onLayout={onLayout}>
      {ready ? (
        <Svg width={size.width} height={size.height}>
          {variant % 4 === 0 ? (
            <Converging {...size} t={t} palette={palette} />
          ) : variant % 4 === 1 ? (
            <Tiles {...size} t={t} palette={palette} />
          ) : variant % 4 === 2 ? (
            <Stack {...size} t={t} palette={palette} surface={colors.surface} />
          ) : (
            <Orbit {...size} t={t} palette={palette} />
          )}
        </Svg>
      ) : null}
    </View>
  );
}

interface ArtProps {
  width: number;
  height: number;
  t: number;
  palette: string[];
}

const hue = (palette: string[], index: number) =>
  palette[index % palette.length] ?? palette[0] ?? '#000000';

/** Two arcs travelling toward each other — "don't do it alone". */
function Converging({ width, height, t, palette }: ArtProps) {
  const cx = width / 2;
  const cy = height / 2;
  const shortest = Math.min(width, height);
  const radius = shortest * 0.3;
  const gap = radius * (1.5 - 0.85 * t);

  return (
    <G>
      {[0, 1, 2, 3].map((ring) => {
        const scale = 1 + ring * 0.22;
        const fade = (1 - ring * 0.22) * t;
        return (
          <G key={ring}>
            <Circle
              cx={cx - gap}
              cy={cy}
              r={radius * scale}
              stroke={withAlpha(hue(palette, 0), 0.32 * fade)}
              strokeWidth={1.6}
              fill="none"
            />
            <Circle
              cx={cx + gap}
              cy={cy}
              r={radius * scale}
              stroke={withAlpha(hue(palette, 1), 0.32 * fade)}
              strokeWidth={1.6}
              fill="none"
            />
          </G>
        );
      })}
      <Circle cx={cx - gap} cy={cy} r={radius * 0.24} fill={withAlpha(hue(palette, 0), 0.85 * t)} />
      <Circle cx={cx + gap} cy={cy} r={radius * 0.24} fill={withAlpha(hue(palette, 1), 0.85 * t)} />
    </G>
  );
}

/** A loose grid of rounded tiles — "say what you're up for". */
function Tiles({ width, height, t, palette }: ArtProps) {
  const columns = 3;
  const rows = 3;
  const shortest = Math.min(width, height);
  const tile = shortest * 0.19;
  const gap = tile * 0.42;
  const totalWidth = columns * tile + (columns - 1) * gap;
  const totalHeight = rows * tile + (rows - 1) * gap;
  const originX = (width - totalWidth) / 2;
  const originY = (height - totalHeight) / 2;

  const cells: React.ReactNode[] = [];
  let index = 0;
  for (let row = 0; row < rows; row += 1) {
    for (let column = 0; column < columns; column += 1) {
      const delay = index * 0.07;
      const local = clamp01((t - delay) / (1 - delay));
      const lift = (1 - local) * tile * 0.5;
      const x = originX + column * (tile + gap);
      const y = originY + row * (tile + gap) + lift;
      const colour = hue(palette, index);

      cells.push(
        <G key={index}>
          <Rect
            x={x}
            y={y}
            width={tile}
            height={tile}
            rx={tile * 0.3}
            fill={withAlpha(colour, 0.16 * local)}
          />
          <Circle
            cx={x + tile / 2}
            cy={y + tile / 2}
            r={tile * 0.16}
            fill={withAlpha(colour, 0.75 * local)}
          />
        </G>,
      );
      index += 1;
    }
  }

  return <G>{cells}</G>;
}

/** Cards fanning out of a deck — "find someone who wants to join". */
function Stack({
  width,
  height,
  t,
  palette,
  surface,
}: ArtProps & { surface: string }) {
  const cx = width / 2;
  const cy = height / 2;
  const shortest = Math.min(width, height);
  const cardWidth = shortest * 0.44;
  const cardHeight = cardWidth * 1.26;

  return (
    <G>
      {[2, 1, 0].map((index) => {
        const local = clamp01((t - index * 0.12) / (1 - index * 0.12));
        const angle = ((index - 1) * 0.16 * local * 180) / Math.PI;
        const offsetX = (index - 1) * cardWidth * 0.34 * local;
        const colour = hue(palette, index);

        return (
          <G key={index} transform={`translate(${cx + offsetX}, ${cy}) rotate(${angle})`}>
            <Rect
              x={-cardWidth / 2}
              y={-cardHeight / 2}
              width={cardWidth}
              height={cardHeight}
              rx={cardWidth * 0.14}
              fill={withAlpha(surface, local)}
            />
            <Rect
              x={-cardWidth / 2}
              y={-cardHeight / 2}
              width={cardWidth}
              height={cardHeight}
              rx={cardWidth * 0.14}
              stroke={withAlpha(colour, 0.4 * local)}
              strokeWidth={1.2}
              fill="none"
            />
            <Circle
              cx={0}
              cy={-cardHeight * 0.18}
              r={cardWidth * 0.16}
              fill={withAlpha(colour, 0.5 * local)}
            />
            {[0, 1].map((line) => {
              const lineWidth = cardWidth * (line === 0 ? 0.56 : 0.36);
              return (
                <Rect
                  key={line}
                  x={-lineWidth / 2}
                  y={cardHeight * (0.12 + line * 0.14) - 3}
                  width={lineWidth}
                  height={6}
                  rx={3}
                  fill={withAlpha(colour, 0.22 * local)}
                />
              );
            })}
          </G>
        );
      })}
    </G>
  );
}

/** Dots orbiting a centre — "meet through what you actually want to do". */
function Orbit({ width, height, t, palette }: ArtProps) {
  const cx = width / 2;
  const cy = height / 2;
  const shortest = Math.min(width, height);
  const radius = shortest * 0.32;

  return (
    <G>
      {[0, 1, 2].map((index) => (
        <Circle
          key={`ring-${index}`}
          cx={cx}
          cy={cy}
          r={radius * (0.55 + index * 0.32)}
          stroke={withAlpha(hue(palette, index), 0.22 * t)}
          strokeWidth={1.2}
          fill="none"
        />
      ))}

      {Array.from({ length: 6 }, (_, index) => {
        const angle = (index / 6) * 2 * Math.PI + t * 0.5;
        const distance = radius * (index % 2 === 0 ? 0.87 : 0.55);
        return (
          <Circle
            key={`dot-${index}`}
            cx={cx + Math.cos(angle) * distance}
            cy={cy + Math.sin(angle) * distance}
            r={shortest * 0.032 * t}
            fill={withAlpha(hue(palette, index), 0.8 * t)}
          />
        );
      })}

      <Circle cx={cx} cy={cy} r={shortest * 0.055 * t} fill={withAlpha(hue(palette, 0), 0.9 * t)} />
    </G>
  );
}
