import React, { useRef, useState } from 'react';
import {
  Dimensions,
  FlatList,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AppButton } from '../../components';
import { useAuthStore } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { BrandMark } from './BrandMark';
import { OnboardingArt } from './OnboardingArt';

interface Page {
  eyebrow: string;
  title: string;
  body: string;
  palette: string[];
}

const PAGES: Page[] = [
  {
    eyebrow: 'The idea',
    title: 'Don’t do it alone.',
    body:
      'The film you keep postponing. The restaurant you never book. Most plans die because nobody wants to go by themselves.',
    palette: ['#14453A', '#C0603A', '#4B5BA6'],
  },
  {
    eyebrow: 'Say it out loud',
    title: 'Post what you’re up for.',
    body:
      'Movies. Dinner. Coffee. A 6am walk. Put the plan out there with a time and a place, and let the right person find it.',
    palette: ['#4B5BA6', '#2F7A5E', '#B0821F', '#8C4A70'],
  },
  {
    eyebrow: 'Find your company',
    title: 'Someone nearby is free too.',
    body:
      'Browse people by what they actually want to do and when they’re actually free. Send an invitation, not a pick-up line.',
    palette: ['#C0603A', '#14453A', '#2B7683'],
  },
  {
    eyebrow: 'Then go',
    title: 'Meet through the thing itself.',
    body:
      'When they accept, a conversation opens with the plan already in it. No small talk about the weather — you have somewhere to be.',
    palette: ['#2F7A5E', '#A43F5F', '#6A4FA3', '#B0821F'],
  },
];

export function OnboardingScreen() {
  const { colors, type } = useTheme();
  const completeOnboarding = useAuthStore((state) => state.completeOnboarding);

  const listRef = useRef<FlatList<Page>>(null);
  const [index, setIndex] = useState(0);
  /** Fractional page position, so the art can respond to a half-swipe. */
  const [page, setPage] = useState(0);
  const [width, setWidth] = useState(Dimensions.get('window').width);

  const isLast = index === PAGES.length - 1;

  const finish = () => {
    void completeOnboarding();
  };

  const next = () => {
    if (isLast) {
      finish();
      return;
    }
    listRef.current?.scrollToIndex({ index: index + 1, animated: true });
  };

  const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (width <= 0) return;
    const position = event.nativeEvent.contentOffset.x / width;
    setPage(position);
    const nearest = Math.round(position);
    if (nearest !== index) setIndex(nearest);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <BrandMark size={26} color={colors.primary} accentColor={colors.accent} />
        <Text style={[type.label, { marginLeft: AppSpacing.md }]}>Companion</Text>
        <View style={styles.spacer} />
        <View style={{ opacity: isLast ? 0 : 1 }}>
          <AppButton
            label="Skip"
            variant="ghost"
            size="small"
            expand={false}
            onPress={isLast ? null : finish}
          />
        </View>
      </View>

      <View
        style={styles.pager}
        onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
      >
        <FlatList
          ref={listRef}
          data={PAGES}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={onScroll}
          scrollEventThrottle={16}
          keyExtractor={(item) => item.title}
          getItemLayout={(_, itemIndex) => ({
            length: width,
            offset: width * itemIndex,
            index: itemIndex,
          })}
          renderItem={({ item, index: pageIndex }) => {
            // 1 when this page is centred, falling off as it slides away.
            const focus = Math.min(Math.max(1 - Math.abs(page - pageIndex), 0), 1);

            return (
              <View style={{ width }}>
                <View style={styles.art}>
                  <OnboardingArt variant={pageIndex} progress={focus} palette={item.palette} />
                </View>

                <View
                  style={[
                    styles.copy,
                    { opacity: focus, transform: [{ translateY: 16 * (1 - focus) }] },
                  ]}
                >
                  {/* Scrollable so the longest page still fits on a small
                      phone with the text scale turned up. */}
                  <ScrollView contentContainerStyle={styles.copyInner}>
                    <Text style={[type.overline, { color: colors.accent }]}>
                      {item.eyebrow.toUpperCase()}
                    </Text>
                    <Text style={[type.headline, { marginTop: AppSpacing.md }]}>{item.title}</Text>
                    <Text
                      style={[
                        type.body,
                        { color: colors.inkMuted, lineHeight: 24, marginTop: AppSpacing.lg },
                      ]}
                    >
                      {item.body}
                    </Text>
                  </ScrollView>
                </View>
              </View>
            );
          }}
        />
      </View>

      <View style={styles.footer}>
        {PAGES.map((item, dotIndex) => (
          <View
            key={item.title}
            style={[
              styles.dot,
              {
                width: dotIndex === index ? 22 : 6,
                backgroundColor: dotIndex === index ? colors.ink : colors.borderStrong,
              },
            ]}
          />
        ))}
        <View style={styles.spacer} />
        <AppButton
          label={isLast ? 'Get started' : 'Next'}
          onPress={next}
          expand={false}
          trailingIcon={isLast ? undefined : 'arrow-forward'}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: AppSpacing.screenX,
    paddingRight: AppSpacing.lg,
    paddingTop: AppSpacing.lg,
  },
  spacer: { flex: 1 },
  pager: { flex: 1 },
  art: { flex: 6, padding: AppSpacing.xxl },
  copy: { flex: 5 },
  copyInner: { paddingHorizontal: AppSpacing.xxxl, paddingBottom: AppSpacing.lg },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.xxxl,
    paddingTop: AppSpacing.lg,
    paddingBottom: AppSpacing.xxl,
  },
  dot: { height: 4, borderRadius: AppRadii.pill, marginRight: AppSpacing.sm },
});
