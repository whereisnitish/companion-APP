import React, { useState } from 'react';
import { Keyboard, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { AppButton, AppTextField, PressEffect, useSnackbar } from '../../components';
import { ApiException } from '../../core/network/apiException';
import type { RootStackParamList } from '../../navigation/types';
import { useAuthStore } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { AuthScaffold } from './AuthScaffold';
import { FormError } from './FormError';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

export function SignInScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const login = useAuthStore((state) => state.login);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const submit = async () => {
    if (isSubmitting) return;
    Keyboard.dismiss();

    setIsSubmitting(true);
    setFormError(null);
    setFieldErrors({});

    try {
      await login({ email: email.trim(), password });
      // The navigator's auth gate takes it from here.
    } catch (error) {
      if (error instanceof ApiException) {
        const hasFieldErrors = Object.keys(error.fieldErrors).length > 0;
        setFormError(hasFieldErrors ? null : error.message);
        setFieldErrors(error.fieldErrors);
      } else {
        setFormError('Something went wrong. Please try again.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AuthScaffold
      title="Welcome back."
      subtitle="Sign in to see who is free near you this week."
      footer={
        <View style={styles.footerRow}>
          <Text style={[type.bodySmall, { color: colors.inkMuted }]}>New here?</Text>
          <PressEffect onPress={() => navigation.replace('SignUp')} scale={0.94}>
            <View style={styles.footerLink}>
              <Text style={[type.label, { color: colors.primary }]}>Create an account</Text>
            </View>
          </PressEffect>
        </View>
      }
    >
      {[
        <AppTextField
          key="email"
          value={email}
          onChangeText={setEmail}
          label="Email"
          hint="you@example.com"
          prefixIcon="alternate-email"
          keyboardType="email-address"
          returnKeyType="next"
          autoComplete="email"
          errorText={fieldErrors.email}
          editable={!isSubmitting}
        />,
        <View key="password" style={{ marginTop: AppSpacing.xl }}>
          <AppTextField
            value={password}
            onChangeText={setPassword}
            label="Password"
            hint="Your password"
            prefixIcon="lock-outline"
            secureTextEntry
            returnKeyType="done"
            autoComplete="current-password"
            errorText={fieldErrors.password}
            editable={!isSubmitting}
            onSubmitEditing={submit}
          />
        </View>,
        <View key="error">
          {formError ? (
            <View style={{ marginTop: AppSpacing.lg }}>
              <FormError message={formError} />
            </View>
          ) : null}
        </View>,
        <View key="submit" style={{ marginTop: AppSpacing.xxl }}>
          <AppButton label="Sign in" isLoading={isSubmitting} onPress={submit} />
        </View>,
        <View key="demo" style={{ marginTop: AppSpacing.xxl }}>
          <DemoAccountHint />
        </View>,
      ]}
    </AuthScaffold>
  );
}

/**
 * The seeded demo account, offered rather than hidden in a README. It fills in
 * the credentials — it does not bypass authentication.
 */
function DemoAccountHint() {
  const { colors, type } = useTheme();
  const snackbar = useSnackbar();
  const login = useAuthStore((state) => state.login);
  const [isLoading, setIsLoading] = useState(false);

  const signInAsDemo = async () => {
    setIsLoading(true);
    try {
      await login({ email: 'demo@companion.app', password: 'Password123' });
    } catch {
      snackbar.error('Seed the database first: npm run db:seed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={[styles.demo, { backgroundColor: colors.surfaceSunken }]}>
      <View style={styles.demoHead}>
        <MaterialIcons name="science" size={16} color={colors.inkMuted} />
        <Text style={[type.label, { color: colors.ink, marginLeft: AppSpacing.sm }]}>
          Exploring the demo?
        </Text>
      </View>
      <Text
        style={[
          type.caption,
          { color: colors.inkMuted, lineHeight: 18, marginTop: AppSpacing.sm },
        ]}
      >
        The seeded database ships with a populated account. Everything you send is real — it just
        talks to your local server.
      </Text>
      <View style={{ marginTop: AppSpacing.md }}>
        <AppButton
          label="Sign in as demo@companion.app"
          variant="secondary"
          size="small"
          isLoading={isLoading}
          onPress={signInAsDemo}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  footerLink: { paddingVertical: AppSpacing.sm, marginLeft: AppSpacing.xs },
  demo: { padding: AppSpacing.lg, borderRadius: AppRadii.md },
  demoHead: { flexDirection: 'row', alignItems: 'center' },
});
