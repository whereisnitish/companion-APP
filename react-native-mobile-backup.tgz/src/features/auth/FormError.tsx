import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

import { AppRadii, AppSpacing, useTheme } from '../../theme';

/** The banner shown when the server rejects a form as a whole. */
export function FormError({ message }: { message: string }) {
  const { colors, type } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: colors.dangerSoft }]}>
      <MaterialIcons name="error-outline" size={18} color={colors.danger} />
      <Text style={[type.bodySmall, styles.text, { color: colors.danger }]}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
    borderRadius: AppRadii.md,
  },
  text: { flex: 1, marginLeft: AppSpacing.md },
});
