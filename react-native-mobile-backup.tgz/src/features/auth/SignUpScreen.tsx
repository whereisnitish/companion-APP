import React, { useState } from 'react';
import { Keyboard, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { AppButton, AppTextField, PressEffect } from '../../components';
import { ApiException } from '../../core/network/apiException';
import type { RootStackParamList } from '../../navigation/types';
import { useAuthStore } from '../../stores';
import { AppSpacing, useTheme } from '../../theme';
import { AuthScaffold } from './AuthScaffold';
import { FormError } from './FormError';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

export function SignUpScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const register = useAuthStore((state) => state.register);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Live requirements beat a rejected form. Each rule is checkable at a glance.
  const hasLength = password.length >= 8;
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const canSubmit = hasLength && hasLetter && hasNumber && email.includes('@');

  const submit = async () => {
    if (isSubmitting || !canSubmit) return;
    Keyboard.dismiss();

    setIsSubmitting(true);
    setFormError(null);
    setFieldErrors({});

    try {
      await register({ email: email.trim(), password });
    } catch (error) {
      if (error instanceof ApiException) {
        const hasFieldErrors = Object.keys(error.fieldErrors).length > 0;
        setFormError(hasFieldErrors ? null : error.message);
        setFieldErrors(error.fieldErrors);
      } else {
        setFormError('Something went wrong. Please try again.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AuthScaffold
      title={'Let’s get you\nsome company.'}
      subtitle="Two fields now, the interesting part next."
      footer={
        <View style={styles.footerRow}>
          <Text style={[type.bodySmall, { color: colors.inkMuted }]}>
            Already have an account?
          </Text>
          <PressEffect onPress={() => navigation.replace('SignIn')} scale={0.94}>
            <View style={styles.footerLink}>
              <Text style={[type.label, { color: colors.primary }]}>Sign in</Text>
            </View>
          </PressEffect>
        </View>
      }
    >
      {[
        <AppTextField
          key="email"
          value={email}
          onChangeText={setEmail}
          label="Email"
          hint="you@example.com"
          prefixIcon="alternate-email"
          keyboardType="email-address"
          returnKeyType="next"
          autoComplete="email"
          errorText={fieldErrors.email}
          editable={!isSubmitting}
        />,
        <View key="password" style={{ marginTop: AppSpacing.xl }}>
          <AppTextField
            value={password}
            onChangeText={setPassword}
            label="Password"
            hint="At least 8 characters"
            prefixIcon="lock-outline"
            secureTextEntry
            returnKeyType="done"
            autoComplete="new-password"
            errorText={fieldErrors.password}
            editable={!isSubmitting}
            onSubmitEditing={submit}
          />
        </View>,
        <View key="requirements" style={styles.requirements}>
          <Requirement label="8+ characters" met={hasLength} />
          <Requirement label="A letter" met={hasLetter} />
          <Requirement label="A number" met={hasNumber} />
        </View>,
        <View key="error">
          {formError ? (
            <View style={{ marginTop: AppSpacing.lg }}>
              <FormError message={formError} />
            </View>
          ) : null}
        </View>,
        <View key="submit" style={{ marginTop: AppSpacing.xxl }}>
          <AppButton
            label="Continue"
            isLoading={isSubmitting}
            onPress={canSubmit ? submit : null}
          />
        </View>,
      ]}
    </AuthScaffold>
  );
}

function Requirement({ label, met }: { label: string; met: boolean }) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.requirement}>
      <View
        style={[
          styles.tick,
          { backgroundColor: met ? colors.success : colors.surfaceSunken },
        ]}
      >
        <MaterialIcons name="check" size={11} color={met ? '#FFFFFF' : colors.inkFaint} />
      </View>
      <Text style={[type.caption, { color: met ? colors.ink : colors.inkFaint }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  footerLink: { paddingVertical: AppSpacing.sm, marginLeft: AppSpacing.xs },
  requirements: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: AppSpacing.lg,
  },
  requirement: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: AppSpacing.lg,
    marginBottom: AppSpacing.sm,
  },
  tick: {
    height: 16,
    width: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: AppSpacing.sm,
  },
});
