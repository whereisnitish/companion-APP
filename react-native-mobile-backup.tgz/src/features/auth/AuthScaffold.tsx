import React, { type ReactNode } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

import { AppIconButton, Entrance } from '../../components';
import { AppSpacing, useTheme } from '../../theme';

interface AuthScaffoldProps {
  title: string;
  subtitle: string;
  children: ReactNode[];
  footer?: ReactNode;
}

/**
 * Shared chrome for sign-in and sign-up: a back affordance, a serif title,
 * a supporting line, then the form. Keeping this in one place is why both
 * screens feel like the same moment in the product rather than two forms.
 */
export function AuthScaffold({ title, subtitle, children, footer }: AuthScaffoldProps) {
  const { colors, type } = useTheme();
  const navigation = useNavigation();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <AppIconButton
          icon="arrow-back"
          bordered={false}
          background="transparent"
          onPress={navigation.canGoBack() ? () => navigation.goBack() : null}
          accessibilityLabel="Go back"
        />
      </View>

      <ScrollView
        contentContainerStyle={styles.body}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
      >
        <Entrance>
          <Text style={type.headline}>{title}</Text>
        </Entrance>
        <Entrance index={1}>
          <Text
            style={[type.body, { color: colors.inkMuted, lineHeight: 23, marginTop: AppSpacing.md }]}
          >
            {subtitle}
          </Text>
        </Entrance>

        <View style={{ height: AppSpacing.xxxl }} />

        {children.map((child, index) => (
          <Entrance key={index} index={index + 2}>
            {child}
          </Entrance>
        ))}
      </ScrollView>

      {footer ? <View style={styles.footer}>{footer}</View> : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    paddingHorizontal: AppSpacing.md,
    paddingTop: AppSpacing.sm,
  },
  body: {
    paddingHorizontal: AppSpacing.xxl,
    paddingTop: AppSpacing.xl,
    paddingBottom: AppSpacing.xxxl,
  },
  footer: {
    paddingHorizontal: AppSpacing.xxl,
    paddingBottom: AppSpacing.xl,
  },
});
