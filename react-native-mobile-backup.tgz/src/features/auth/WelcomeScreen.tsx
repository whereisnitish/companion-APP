import React, { useEffect } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Animated, {
  Easing,
  type SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

import { AppButton, Entrance } from '../../components';
import {
  categoryForeground,
  categoryMeta,
  type ActivityCategory,
} from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { BrandMark } from '../onboarding/BrandMark';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * The doorway. One promise, one primary action, one quiet alternative.
 * The drifting category tiles do the selling so the copy does not have to.
 */
export function WelcomeScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.spacerLarge} />
        <Entrance>
          <DriftingCategories />
        </Entrance>
        <View style={styles.spacerLarge} />

        <Entrance index={1}>
          <BrandMark size={40} color={colors.primary} accentColor={colors.accent} />
        </Entrance>

        <Entrance index={2} style={{ marginTop: AppSpacing.xl }}>
          <Text style={type.display}>{'Never do\nit alone.'}</Text>
        </Entrance>

        <Entrance index={3} style={{ marginTop: AppSpacing.lg }}>
          <Text style={[type.body, { color: colors.inkMuted, lineHeight: 24 }]}>
            Find someone nearby who wants to do the same thing, at the same time.
          </Text>
        </Entrance>

        <View style={styles.spacer} />

        <Entrance index={4}>
          <AppButton label="Create an account" onPress={() => navigation.navigate('SignUp')} />
        </Entrance>

        <Entrance index={5} style={{ marginTop: AppSpacing.md }}>
          <AppButton
            label="I already have one"
            variant="secondary"
            onPress={() => navigation.navigate('SignIn')}
          />
        </Entrance>

        <Entrance index={6} style={{ marginTop: AppSpacing.xl }}>
          <View style={styles.legalRow}>
            <Text
              style={[
                type.caption,
                styles.legal,
                { color: colors.inkFaint, lineHeight: 18 },
              ]}
            >
              By continuing you agree to our Community Guidelines and Privacy Policy.
            </Text>
          </View>
        </Entrance>
      </ScrollView>
    </SafeAreaView>
  );
}

const TOP_ROW: ActivityCategory[] = ['MOVIE', 'DINNER', 'COFFEE', 'CONCERT', 'WALK', 'TRAVEL'];
const BOTTOM_ROW: ActivityCategory[] = ['SPORTS', 'SHOPPING', 'GAMING', 'STUDY', 'EVENT', 'OTHER'];

/**
 * Two rows of category pills scrolling slowly in opposite directions — the
 * product's vocabulary, shown rather than listed.
 */
function DriftingCategories() {
  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, { duration: 40_000, easing: Easing.linear }),
      -1,
      false,
    );
  }, [progress]);

  return (
    <View style={styles.drift}>
      <Marquee categories={TOP_ROW} progress={progress} reverse={false} />
      <View style={{ height: AppSpacing.md }} />
      <Marquee categories={BOTTOM_ROW} progress={progress} reverse />
    </View>
  );
}

const ITEM_WIDTH = 132;

function Marquee({
  categories,
  progress,
  reverse,
}: {
  categories: ActivityCategory[];
  progress: SharedValue<number>;
  reverse: boolean;
}) {
  const span = categories.length * ITEM_WIDTH;

  const animatedStyle = useAnimatedStyle(() => {
    const shift = progress.value * span;
    return { transform: [{ translateX: reverse ? shift - span : -shift }] };
  });

  return (
    <View style={styles.marquee}>
      <Animated.View style={[styles.marqueeRow, animatedStyle]}>
        {/* Two copies make the loop seamless at any offset. */}
        {[0, 1].map((copy) =>
          categories.map((category) => (
            <CategoryPill key={`${copy}-${category}`} category={category} />
          )),
        )}
      </Animated.View>
    </View>
  );
}

function CategoryPill({ category }: { category: ActivityCategory }) {
  const { colors, type, isDark } = useTheme();
  const meta = categoryMeta(category);

  return (
    <View
      style={[
        styles.pill,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <MaterialIcons name={meta.icon} size={17} color={categoryForeground(category, isDark)} />
      <Text
        numberOfLines={1}
        style={[type.label, { color: colors.ink, marginLeft: AppSpacing.sm, flexShrink: 1 }]}
      >
        {meta.label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: AppSpacing.xxl,
    paddingBottom: AppSpacing.lg,
  },
  spacer: { flex: 1, minHeight: AppSpacing.xxl },
  spacerLarge: { flex: 2, minHeight: AppSpacing.xxl },
  drift: { height: 116, marginHorizontal: -AppSpacing.xxl },
  marquee: { height: 50, overflow: 'hidden' },
  marqueeRow: { flexDirection: 'row' },
  pill: {
    width: ITEM_WIDTH - AppSpacing.md,
    height: 46,
    marginRight: AppSpacing.md,
    paddingHorizontal: AppSpacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: AppRadii.pill,
    borderWidth: 1,
  },
  legalRow: { alignItems: 'center' },
  legal: { width: 300, textAlign: 'center' },
});
