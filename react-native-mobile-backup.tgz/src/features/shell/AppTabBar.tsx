import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';

import { PressEffect } from '../../components';
import { useInvitationCounts, useUnreadMessages } from '../../queries';
import type { MaterialIconName } from '../../models/enums';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

interface Destination {
  name: string;
  label: string;
  icon: MaterialIconName;
  activeIcon: MaterialIconName;
}

/**
 * Five destinations, in the order the product is actually used:
 * what's on → who's around → who asked → who you're talking to → you.
 *
 * The stock tab bar was tempting; it also looks like every other app. This one
 * is a hairline bar with an icon swap and badges that count real things, which
 * is the only decoration it gets.
 */
const DESTINATIONS: Destination[] = [
  { name: 'Home', label: 'Home', icon: 'explore', activeIcon: 'explore' },
  { name: 'Discover', label: 'Discover', icon: 'search', activeIcon: 'saved-search' },
  { name: 'Invites', label: 'Invites', icon: 'mail-outline', activeIcon: 'mail' },
  { name: 'Messages', label: 'Messages', icon: 'chat-bubble-outline', activeIcon: 'chat-bubble' },
  { name: 'Me', label: 'You', icon: 'person-outline', activeIcon: 'person' },
];

export function AppTabBar({ state, navigation }: BottomTabBarProps) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  const { data: counts } = useInvitationCounts();
  const unreadMessages = useUnreadMessages();
  const pendingInvites = counts?.pendingReceived ?? 0;

  return (
    <View
      style={[
        styles.bar,
        {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          paddingBottom: insets.bottom,
        },
      ]}
    >
      <View style={styles.row}>
        {DESTINATIONS.map((destination, index) => {
          const isSelected = state.index === index;
          const badgeCount = index === 2 ? pendingInvites : index === 3 ? unreadMessages : 0;

          return (
            <View key={destination.name} style={styles.item}>
              <NavItem
                destination={destination}
                isSelected={isSelected}
                badgeCount={badgeCount}
                onPress={() => {
                  const route = state.routes[index];
                  if (!route) return;
                  const event = navigation.emit({
                    type: 'tabPress',
                    target: route.key,
                    canPreventDefault: true,
                  });
                  // Tapping the tab you are on pops that branch back to its root.
                  if (!event.defaultPrevented) {
                    navigation.navigate(route.name, route.params);
                  }
                }}
              />
            </View>
          );
        })}
      </View>
    </View>
  );
}

function NavItem({
  destination,
  isSelected,
  badgeCount,
  onPress,
}: {
  destination: Destination;
  isSelected: boolean;
  badgeCount: number;
  onPress: () => void;
}) {
  const { colors, type } = useTheme();
  const tint = isSelected ? colors.ink : colors.inkFaint;

  return (
    <PressEffect onPress={onPress} scale={0.9} accessibilityLabel={destination.label}>
      <View style={styles.navItem}>
        <View>
          <MaterialIcons
            name={isSelected ? destination.activeIcon : destination.icon}
            size={23}
            color={tint}
          />
          {badgeCount > 0 ? (
            <View
              style={[
                styles.badge,
                { backgroundColor: colors.accent, borderColor: colors.surface },
              ]}
            >
              <Text style={[type.caption, styles.badgeText]}>
                {badgeCount > 9 ? '9+' : `${badgeCount}`}
              </Text>
            </View>
          ) : null}
        </View>
        <Text
          style={[
            type.caption,
            {
              color: tint,
              fontSize: 10.5,
              lineHeight: 13,
              fontWeight: isSelected ? '600' : '500',
              marginTop: AppSpacing.xs + 2,
            },
          ]}
        >
          {destination.label}
        </Text>
      </View>
    </PressEffect>
  );
}

const styles = StyleSheet.create({
  bar: { borderTopWidth: 1 },
  row: { flexDirection: 'row', height: 62 },
  item: { flex: 1 },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', height: 62 },
  badge: {
    position: 'absolute',
    top: -4,
    right: -8,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
    borderWidth: 1.5,
  },
  badgeText: { color: '#FFFFFF', fontSize: 10, lineHeight: 13, fontWeight: '700' },
});
