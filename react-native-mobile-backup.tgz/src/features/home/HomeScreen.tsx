import React from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  ActivityCard,
  ActivityPreviewCard,
  AppAvatar,
  AppButton,
  AppIconButton,
  Entrance,
  ErrorStateView,
  PersonPreviewCard,
  PressEffect,
  SectionHeader,
  StateView,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import {
  categoryForeground,
  categoryMeta,
  categoryTint,
  type ActivityCategory,
} from '../../models/enums';
import { greetingLabel, orderedCategories, type CategoryCount, type HomeFeed } from '../../models/homeFeed';
import { firstName } from '../../models/profile';
import type { RootStackParamList } from '../../navigation/types';
import { useHomeFeed, useUnreadNotifications } from '../../queries';
import { NO_FILTERS } from '../../services/discoveryService';
import { useCurrentUser, useDiscoverStore } from '../../stores';
import { AppRadii, AppSpacing, useTheme, withAlpha } from '../../theme';
import { useInviteSheet } from '../invitations/InviteSheet';
import { HomeSkeleton } from './HomeSkeleton';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Home answers one question before anything else: **what can I do today?**
 *
 * So the categories sit directly under the greeting — the fastest route into
 * the product — and everything below is evidence that the answer is real:
 * what is on tonight, who is free, what is nearby.
 */
export function HomeScreen() {
  const { colors } = useTheme();
  const { data: feed, isPending, error, refetch, isRefetching } = useHomeFeed();

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      {isPending ? (
        <HomeSkeleton />
      ) : error ? (
        <ScrollView contentContainerStyle={styles.errorBody}>
          <ErrorStateView error={error} onRetry={() => void refetch()} />
        </ScrollView>
      ) : feed ? (
        <HomeContent
          feed={feed}
          refreshing={isRefetching}
          onRefresh={() => void refetch()}
        />
      ) : null}
    </SafeAreaView>
  );
}

function HomeContent({
  feed,
  refreshing,
  onRefresh,
}: {
  feed: HomeFeed;
  refreshing: boolean;
  onRefresh: () => void;
}) {
  const { colors } = useTheme();
  const navigation = useNavigation<Navigation>();
  const { showInvite } = useInviteSheet();
  const setFilters = useDiscoverStore((state) => state.setFilters);
  const setMode = useDiscoverStore((state) => state.setMode);

  const openCategory = (category: ActivityCategory) => {
    setFilters({ ...NO_FILTERS, activities: [category] });
    setMode('people');
    navigation.navigate('Tabs', { screen: 'Discover' });
  };

  const openDiscover = (mode: 'people' | 'activities') => {
    setMode(mode);
    navigation.navigate('Tabs', { screen: 'Discover' });
  };

  const categories = orderedCategories(feed);

  return (
    <ScrollView
      contentContainerStyle={styles.scroll}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={colors.primary}
          progressBackgroundColor={colors.surface}
        />
      }
    >
      <Entrance>
        <Greeting feed={feed} />
      </Entrance>

      {feed.pendingInvitations > 0 ? (
        <Entrance index={1} style={styles.bannerWrap}>
          <PendingInvitesBanner
            count={feed.pendingInvitations}
            onPress={() => navigation.navigate('Tabs', { screen: 'Invites' })}
          />
        </Entrance>
      ) : null}

      <Entrance index={2}>
        <SectionHeader title="What are you up for?" style={styles.categoryHeader} />
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.rail}
        >
          {categories.map((count) => (
            <View key={count.category} style={styles.railItem}>
              <CategoryTile count={count} onPress={() => openCategory(count.category)} />
            </View>
          ))}
        </ScrollView>
      </Entrance>

      {feed.tonight.length > 0 ? (
        <Entrance index={3}>
          <SectionHeader
            eyebrow="Short notice"
            title="Happening today"
            actionLabel="See all"
            onAction={() => openDiscover('activities')}
          />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.rail}
          >
            {feed.tonight.map((activity) => (
              <View key={activity.id} style={styles.railItem}>
                <ActivityPreviewCard
                  activity={activity}
                  onPress={() =>
                    navigation.navigate('ActivityDetail', { activityId: activity.id })
                  }
                />
              </View>
            ))}
          </ScrollView>
        </Entrance>
      ) : null}

      {feed.peopleNearby.length > 0 ? (
        <Entrance index={4}>
          <SectionHeader
            eyebrow="Nearby"
            title="Looking for company"
            subtitle="Sorted by what you both want to do."
            actionLabel="See all"
            onAction={() => openDiscover('people')}
          />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.rail}
          >
            {feed.peopleNearby.map((profile) => (
              <View key={profile.id} style={styles.railItem}>
                <PersonPreviewCard
                  profile={profile}
                  onPress={() => navigation.navigate('PersonProfile', { userId: profile.id })}
                  onInvite={() => showInvite({ profile })}
                />
              </View>
            ))}
          </ScrollView>
        </Entrance>
      ) : null}

      <Entrance index={5}>
        <SectionHeader
          eyebrow="Open plans"
          title="Near you this week"
          actionLabel="See all"
          onAction={() => openDiscover('activities')}
        />
      </Entrance>

      {feed.activitiesNearby.length === 0 ? (
        <StateView
          icon="event-available"
          title="Quiet around here"
          message="No open plans nearby yet. Be the first to post one."
          compact
        />
      ) : (
        <View style={styles.activityList}>
          {feed.activitiesNearby.slice(0, 4).map((activity, index) => (
            <View key={activity.id} style={index > 0 ? { marginTop: AppSpacing.md } : null}>
              <ActivityCard
                activity={activity}
                onPress={() => navigation.navigate('ActivityDetail', { activityId: activity.id })}
                onInvite={() => showInvite({ profile: activity.host, activity })}
              />
            </View>
          ))}
        </View>
      )}

      <View style={styles.promptWrap}>
        <CreatePlanPrompt onPress={() => navigation.navigate('CreateActivity')} />
      </View>
    </ScrollView>
  );
}

function Greeting({ feed }: { feed: HomeFeed }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const me = useCurrentUser();
  const unread = useUnreadNotifications();

  const name = me ? firstName(me) : 'there';
  const freeNow = feed.peopleNearby.filter(
    (profile) => profile.availability.includes('TONIGHT') || profile.isOnline,
  ).length;

  return (
    <View style={styles.greeting}>
      <View style={styles.greetingBody}>
        <Text style={[type.bodySmall, { color: colors.inkMuted }]}>
          {greetingLabel(feed.greeting)}
        </Text>
        <Text style={[type.display, { marginTop: AppSpacing.xs }]}>{name}</Text>

        <View style={[styles.placeRow, { marginTop: AppSpacing.md }]}>
          <MaterialIcons name="place" size={14} color={colors.inkFaint} />
          <Text
            style={[type.caption, { color: colors.inkMuted, marginLeft: AppSpacing.xs + 1 }]}
          >
            {feed.city.length === 0 ? 'Nearby' : feed.city}
          </Text>
          {freeNow > 0 ? (
            <>
              <Text style={[type.caption, { color: colors.inkFaint }]}>{'  ·  '}</Text>
              <View style={[styles.liveDot, { backgroundColor: colors.success }]} />
              <Text style={[type.caption, { color: colors.inkMuted }]}>
                {`${freeNow} free right now`}
              </Text>
            </>
          ) : null}
        </View>
      </View>

      <View style={styles.greetingActions}>
        <View>
          <AppIconButton
            icon="notifications-none"
            onPress={() => navigation.navigate('Notifications')}
            accessibilityLabel="Notifications"
          />
          {unread > 0 ? (
            <View
              style={[styles.unreadDot, { backgroundColor: colors.accent, borderColor: colors.surface }]}
            />
          ) : null}
        </View>

        <View style={{ width: AppSpacing.sm }} />
        <PressEffect
          onPress={() => navigation.navigate('Tabs', { screen: 'Me' })}
          scale={0.9}
          accessibilityLabel="Your profile"
        >
          <AppAvatar name={me?.displayName ?? 'You'} imageUrl={me?.avatarUrl} size={42} />
        </PressEffect>
      </View>
    </View>
  );
}

function CategoryTile({ count, onPress }: { count: CategoryCount; onPress: () => void }) {
  const { colors, type, isDark } = useTheme();
  const meta = categoryMeta(count.category);
  const total = count.openActivities;

  return (
    <PressEffect onPress={onPress} scale={0.95}>
      <View
        style={[styles.tile, { backgroundColor: colors.surface, borderColor: colors.border }]}
      >
        <View
          style={[styles.tileIcon, { backgroundColor: categoryTint(count.category, isDark) }]}
        >
          <MaterialIcons
            name={meta.icon}
            size={19}
            color={categoryForeground(count.category, isDark)}
          />
        </View>
        <Text
          numberOfLines={1}
          style={[type.label, styles.tileLabel, { fontSize: 12.5 }]}
        >
          {meta.label}
        </Text>
        <Text
          style={[
            type.caption,
            { color: total > 0 ? colors.inkMuted : colors.inkFaint, fontSize: 11, marginTop: 2 },
          ]}
        >
          {total > 0 ? `${total} open` : 'Be first'}
        </Text>
      </View>
    </PressEffect>
  );
}

function PendingInvitesBanner({ count, onPress }: { count: number; onPress: () => void }) {
  const { colors, type } = useTheme();

  return (
    <PressEffect onPress={onPress} scale={0.99}>
      <View
        style={[
          styles.banner,
          { backgroundColor: colors.accentSoft, borderColor: withAlpha(colors.accent, 0.22) },
        ]}
      >
        <View style={[styles.bannerMark, { backgroundColor: colors.accent }]}>
          <MaterialIcons name="mail" size={18} color="#FFFFFF" />
        </View>
        <View style={styles.bannerBody}>
          <Text style={type.bodyStrong}>
            {count === 1 ? 'Someone invited you' : `${count} people invited you`}
          </Text>
          <Text style={[type.caption, { color: colors.inkMuted, marginTop: 1 }]}>
            They are waiting on your answer.
          </Text>
        </View>
        <MaterialIcons name="chevron-right" size={24} color={colors.accent} />
      </View>
    </PressEffect>
  );
}

function CreatePlanPrompt({ onPress }: { onPress: () => void }) {
  const { colors, type } = useTheme();
  const showcase: ActivityCategory[] = ['MOVIE', 'DINNER', 'WALK'];

  return (
    <View style={[styles.prompt, { backgroundColor: colors.primary }]}>
      <View style={styles.promptIcons}>
        {showcase.map((category) => (
          <View
            key={category}
            style={[
              styles.promptIcon,
              { backgroundColor: withAlpha(colors.onPrimary, 0.12) },
            ]}
          >
            <MaterialIcons
              name={categoryMeta(category).icon}
              size={15}
              color={withAlpha(colors.onPrimary, 0.85)}
            />
          </View>
        ))}
      </View>

      <Text style={[type.serifTitle, { color: colors.onPrimary, marginTop: AppSpacing.xl }]}>
        Nothing on tonight?
      </Text>
      <Text
        style={[
          type.body,
          { color: withAlpha(colors.onPrimary, 0.76), lineHeight: 23, marginTop: AppSpacing.sm },
        ]}
      >
        Post what you want to do and let the right person come to you. It takes about thirty
        seconds.
      </Text>

      <View style={{ marginTop: AppSpacing.xxl }}>
        <AppButton label="Create a plan" variant="secondary" icon="add" onPress={onPress} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingBottom: AppSpacing.giant },
  errorBody: { flexGrow: 1, paddingTop: 120 },
  greeting: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
  },
  greetingBody: { flex: 1, marginRight: AppSpacing.md },
  greetingActions: { flexDirection: 'row', alignItems: 'center' },
  placeRow: { flexDirection: 'row', alignItems: 'center' },
  liveDot: { height: 6, width: 6, borderRadius: 3, marginRight: AppSpacing.sm },
  unreadDot: {
    position: 'absolute',
    top: 2,
    right: 2,
    height: 9,
    width: 9,
    borderRadius: 4.5,
    borderWidth: 1.5,
  },
  bannerWrap: { paddingHorizontal: AppSpacing.screenX, paddingTop: AppSpacing.xl },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  bannerMark: {
    height: 38,
    width: 38,
    borderRadius: AppRadii.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bannerBody: { flex: 1, marginHorizontal: AppSpacing.lg },
  categoryHeader: { paddingTop: AppSpacing.xxl },
  rail: { paddingHorizontal: AppSpacing.screenX },
  railItem: { marginRight: AppSpacing.md },
  tile: {
    width: 96,
    paddingVertical: AppSpacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  tileIcon: {
    height: 40,
    width: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileLabel: {
    textAlign: 'center',
    marginTop: AppSpacing.md,
    paddingHorizontal: AppSpacing.sm,
  },
  activityList: { paddingHorizontal: AppSpacing.screenX },
  promptWrap: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xxxl,
  },
  prompt: { padding: AppSpacing.xxl, borderRadius: AppRadii.xl },
  promptIcons: { flexDirection: 'row' },
  promptIcon: {
    height: 30,
    width: 30,
    borderRadius: AppRadii.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: AppSpacing.sm,
  },
});
