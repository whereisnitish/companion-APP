import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';

import { PersonCardSkeleton, Shimmer, SkeletonBox } from '../../components';
import { AppRadii, AppSpacing } from '../../theme';

/** The loading silhouette for Home — the same shape the real feed will take. */
export function HomeSkeleton() {
  return (
    <Shimmer>
      <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.headerBody}>
            <SkeletonBox width={90} height={12} />
            <View style={{ height: AppSpacing.md }} />
            <SkeletonBox width={160} height={30} />
            <View style={{ height: AppSpacing.md }} />
            <SkeletonBox width={130} height={12} />
          </View>
          <SkeletonBox circle size={42} />
        </View>

        <View style={{ height: AppSpacing.xxxl }} />
        <SkeletonBox width={180} height={20} />
        <View style={{ height: AppSpacing.lg }} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {[0, 1, 2, 3, 4].map((index) => (
            <View key={index} style={styles.railItem}>
              <SkeletonBox width={96} height={112} radius={AppRadii.lg} />
            </View>
          ))}
        </ScrollView>

        <View style={{ height: AppSpacing.xxxl }} />
        <SkeletonBox width={210} height={20} />
        <View style={{ height: AppSpacing.lg }} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {[0, 1, 2].map((index) => (
            <View key={index} style={[styles.railItem, { width: 232 }]}>
              <PersonCardSkeleton />
            </View>
          ))}
        </ScrollView>
      </ScrollView>
    </Shimmer>
  );
}

const styles = StyleSheet.create({
  body: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xl,
    paddingBottom: AppSpacing.giant,
  },
  header: { flexDirection: 'row', alignItems: 'flex-start' },
  headerBody: { flex: 1 },
  railItem: { marginRight: AppSpacing.md },
});
