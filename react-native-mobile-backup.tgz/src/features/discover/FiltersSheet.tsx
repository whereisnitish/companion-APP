import React, { useState, type ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import {
  AppButton,
  AppChip,
  AppRangeSlider,
  AppSheet,
  AppSlider,
  CategoryChip,
} from '../../components';
import {
  ACTIVITY_CATEGORIES,
  AVAILABILITY_SLOTS,
  availabilityLabel,
  genderLabel,
  type ActivityCategory,
  type AvailabilitySlot,
  type Gender,
} from '../../models/enums';
import { useInterestCatalog } from '../../queries';
import { isDefaultFilters, NO_FILTERS, type DiscoveryFilters } from '../../services/discoveryService';
import { useDiscoverStore } from '../../stores';
import { AppSpacing, useTheme } from '../../theme';

/** Toggles `item` in `list` without mutating it. */
function toggle<T>(list: T[], item: T): T[] {
  return list.includes(item) ? list.filter((entry) => entry !== item) : [...list, item];
}

/**
 * Filters as a single sheet with one "Reset".
 *
 * Nothing is applied until "Show results" — half-typed filters should never
 * make the list flicker underneath the sheet.
 */
export function FiltersSheet({ visible, onDismiss }: { visible: boolean; onDismiss: () => void }) {
  const { colors, type } = useTheme();
  const filters = useDiscoverStore((state) => state.filters);
  const setFilters = useDiscoverStore((state) => state.setFilters);

  const [draft, setDraft] = useState<DiscoveryFilters>(filters);
  const { data: interests } = useInterestCatalog();

  const apply = () => {
    setFilters(draft);
    onDismiss();
  };

  if (!visible) return null;

  return (
    <AppSheet
      visible={visible}
      onDismiss={onDismiss}
      title="Filters"
      subtitle="Narrow it down to the plans you would actually say yes to."
      trailing={
        isDefaultFilters(draft) ? null : (
          <AppButton
            label="Reset"
            variant="ghost"
            size="small"
            expand={false}
            onPress={() => setDraft(NO_FILTERS)}
          />
        )
      }
      footer={<AppButton label="Show results" onPress={apply} />}
    >
      <Group label="Activity">
        <View style={styles.wrap}>
          {ACTIVITY_CATEGORIES.map((category: ActivityCategory) => (
            <View key={category} style={styles.wrapItem}>
              <CategoryChip
                category={category}
                dense
                selected={draft.activities.includes(category)}
                onPress={() =>
                  setDraft({ ...draft, activities: toggle(draft.activities, category) })
                }
              />
            </View>
          ))}
        </View>
      </Group>

      <Group label="When they’re free">
        <View style={styles.wrap}>
          {AVAILABILITY_SLOTS.map((slot: AvailabilitySlot) => (
            <View key={slot} style={styles.wrapItem}>
              <AppChip
                label={availabilityLabel(slot)}
                dense
                selected={draft.availability.includes(slot)}
                onPress={() =>
                  setDraft({ ...draft, availability: toggle(draft.availability, slot) })
                }
              />
            </View>
          ))}
        </View>
      </Group>

      <Group label="Show me">
        <View style={styles.wrap}>
          {(['FEMALE', 'MALE', 'NON_BINARY'] as Gender[]).map((gender) => (
            <View key={gender} style={styles.wrapItem}>
              <AppChip
                label={genderLabel(gender)}
                dense
                selected={draft.genders.includes(gender)}
                onPress={() => setDraft({ ...draft, genders: toggle(draft.genders, gender) })}
              />
            </View>
          ))}
        </View>
      </Group>

      <Group label="Age" trailing={`${draft.minAge} – ${draft.maxAge}`}>
        <AppRangeSlider
          low={draft.minAge}
          high={draft.maxAge}
          min={18}
          max={99}
          onChange={(low, high) => setDraft({ ...draft, minAge: low, maxAge: high })}
        />
      </Group>

      <Group label="Distance" trailing={`${Math.round(draft.radiusKm)} km`}>
        <AppSlider
          value={draft.radiusKm}
          min={1}
          max={100}
          onChange={(value) => setDraft({ ...draft, radiusKm: value })}
        />
      </Group>

      {interests && interests.length > 0 ? (
        <Group label="Interests">
          <View style={styles.wrap}>
            {interests.slice(0, 24).map((interest) => (
              <View key={interest.slug} style={styles.wrapItem}>
                <AppChip
                  label={interest.label}
                  dense
                  leading={
                    interest.emoji.length > 0 ? (
                      <Text style={{ fontSize: 12 }}>{interest.emoji}</Text>
                    ) : undefined
                  }
                  selected={draft.interests.includes(interest.slug)}
                  onPress={() =>
                    setDraft({ ...draft, interests: toggle(draft.interests, interest.slug) })
                  }
                />
              </View>
            ))}
          </View>
        </Group>
      ) : null}

      <Text style={[type.caption, { color: colors.inkFaint, lineHeight: 18 }]}>
        Filters only affect who you see. They never tell the other person anything about you.
      </Text>
    </AppSheet>
  );
}

function Group({
  label,
  trailing,
  children,
}: {
  label: string;
  trailing?: string;
  children: ReactNode;
}) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.group}>
      <View style={styles.groupHead}>
        <Text style={[type.overline, { color: colors.inkFaint }]}>{label.toUpperCase()}</Text>
        <View style={styles.spacer} />
        {trailing ? <Text style={[type.numeric, { color: colors.ink }]}>{trailing}</Text> : null}
      </View>
      <View style={{ marginTop: AppSpacing.md }}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  group: { marginBottom: AppSpacing.xxl },
  groupHead: { flexDirection: 'row', alignItems: 'center' },
  spacer: { flex: 1 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
});
