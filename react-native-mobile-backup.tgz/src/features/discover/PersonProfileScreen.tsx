import React, { useState, type ReactNode } from 'react';
import {
  Dimensions,
  FlatList,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  AppAvatar,
  AppButton,
  AppChip,
  AppIconButton,
  CategoryChip,
  Entrance,
  ErrorStateView,
  Shimmer,
  SkeletonBox,
  VerifiedBadge,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import { availabilityLabel, isVerified, type MaterialIconName } from '../../models/enums';
import { firstName, gallery, type Profile } from '../../models/profile';
import type { RootStackParamList } from '../../navigation/types';
import { useProfileById } from '../../queries';
import { AppMotion, AppRadii, AppSpacing, useTheme } from '../../theme';
import { useInviteSheet } from '../invitations/InviteSheet';
import { useSafetyActions } from '../settings/SafetyActionsSheet';

type Navigation = NativeStackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'PersonProfile'>;

/**
 * A person, at full size.
 *
 * The photo gets real estate because it is what people look at first, but the
 * screen is organised around the question that matters here: *would I spend an
 * evening with them, doing what?* So "Up for" and "Free" sit above the bio.
 */
export function PersonProfileScreen({ route }: { route: Route }) {
  const { colors } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const { userId } = route.params;

  const { data: person, isPending, error, refetch } = useProfileById(userId);

  if (isPending) return <ProfileSkeleton />;

  if (error || !person) {
    return (
      <View style={[styles.container, { backgroundColor: colors.canvas, paddingTop: insets.top }]}>
        <View style={styles.errorHeader}>
          <AppIconButton
            icon="arrow-back"
            onPress={() => navigation.goBack()}
            accessibilityLabel="Go back"
          />
        </View>
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      </View>
    );
  }

  return <ProfileBody person={person} />;
}

function ProfileBody({ person }: { person: Profile }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const { showInvite } = useInviteSheet();
  const { showSafetyActions } = useSafetyActions();

  const [photoIndex, setPhotoIndex] = useState(0);
  const [width, setWidth] = useState(Dimensions.get('window').width);

  const photos = gallery(person);
  const photoHeight = Dimensions.get('window').height * 0.52;

  const openSafety = () =>
    showSafetyActions({
      userId: person.id,
      displayName: person.displayName,
      onBlocked: () => navigation.goBack(),
    });

  const onPhotoScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (width <= 0) return;
    setPhotoIndex(Math.round(event.nativeEvent.contentOffset.x / width));
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View
          style={{ height: photoHeight }}
          onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
        >
          {photos.length === 0 ? (
            <View
              style={[styles.fill, styles.center, { backgroundColor: colors.surfaceSunken }]}
            >
              <AppAvatar name={person.displayName} size={128} />
            </View>
          ) : (
            <FlatList
              data={photos}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onScroll={onPhotoScroll}
              scrollEventThrottle={16}
              keyExtractor={(uri, index) => `${uri}-${index}`}
              renderItem={({ item }) => (
                <Image
                  source={{ uri: item }}
                  style={{ width, height: photoHeight }}
                  contentFit="cover"
                  transition={AppMotion.base}
                />
              )}
            />
          )}

          <LinearGradient
            pointerEvents="none"
            colors={[
              'rgba(0, 0, 0, 0.4)',
              'transparent',
              'transparent',
              'rgba(0, 0, 0, 0.25)',
            ]}
            locations={[0, 0.28, 0.72, 1]}
            style={styles.fillAbsolute}
          />

          {photos.length > 1 ? (
            <View style={styles.dots}>
              {photos.map((uri, index) => (
                <View
                  key={`${uri}-${index}`}
                  style={[
                    styles.dot,
                    {
                      width: index === photoIndex ? 20 : 8,
                      backgroundColor:
                        index === photoIndex ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.45)',
                    },
                  ]}
                />
              ))}
            </View>
          ) : null}
        </View>

        <View style={[styles.sheet, { backgroundColor: colors.canvas }]}>
          <Entrance>
            <Identity person={person} />
          </Entrance>

          <Entrance index={1} style={{ marginTop: AppSpacing.xl }}>
            <MetaRow person={person} />
          </Entrance>

          {person.preferredActivities.length > 0 ? (
            <Entrance index={2} style={{ marginTop: AppSpacing.xxxl }}>
              <Block label="Up for">
                <View style={styles.wrap}>
                  {person.preferredActivities.map((category) => (
                    <View key={category} style={styles.wrapItem}>
                      <CategoryChip category={category} selected />
                    </View>
                  ))}
                </View>
              </Block>
            </Entrance>
          ) : null}

          {person.availability.length > 0 ? (
            <Entrance index={3} style={{ marginTop: AppSpacing.xxl }}>
              <Block label="Usually free">
                <View style={styles.wrap}>
                  {person.availability.map((slot) => (
                    <View key={slot} style={styles.wrapItem}>
                      <AppChip
                        label={availabilityLabel(slot)}
                        icon="schedule"
                        tint={colors.primarySoft}
                        foreground={colors.primary}
                        selected
                      />
                    </View>
                  ))}
                </View>
              </Block>
            </Entrance>
          ) : null}

          {person.bio.length > 0 ? (
            <Entrance index={4} style={{ marginTop: AppSpacing.xxl }}>
              <Block label="About">
                <Text style={[type.body, { lineHeight: 25, color: colors.ink }]}>{person.bio}</Text>
              </Block>
            </Entrance>
          ) : null}

          {person.interests.length > 0 ? (
            <Entrance index={5} style={{ marginTop: AppSpacing.xxl }}>
              <Block label="Into">
                <View style={styles.wrap}>
                  {person.interests.map((interest) => (
                    <View key={interest.slug} style={styles.wrapItem}>
                      <AppChip
                        label={interest.label}
                        dense
                        leading={
                          interest.emoji.length > 0 ? (
                            <Text style={{ fontSize: 12 }}>{interest.emoji}</Text>
                          ) : undefined
                        }
                      />
                    </View>
                  ))}
                </View>
              </Block>
            </Entrance>
          ) : null}

          <Entrance index={6} style={{ marginTop: AppSpacing.xxxl }}>
            <TrustPanel person={person} />
          </Entrance>

          <Entrance index={7} style={{ marginTop: AppSpacing.xxl, alignItems: 'center' }}>
            <AppButton
              label={`Report or block ${firstName(person)}`}
              variant="ghost"
              icon="shield"
              size="small"
              expand={false}
              onPress={openSafety}
            />
          </Entrance>
        </View>
      </ScrollView>

      {/* Floating chrome, so the photo is never covered by a solid bar. */}
      <View style={[styles.chrome, { top: insets.top + AppSpacing.sm }]}>
        <AppIconButton
          icon="arrow-back"
          background="rgba(0, 0, 0, 0.36)"
          foreground="#FFFFFF"
          bordered={false}
          onPress={() => navigation.goBack()}
          accessibilityLabel="Go back"
        />
        <View style={styles.spacer} />
        <AppIconButton
          icon="more-horiz"
          background="rgba(0, 0, 0, 0.36)"
          foreground="#FFFFFF"
          bordered={false}
          onPress={openSafety}
          accessibilityLabel="More options"
        />
      </View>

      <View
        style={[
          styles.inviteBar,
          {
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            paddingBottom: insets.bottom + AppSpacing.lg,
          },
        ]}
      >
        <AppButton
          label={`Invite ${firstName(person)}`}
          icon="send"
          onPress={() => showInvite({ profile: person })}
        />
      </View>
    </View>
  );
}

function Identity({ person }: { person: Profile }) {
  const { colors, type } = useTheme();

  return (
    <View>
      <View style={styles.identityRow}>
        <Text style={[type.headline, styles.identityName]}>
          {person.age === null ? person.displayName : `${person.displayName}, ${person.age}`}
        </Text>
        {isVerified(person.verification) ? (
          <View style={{ marginLeft: AppSpacing.md, marginTop: 4 }}>
            <VerifiedBadge size={20} status={person.verification} />
          </View>
        ) : null}
      </View>
      {person.occupation && person.occupation.length > 0 ? (
        <Text style={[type.body, { color: colors.inkMuted, marginTop: AppSpacing.xs }]}>
          {person.occupation}
        </Text>
      ) : null}
    </View>
  );
}

function MetaRow({ person }: { person: Profile }) {
  const { colors, type } = useTheme();

  const item = (icon: MaterialIconName, label: string, tint?: string) => (
    <View key={label} style={styles.metaItem}>
      <MaterialIcons name={icon} size={14} color={tint ?? colors.inkFaint} />
      <Text
        style={[type.caption, { color: tint ?? colors.inkMuted, marginLeft: AppSpacing.xs + 2 }]}
      >
        {label}
      </Text>
    </View>
  );

  return (
    <View style={styles.metaWrap}>
      {person.area && person.area.length > 0 ? item('place', person.area) : null}
      {person.distanceKm !== null ? item('near-me', Format.distance(person.distanceKm)) : null}
      {item(
        person.isOnline ? 'circle' : 'schedule',
        Format.lastSeen(person.lastActiveAt, person.isOnline),
        person.isOnline ? colors.success : undefined,
      )}
    </View>
  );
}

function Block({ label, children }: { label: string; children: ReactNode }) {
  const { colors, type } = useTheme();

  return (
    <View>
      <Text style={[type.overline, { color: colors.inkFaint }]}>{label.toUpperCase()}</Text>
      <View style={{ marginTop: AppSpacing.md }}>{children}</View>
    </View>
  );
}

/**
 * Reputation and verification, shown together because that is how someone
 * actually decides whether to meet a stranger. Both are read-only placeholders
 * in the MVP; the shape is what a real trust system would fill in.
 */
function TrustPanel({ person }: { person: Profile }) {
  const { colors, type } = useTheme();
  const verified = isVerified(person.verification);

  return (
    <View
      style={[styles.trust, { backgroundColor: colors.surface, borderColor: colors.border }]}
    >
      <View style={styles.trustHalf}>
        <View style={styles.trustHead}>
          <MaterialIcons name="star" size={17} color={colors.warning} />
          <Text style={[type.bodyStrong, { marginLeft: AppSpacing.xs + 2 }]}>
            {person.ratingCount === 0 ? 'New here' : person.ratingAverage.toFixed(1)}
          </Text>
        </View>
        <Text style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>
          {person.ratingCount === 0 ? 'No meet-ups yet' : `from ${person.ratingCount} meet-ups`}
        </Text>
      </View>

      <View style={[styles.trustDivider, { backgroundColor: colors.border }]} />

      <View style={styles.trustHalf}>
        <View style={styles.trustHead}>
          <MaterialIcons
            name={verified ? 'verified' : 'shield'}
            size={17}
            color={verified ? colors.primary : colors.inkFaint}
          />
          <Text style={[type.bodyStrong, { marginLeft: AppSpacing.xs + 2 }]}>
            {verified ? 'Verified' : 'Unverified'}
          </Text>
        </View>
        <Text style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>
          {verified ? 'Photo and ID checked' : 'Meet somewhere public'}
        </Text>
      </View>
    </View>
  );
}

function ProfileSkeleton() {
  const { colors } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: colors.canvas }]}>
      <Shimmer>
        <SkeletonBox height={Dimensions.get('window').height * 0.5} radius={0} width="100%" />
        <View style={{ padding: AppSpacing.screenX }}>
          <SkeletonBox width={200} height={28} />
          <View style={{ height: AppSpacing.md }} />
          <SkeletonBox width={130} height={14} />
          <View style={{ height: AppSpacing.xxl }} />
          <SkeletonBox height={14} width="100%" />
          <View style={{ height: AppSpacing.sm }} />
          <SkeletonBox width={240} height={14} />
        </View>
      </Shimmer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  fill: { width: '100%', height: '100%' },
  fillAbsolute: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 },
  center: { alignItems: 'center', justifyContent: 'center' },
  errorHeader: { padding: AppSpacing.md, alignItems: 'flex-start' },
  dots: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: AppSpacing.xxxl,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  dot: { height: 3, borderRadius: AppRadii.pill, marginHorizontal: 3 },
  sheet: {
    marginTop: -AppSpacing.xxl,
    borderTopLeftRadius: AppRadii.xl,
    borderTopRightRadius: AppRadii.xl,
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.xxl,
    paddingBottom: 140,
  },
  identityRow: { flexDirection: 'row', alignItems: 'center' },
  identityName: { flexShrink: 1 },
  metaWrap: { flexDirection: 'row', flexWrap: 'wrap' },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: AppSpacing.lg,
    marginBottom: AppSpacing.sm,
  },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  trust: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  trustHalf: { flex: 1 },
  trustHead: { flexDirection: 'row', alignItems: 'center' },
  trustDivider: { width: 1, height: 34, marginRight: AppSpacing.lg },
  chrome: {
    position: 'absolute',
    left: AppSpacing.lg,
    right: AppSpacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
  },
  spacer: { flex: 1 },
  inviteBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    borderTopWidth: 1,
  },
});
