import React, { useEffect, useRef, useState } from 'react';
import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  ActivityCard,
  AppChip,
  AppTextField,
  CategoryChip,
  Entrance,
  ErrorStateView,
  PersonCard,
  PersonCardSkeleton,
  PressEffect,
  Shimmer,
  SkeletonBox,
  StateView,
} from '../../components';
import {
  availabilityLabel,
  genderLabel,
  type ActivityCategory,
  type AvailabilitySlot,
  type Gender,
} from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { useDiscoverActivities, useDiscoverPeople } from '../../queries';
import {
  activeFilterCount,
  NO_FILTERS,
  type DiscoveryFilters,
} from '../../services/discoveryService';
import { useDiscoverStore, type DiscoverMode } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { useInviteSheet } from '../invitations/InviteSheet';
import { FiltersSheet } from './FiltersSheet';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Discover is a browse surface, not a game.
 *
 * No swiping, no scarcity, no artificial "you have 3 left". A search field, a
 * segmented switch between people and plans, a filter sheet, and a list you
 * can scroll back up in.
 */
export function DiscoverScreen() {
  const { colors, type } = useTheme();
  const mode = useDiscoverStore((state) => state.mode);
  const setMode = useDiscoverStore((state) => state.setMode);
  const filters = useDiscoverStore((state) => state.filters);
  const setFilters = useDiscoverStore((state) => state.setFilters);

  const [search, setSearch] = useState(filters.query);
  const [filtersVisible, setFiltersVisible] = useState(false);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Typing should not fire a request per keystroke.
  const onSearchChanged = (value: string) => {
    setSearch(value);
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = setTimeout(() => {
      const trimmed = value.trim();
      if (useDiscoverStore.getState().filters.query === trimmed) return;
      setFilters({ ...useDiscoverStore.getState().filters, query: trimmed });
    }, 350);
  };

  useEffect(
    () => () => {
      if (debounce.current) clearTimeout(debounce.current);
    },
    [],
  );

  // The home screen can set filters before navigating here.
  useEffect(() => setSearch(filters.query), [filters.query]);

  const activeCount = activeFilterCount(filters);

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <Text style={[type.headline, styles.title]}>Discover</Text>
          <FilterButton count={activeCount} onPress={() => setFiltersVisible(true)} />
        </View>

        <View style={{ height: AppSpacing.lg }} />
        <AppTextField
          value={search}
          onChangeText={onSearchChanged}
          hint={mode === 'people' ? 'Search names, bios, areas' : 'Search plans and places'}
          prefixIcon="search"
          returnKeyType="search"
          suffix={
            search.length === 0 ? undefined : (
              <PressEffect onPress={() => onSearchChanged('')} hitSlop={8}>
                <MaterialIcons name="close" size={18} color={colors.inkFaint} />
              </PressEffect>
            )
          }
        />

        <View style={{ height: AppSpacing.lg }} />
        <ModeSwitch mode={mode} onChange={setMode} />

        {activeCount > 0 ? (
          <View style={{ marginTop: AppSpacing.md }}>
            <ActiveFilterSummary filters={filters} onChange={setFilters} />
          </View>
        ) : null}
      </View>

      <View style={styles.body}>
        {mode === 'people' ? <PeopleList /> : <ActivitiesList />}
      </View>

      <FiltersSheet visible={filtersVisible} onDismiss={() => setFiltersVisible(false)} />
    </SafeAreaView>
  );
}

function ModeSwitch({
  mode,
  onChange,
}: {
  mode: DiscoverMode;
  onChange: (mode: DiscoverMode) => void;
}) {
  const { colors, type } = useTheme();

  const segment = (value: DiscoverMode, label: string, icon: 'people' | 'event') => {
    const isSelected = mode === value;
    return (
      <View style={styles.segment}>
        <PressEffect onPress={() => onChange(value)} scale={0.97}>
          <View
            style={[
              styles.segmentBody,
              {
                backgroundColor: isSelected ? colors.surface : 'transparent',
                borderColor: isSelected ? colors.border : 'transparent',
              },
            ]}
          >
            <MaterialIcons
              name={icon}
              size={15}
              color={isSelected ? colors.ink : colors.inkFaint}
            />
            <Text
              style={[
                type.label,
                { color: isSelected ? colors.ink : colors.inkFaint, marginLeft: AppSpacing.sm },
              ]}
            >
              {label}
            </Text>
          </View>
        </PressEffect>
      </View>
    );
  };

  return (
    <View style={[styles.switch, { backgroundColor: colors.surfaceSunken }]}>
      {segment('people', 'People', 'people')}
      {segment('activities', 'Plans', 'event')}
    </View>
  );
}

function FilterButton({ count, onPress }: { count: number; onPress: () => void }) {
  const { colors, type } = useTheme();
  const isActive = count > 0;

  return (
    <PressEffect onPress={onPress} scale={0.93} accessibilityLabel="Filters">
      <View
        style={[
          styles.filterButton,
          {
            backgroundColor: isActive ? colors.ink : colors.surface,
            borderColor: isActive ? colors.ink : colors.border,
          },
        ]}
      >
        <MaterialIcons name="tune" size={17} color={isActive ? colors.inkInverse : colors.ink} />
        {isActive ? (
          <Text style={[type.numeric, { color: colors.inkInverse, marginLeft: AppSpacing.sm }]}>
            {count}
          </Text>
        ) : null}
      </View>
    </PressEffect>
  );
}

function ActiveFilterSummary({
  filters,
  onChange,
}: {
  filters: DiscoveryFilters;
  onChange: (filters: DiscoveryFilters) => void;
}) {
  const chips: React.ReactNode[] = [];

  filters.activities.forEach((category: ActivityCategory) =>
    chips.push(
      <CategoryChip
        key={`c-${category}`}
        category={category}
        dense
        selected
        onPress={() =>
          onChange({
            ...filters,
            activities: filters.activities.filter((entry) => entry !== category),
          })
        }
      />,
    ),
  );

  filters.availability.forEach((slot: AvailabilitySlot) =>
    chips.push(
      <AppChip
        key={`a-${slot}`}
        label={availabilityLabel(slot)}
        dense
        selected
        onPress={() =>
          onChange({
            ...filters,
            availability: filters.availability.filter((entry) => entry !== slot),
          })
        }
      />,
    ),
  );

  filters.genders.forEach((gender: Gender) =>
    chips.push(
      <AppChip
        key={`g-${gender}`}
        label={genderLabel(gender)}
        dense
        selected
        onPress={() =>
          onChange({ ...filters, genders: filters.genders.filter((entry) => entry !== gender) })
        }
      />,
    ),
  );

  if (filters.minAge !== 18 || filters.maxAge !== 99) {
    chips.push(
      <AppChip
        key="age"
        label={`${filters.minAge}–${filters.maxAge}`}
        dense
        selected
        onPress={() => onChange({ ...filters, minAge: 18, maxAge: 99 })}
      />,
    );
  }

  if (filters.radiusKm !== 25) {
    chips.push(
      <AppChip
        key="radius"
        label={`Within ${Math.round(filters.radiusKm)} km`}
        dense
        selected
        onPress={() => onChange({ ...filters, radiusKm: 25 })}
      />,
    );
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      {chips.map((chip, index) => (
        <View key={index} style={{ marginRight: AppSpacing.sm }}>
          {chip}
        </View>
      ))}
    </ScrollView>
  );
}

function PeopleList() {
  const { colors } = useTheme();
  const navigation = useNavigation<Navigation>();
  const { showInvite } = useInviteSheet();
  const filters = useDiscoverStore((state) => state.filters);
  const setFilters = useDiscoverStore((state) => state.setFilters);

  const { data, isPending, error, refetch, isRefetching } = useDiscoverPeople(filters);

  if (isPending) {
    return (
      <Shimmer>
        <ScrollView contentContainerStyle={styles.listContent}>
          {[0, 1, 2].map((index) => (
            <View key={index} style={index > 0 ? { marginTop: AppSpacing.xl } : null}>
              <PersonCardSkeleton />
            </View>
          ))}
        </ScrollView>
      </Shimmer>
    );
  }

  if (error) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      </ScrollView>
    );
  }

  const items = data ?? [];

  if (items.length === 0) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <StateView
          icon="person-search"
          title="Nobody matches that yet"
          message="Try widening the distance or clearing a filter. New people join every day."
          actionLabel="Clear filters"
          onAction={() => setFilters(NO_FILTERS)}
        />
      </ScrollView>
    );
  }

  return (
    <FlatList
      data={items}
      keyExtractor={(profile) => profile.id}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={isRefetching}
          onRefresh={() => void refetch()}
          tintColor={colors.primary}
        />
      }
      ItemSeparatorComponent={() => <View style={{ height: AppSpacing.xl }} />}
      renderItem={({ item, index }) => (
        <Entrance index={index}>
          <PersonCard
            profile={item}
            onPress={() => navigation.navigate('PersonProfile', { userId: item.id })}
            onInvite={() => showInvite({ profile: item })}
          />
        </Entrance>
      )}
    />
  );
}

function ActivitiesList() {
  const { colors } = useTheme();
  const navigation = useNavigation<Navigation>();
  const { showInvite } = useInviteSheet();
  const filters = useDiscoverStore((state) => state.filters);

  const { data, isPending, error, refetch, isRefetching } = useDiscoverActivities(filters);

  if (isPending) {
    return (
      <Shimmer>
        <ScrollView contentContainerStyle={styles.listContent}>
          {[0, 1, 2, 3, 4].map((index) => (
            <View key={index} style={index > 0 ? { marginTop: AppSpacing.md } : null}>
              <SkeletonBox height={132} radius={AppRadii.lg} width="100%" />
            </View>
          ))}
        </ScrollView>
      </Shimmer>
    );
  }

  if (error) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      </ScrollView>
    );
  }

  const items = data ?? [];

  if (items.length === 0) {
    return (
      <ScrollView contentContainerStyle={styles.stateBody}>
        <StateView
          icon="event-busy"
          title="No open plans right now"
          message="Nothing matches these filters. Post your own and see who joins."
          actionLabel="Create a plan"
          onAction={() => navigation.navigate('CreateActivity')}
        />
      </ScrollView>
    );
  }

  return (
    <FlatList
      data={items}
      keyExtractor={(activity) => activity.id}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={isRefetching}
          onRefresh={() => void refetch()}
          tintColor={colors.primary}
        />
      }
      ItemSeparatorComponent={() => <View style={{ height: AppSpacing.md }} />}
      renderItem={({ item, index }) => (
        <Entrance index={index}>
          <ActivityCard
            activity={item}
            onPress={() => navigation.navigate('ActivityDetail', { activityId: item.id })}
            onInvite={() => showInvite({ profile: item.host, activity: item })}
          />
        </Entrance>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.lg,
  },
  titleRow: { flexDirection: 'row', alignItems: 'flex-end' },
  title: { flex: 1 },
  body: { flex: 1 },
  listContent: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.sm,
    paddingBottom: AppSpacing.giant,
  },
  stateBody: { flexGrow: 1, paddingTop: 40 },
  switch: { flexDirection: 'row', padding: 3, borderRadius: AppRadii.pill },
  segment: { flex: 1 },
  segmentBody: {
    height: 38,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
    borderWidth: 1,
  },
  filterButton: {
    height: 42,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    borderRadius: AppRadii.pill,
    borderWidth: 1,
  },
});
