import React, { type ReactNode } from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  AppAvatar,
  AppButton,
  AppChip,
  AppIconButton,
  CategoryBadge,
  CategoryChip,
  Entrance,
  PressEffect,
  Shimmer,
  SkeletonBox,
  VerifiedBadge,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import type { Activity } from '../../models/activity';
import { availabilityLabel, isVerified } from '../../models/enums';
import type { CurrentUser } from '../../models/profile';
import type { RootStackParamList } from '../../navigation/types';
import { useInvitationCounts, useMyActivities } from '../../queries';
import { useAuthStore, useCurrentUser } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Your own profile, plus your plans and the way out to settings.
 *
 * Deliberately less photographic than someone else's profile — this is a
 * control surface, not a pitch. The one thing it borrows is the same "up for"
 * and "free" language, so what you edit is visibly what others read.
 */
export function MyProfileScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const me = useCurrentUser();
  const refreshUser = useAuthStore((state) => state.refreshUser);
  const { refetch: refetchPlans, isRefetching } = useMyActivities();

  if (!me) {
    return (
      <View style={[styles.container, styles.center, { backgroundColor: colors.canvas }]}>
        <ActivityIndicator size="small" />
      </View>
    );
  }

  const editProfile = () => navigation.navigate('EditProfile');

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={() => {
              void refreshUser();
              void refetchPlans();
            }}
            tintColor={colors.primary}
          />
        }
      >
        <View style={styles.appBar}>
          <Text style={[type.headline, styles.flex]}>You</Text>
          <AppIconButton
            icon="settings"
            onPress={() => navigation.navigate('Settings')}
            accessibilityLabel="Settings"
          />
        </View>

        <Entrance style={{ marginTop: AppSpacing.xl }}>
          <ProfileHeader me={me} />
        </Entrance>

        <Entrance index={1} style={{ marginTop: AppSpacing.xxl }}>
          <StatsRow me={me} />
        </Entrance>

        <Entrance index={2} style={{ marginTop: AppSpacing.xxxl }}>
          <MyPlansSection />
        </Entrance>

        {me.preferredActivities.length > 0 ? (
          <Entrance index={3} style={{ marginTop: AppSpacing.xxxl }}>
            <Section label="Up for" onEdit={editProfile}>
              <View style={styles.wrap}>
                {me.preferredActivities.map((category) => (
                  <View key={category} style={styles.wrapItem}>
                    <CategoryChip category={category} selected />
                  </View>
                ))}
              </View>
            </Section>
          </Entrance>
        ) : null}

        {me.availability.length > 0 ? (
          <Entrance index={4} style={{ marginTop: AppSpacing.xxl }}>
            <Section label="Usually free" onEdit={editProfile}>
              <View style={styles.wrap}>
                {me.availability.map((slot) => (
                  <View key={slot} style={styles.wrapItem}>
                    <AppChip
                      label={availabilityLabel(slot)}
                      icon="schedule"
                      selected
                      tint={colors.primarySoft}
                      foreground={colors.primary}
                    />
                  </View>
                ))}
              </View>
            </Section>
          </Entrance>
        ) : null}

        {me.bio.length > 0 ? (
          <Entrance index={5} style={{ marginTop: AppSpacing.xxl }}>
            <Section label="About" onEdit={editProfile}>
              <Text style={[type.body, { lineHeight: 25 }]}>{me.bio}</Text>
            </Section>
          </Entrance>
        ) : null}

        {me.interests.length > 0 ? (
          <Entrance index={6} style={{ marginTop: AppSpacing.xxl }}>
            <Section label="Into" onEdit={editProfile}>
              <View style={styles.wrap}>
                {me.interests.map((interest) => (
                  <View key={interest.slug} style={styles.wrapItem}>
                    <AppChip
                      label={interest.label}
                      dense
                      leading={
                        interest.emoji.length > 0 ? (
                          <Text style={{ fontSize: 12 }}>{interest.emoji}</Text>
                        ) : undefined
                      }
                    />
                  </View>
                ))}
              </View>
            </Section>
          </Entrance>
        ) : null}

        <Entrance index={7} style={styles.editRow}>
          <AppButton
            label="Edit profile"
            variant="secondary"
            icon="edit"
            onPress={editProfile}
          />
        </Entrance>
      </ScrollView>
    </SafeAreaView>
  );
}

function ProfileHeader({ me }: { me: CurrentUser }) {
  const { colors, type } = useTheme();

  const place = [me.area && me.area.length > 0 ? me.area : null, me.city]
    .filter((part): part is string => !!part && part.length > 0)
    .join(', ');

  return (
    <View style={styles.screenPadding}>
      <View style={styles.headerRow}>
        <AppAvatar name={me.displayName} imageUrl={me.avatarUrl} size={84} ring={colors.primary} />

        <View style={styles.headerBody}>
          <View style={styles.nameRow}>
            <Text numberOfLines={1} style={[type.serifTitle, styles.flexShrink]}>
              {me.age === null ? me.displayName : `${me.displayName}, ${me.age}`}
            </Text>
            {isVerified(me.verification) ? (
              <View style={{ marginLeft: AppSpacing.sm }}>
                <VerifiedBadge size={17} status={me.verification} />
              </View>
            ) : null}
          </View>

          {me.occupation && me.occupation.length > 0 ? (
            <Text
              numberOfLines={1}
              style={[type.bodySmall, { color: colors.inkMuted, marginTop: 2 }]}
            >
              {me.occupation}
            </Text>
          ) : null}

          <View style={[styles.placeRow, { marginTop: AppSpacing.sm }]}>
            <MaterialIcons name="place" size={13} color={colors.inkFaint} />
            <Text
              numberOfLines={1}
              style={[type.caption, { color: colors.inkMuted, marginLeft: 3, flex: 1 }]}
            >
              {place}
            </Text>
          </View>

          {!me.isDiscoverable ? (
            <View style={{ marginTop: AppSpacing.sm }}>
              <AppChip
                label="Hidden from discovery"
                icon="visibility-off"
                dense
                tint={colors.accentSoft}
                foreground={colors.accent}
                selected
              />
            </View>
          ) : null}
        </View>
      </View>
    </View>
  );
}

function StatsRow({ me }: { me: CurrentUser }) {
  const { colors, type } = useTheme();
  const { data: counts } = useInvitationCounts();
  const accepted = counts?.accepted ?? 0;

  const stat = (value: string, label: string) => (
    <View style={styles.flex}>
      <Text style={[type.title, styles.centered]}>{value}</Text>
      <Text style={[type.caption, styles.centered, { color: colors.inkMuted, marginTop: 2 }]}>
        {label}
      </Text>
    </View>
  );

  return (
    <View style={styles.screenPadding}>
      <View
        style={[styles.stats, { backgroundColor: colors.surface, borderColor: colors.border }]}
      >
        {stat(me.ratingCount === 0 ? '—' : me.ratingAverage.toFixed(1), 'Rating')}
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        {stat(`${accepted}`, 'Connections')}
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        {stat(me.createdAt === null ? '—' : Format.relative(me.createdAt), 'Member for')}
      </View>
    </View>
  );
}

function MyPlansSection() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const { data, isPending, error } = useMyActivities();

  const upcoming = (data ?? []).filter((activity) => activity.status !== 'CANCELLED');

  return (
    <View>
      <View style={[styles.screenPadding, styles.sectionHead]}>
        <Text style={[type.overline, { color: colors.inkFaint, flex: 1 }]}>YOUR PLANS</Text>
        <AppButton
          label="New plan"
          variant="ghost"
          icon="add"
          size="small"
          expand={false}
          onPress={() => navigation.navigate('CreateActivity')}
        />
      </View>

      <View style={{ height: AppSpacing.md }} />

      {isPending ? (
        <View style={styles.screenPadding}>
          <Shimmer>
            <SkeletonBox height={76} radius={AppRadii.lg} width="100%" />
          </Shimmer>
        </View>
      ) : error ? (
        <View style={styles.screenPadding}>
          <Text style={[type.bodySmall, { color: colors.inkMuted }]}>
            We could not load your plans.
          </Text>
        </View>
      ) : upcoming.length === 0 ? (
        <View style={styles.screenPadding}>
          <View style={[styles.emptyPlans, { backgroundColor: colors.surfaceSunken }]}>
            <MaterialIcons name="event" size={20} color={colors.inkMuted} />
            <Text
              style={[
                type.bodySmall,
                { color: colors.inkMuted, lineHeight: 19, marginLeft: AppSpacing.md, flex: 1 },
              ]}
            >
              Nothing posted yet. A plan takes thirty seconds and does the finding for you.
            </Text>
          </View>
        </View>
      ) : (
        upcoming.slice(0, 4).map((activity) => (
          <View key={activity.id} style={[styles.screenPadding, { marginBottom: AppSpacing.sm }]}>
            <PlanRow activity={activity} />
          </View>
        ))
      )}
    </View>
  );
}

function PlanRow({ activity }: { activity: Activity }) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();

  return (
    <PressEffect
      onPress={() => navigation.navigate('ActivityDetail', { activityId: activity.id })}
      scale={0.99}
    >
      <View
        style={[styles.planRow, { backgroundColor: colors.surface, borderColor: colors.border }]}
      >
        <CategoryBadge category={activity.category} size={38} radius={12} />
        <View style={styles.planBody}>
          <Text numberOfLines={1} style={type.label}>
            {activity.title}
          </Text>
          <Text style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>
            {Format.whenShort(activity.startsAt)}
          </Text>
        </View>
        <MaterialIcons name="chevron-right" size={20} color={colors.inkFaint} />
      </View>
    </PressEffect>
  );
}

function Section({
  label,
  children,
  onEdit,
}: {
  label: string;
  children: ReactNode;
  onEdit?: () => void;
}) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.screenPadding}>
      <View style={styles.sectionHead}>
        <Text style={[type.overline, { color: colors.inkFaint, flex: 1 }]}>
          {label.toUpperCase()}
        </Text>
        {onEdit ? (
          <PressEffect onPress={onEdit} scale={0.9} hitSlop={8} accessibilityLabel={`Edit ${label}`}>
            <MaterialIcons name="edit" size={16} color={colors.inkFaint} />
          </PressEffect>
        ) : null}
      </View>
      <View style={{ marginTop: AppSpacing.md }}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  flex: { flex: 1 },
  flexShrink: { flexShrink: 1 },
  centered: { textAlign: 'center' },
  scroll: { paddingBottom: AppSpacing.giant },
  screenPadding: { paddingHorizontal: AppSpacing.screenX },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: AppSpacing.screenX,
    paddingRight: AppSpacing.lg,
    paddingTop: AppSpacing.lg,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  headerBody: { flex: 1, marginLeft: AppSpacing.xl },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  placeRow: { flexDirection: 'row', alignItems: 'center' },
  stats: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: AppSpacing.lg,
    borderRadius: AppRadii.lg,
    borderWidth: 1,
  },
  statDivider: { width: 1, height: 30 },
  sectionHead: { flexDirection: 'row', alignItems: 'center' },
  emptyPlans: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.lg,
  },
  planRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.md,
    borderRadius: AppRadii.md,
    borderWidth: 1,
  },
  planBody: { flex: 1, marginHorizontal: AppSpacing.md },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  editRow: { paddingHorizontal: AppSpacing.screenX, marginTop: AppSpacing.xxxl },
});
