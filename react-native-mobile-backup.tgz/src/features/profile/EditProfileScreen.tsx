import React, { useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppButton,
  AppChip,
  AppIconButton,
  AppSheet,
  AppTextField,
  CategoryChip,
  PressEffect,
  useSnackbar,
} from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Places, STOCK_PORTRAITS, type Place } from '../../core/utils/locations';
import {
  ACTIVITY_CATEGORIES,
  AVAILABILITY_SLOTS,
  availabilityLabel,
  type ActivityCategory,
  type AvailabilitySlot,
} from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { queryKeys, useInterestCatalog } from '../../queries';
import { profileService } from '../../services';
import { useAuthStore, useCurrentUser } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

function toggle<T>(list: T[], item: T): T[] {
  return list.includes(item) ? list.filter((entry) => entry !== item) : [...list, item];
}

/**
 * Everything from setup, on one screen, with a Save that only lights up when
 * something has actually changed.
 */
export function EditProfileScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const insets = useSafeAreaInsets();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();

  const me = useCurrentUser();
  const setUser = useAuthStore((state) => state.setUser);

  const [name, setName] = useState(me?.displayName ?? '');
  const [bio, setBio] = useState(me?.bio ?? '');
  const [occupation, setOccupation] = useState(me?.occupation ?? '');
  const [activities, setActivities] = useState<ActivityCategory[]>(
    me?.preferredActivities ?? [],
  );
  const [availability, setAvailability] = useState<AvailabilitySlot[]>(me?.availability ?? []);
  const [interests, setInterests] = useState<string[]>(
    (me?.interests ?? []).map((interest) => interest.slug),
  );
  const [avatarUrl, setAvatarUrl] = useState<string | null>(me?.avatarUrl ?? null);
  const [place, setPlace] = useState<Place>(() => Places.byName(me?.area) ?? Places.fallback);

  const [isSaving, setIsSaving] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [avatarSheet, setAvatarSheet] = useState(false);

  const { data: catalog } = useInterestCatalog();

  /** Every edit routes through here so Save reflects real changes only. */
  const edit = <T,>(setter: (value: T) => void) => (value: T) => {
    setter(value);
    setIsDirty(true);
  };

  const save = async () => {
    setIsSaving(true);
    try {
      const updated = await profileService.updateProfile({
        displayName: name.trim(),
        bio: bio.trim(),
        occupation: occupation.trim(),
        avatarUrl,
        city: place.city,
        area: place.name,
        latitude: place.latitude,
        longitude: place.longitude,
        preferredActivities: activities,
        availability,
        interests,
      });

      setUser(updated);
      void queryClient.invalidateQueries({ queryKey: queryKeys.homeFeed });
      void queryClient.invalidateQueries({ queryKey: ['discover'] });
      snackbar.success('Profile updated.');
      navigation.goBack();
    } catch (error) {
      setIsSaving(false);
      snackbar.error(
        error instanceof ApiException ? error.message : 'We could not save those changes.',
      );
    }
  };

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.appBar}>
        <AppIconButton
          icon="arrow-back"
          bordered={false}
          background="transparent"
          onPress={() => navigation.goBack()}
          accessibilityLabel="Go back"
        />
        <Text style={[type.subtitle, styles.appBarTitle]}>Edit profile</Text>
        <View style={styles.appBarSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.body}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.avatarRow}>
          <PressEffect onPress={() => setAvatarSheet(true)} scale={0.94}>
            <View>
              <AppAvatar
                name={name.length === 0 ? 'You' : name}
                imageUrl={avatarUrl}
                size={96}
                ring={colors.primary}
              />
              <View
                style={[
                  styles.cameraBadge,
                  { backgroundColor: colors.primary, borderColor: colors.canvas },
                ]}
              >
                <MaterialIcons name="camera-alt" size={14} color={colors.onPrimary} />
              </View>
            </View>
          </PressEffect>
        </View>

        <View style={{ height: AppSpacing.xxxl }} />
        <AppTextField
          value={name}
          onChangeText={edit(setName)}
          label="Name"
          maxLength={40}
          autoCapitalize="words"
        />

        <View style={{ height: AppSpacing.xl }} />
        <AppTextField
          value={occupation}
          onChangeText={edit(setOccupation)}
          label="What you do"
          hint="Optional"
          maxLength={80}
          autoCapitalize="sentences"
        />

        <View style={{ height: AppSpacing.xl }} />
        <AppTextField
          value={bio}
          onChangeText={edit(setBio)}
          label="About you"
          multiline
          numberOfLines={5}
          maxLength={500}
          autoCapitalize="sentences"
        />

        <Group label="AREA">
          <View style={styles.wrap}>
            {Places.all.map((option) => (
              <View key={option.name} style={styles.wrapItem}>
                <AppChip
                  label={option.name}
                  dense
                  selected={option.name === place.name}
                  onPress={() => edit(setPlace)(option)}
                />
              </View>
            ))}
          </View>
        </Group>

        <Group label="UP FOR">
          <View style={styles.wrap}>
            {ACTIVITY_CATEGORIES.map((category) => (
              <View key={category} style={styles.wrapItem}>
                <CategoryChip
                  category={category}
                  dense
                  selected={activities.includes(category)}
                  onPress={() => edit(setActivities)(toggle(activities, category))}
                />
              </View>
            ))}
          </View>
        </Group>

        <Group label="USUALLY FREE">
          <View style={styles.wrap}>
            {AVAILABILITY_SLOTS.map((slot) => (
              <View key={slot} style={styles.wrapItem}>
                <AppChip
                  label={availabilityLabel(slot)}
                  dense
                  selected={availability.includes(slot)}
                  onPress={() => edit(setAvailability)(toggle(availability, slot))}
                />
              </View>
            ))}
          </View>
        </Group>

        <Group label="INTERESTS">
          {!catalog ? (
            <View style={styles.loadingRow}>
              <ActivityIndicator size="small" />
            </View>
          ) : (
            <View style={styles.wrap}>
              {catalog.map((interest) => (
                <View key={interest.slug} style={styles.wrapItem}>
                  <AppChip
                    label={interest.label}
                    dense
                    leading={
                      interest.emoji.length > 0 ? (
                        <Text style={{ fontSize: 12 }}>{interest.emoji}</Text>
                      ) : undefined
                    }
                    selected={interests.includes(interest.slug)}
                    onPress={() => {
                      // Twelve is the cap the setup flow uses too.
                      if (interests.includes(interest.slug)) {
                        edit(setInterests)(interests.filter((slug) => slug !== interest.slug));
                      } else if (interests.length < 12) {
                        edit(setInterests)([...interests, interest.slug]);
                      }
                    }}
                  />
                </View>
              ))}
            </View>
          )}
        </Group>
      </ScrollView>

      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            paddingBottom: insets.bottom + AppSpacing.lg,
          },
        ]}
      >
        <AppButton
          label="Save changes"
          isLoading={isSaving}
          onPress={isDirty ? save : null}
        />
      </View>

      <AppSheet
        visible={avatarSheet}
        onDismiss={() => setAvatarSheet(false)}
        title="Choose a photo"
        subtitle="Uploads land in a later release."
      >
        <View style={styles.grid}>
          {STOCK_PORTRAITS.map((url) => (
            <View key={url} style={styles.gridItem}>
              <PressEffect
                onPress={() => {
                  edit(setAvatarUrl)(url);
                  setAvatarSheet(false);
                }}
                scale={0.92}
              >
                <Image
                  source={{ uri: url }}
                  style={[styles.gridImage, { backgroundColor: colors.surfaceSunken }]}
                  contentFit="cover"
                />
              </PressEffect>
            </View>
          ))}
        </View>
      </AppSheet>
    </SafeAreaView>
  );
}

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  const { colors, type } = useTheme();

  return (
    <View style={{ marginTop: AppSpacing.xxxl }}>
      <Text style={[type.overline, { color: colors.inkFaint }]}>{label}</Text>
      <View style={{ marginTop: AppSpacing.md }}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.md,
    paddingVertical: AppSpacing.sm,
  },
  appBarTitle: { flex: 1, textAlign: 'center' },
  appBarSpacer: { width: 42 },
  body: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    paddingBottom: AppSpacing.giant,
  },
  avatarRow: { alignItems: 'center' },
  cameraBadge: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    height: 30,
    width: 30,
    borderRadius: 15,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  loadingRow: { height: 40, alignItems: 'center', justifyContent: 'center' },
  footer: {
    paddingHorizontal: AppSpacing.screenX,
    paddingTop: AppSpacing.lg,
    borderTopWidth: 1,
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -AppSpacing.sm / 2 },
  gridItem: { width: '25%', padding: AppSpacing.sm / 2 },
  gridImage: { width: '100%', aspectRatio: 1, borderRadius: AppRadii.sm },
});
