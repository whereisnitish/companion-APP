import React from 'react';
import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppButton,
  AppIconButton,
  Entrance,
  ErrorStateView,
  ListRowSkeleton,
  PressEffect,
  Shimmer,
  StateView,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import { isUnread, type AppNotification } from '../../models/appNotification';
import { notificationIcon } from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { queryKeys, useNotifications } from '../../queries';
import { notificationService } from '../../services';
import { AppSpacing, useTheme, withAlpha } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * Notifications persist server-side, so this list is the record — the push
 * layer (APNs/FCM) is a delivery detail that can be added without changing
 * anything here.
 */
export function NotificationsScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const queryClient = useQueryClient();

  const { data, isPending, error, refetch, isRefetching } = useNotifications();

  const refresh = () => void queryClient.invalidateQueries({ queryKey: queryKeys.notifications });

  const open = (notification: AppNotification) => {
    if (isUnread(notification)) {
      void notificationService.markRead(notification.id).then(refresh);
    }

    const conversationId = notification.data.conversationId;
    if (typeof conversationId === 'string') {
      navigation.navigate('Chat', { conversationId });
      return;
    }

    if (
      notification.type === 'INVITATION_RECEIVED' ||
      notification.type === 'INVITATION_ACCEPTED' ||
      notification.type === 'INVITATION_DECLINED'
    ) {
      navigation.navigate('Tabs', { screen: 'Invites' });
    }
  };

  const markAllRead = async () => {
    await notificationService.markAllRead();
    refresh();
  };

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.appBar}>
        <AppIconButton
          icon="arrow-back"
          bordered={false}
          background="transparent"
          onPress={() => navigation.goBack()}
          accessibilityLabel="Go back"
        />
        <Text style={[type.subtitle, styles.appBarTitle]}>Notifications</Text>
        <View style={styles.appBarAction}>
          {data && data.unreadCount > 0 ? (
            <AppButton
              label="Mark all read"
              variant="ghost"
              size="small"
              expand={false}
              onPress={() => void markAllRead()}
            />
          ) : null}
        </View>
      </View>

      {isPending ? (
        <Shimmer>
          <ScrollView>
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <ListRowSkeleton key={index} leadingSize={40} />
            ))}
          </ScrollView>
        </Shimmer>
      ) : error ? (
        <ErrorStateView error={error} onRetry={() => void refetch()} />
      ) : (data?.items ?? []).length === 0 ? (
        <StateView
          icon="notifications-none"
          title="Nothing yet"
          message="Invitations, replies and reminders show up here so nothing slips past you."
        />
      ) : (
        <FlatList
          data={data?.items ?? []}
          keyExtractor={(notification) => notification.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={() => void refetch()}
              tintColor={colors.primary}
            />
          }
          ItemSeparatorComponent={() => (
            <View style={styles.separatorWrap}>
              <View style={[styles.separator, { backgroundColor: colors.border }]} />
            </View>
          )}
          renderItem={({ item, index }) => {
            const unread = isUnread(item);
            return (
              <Entrance index={index}>
                <PressEffect onPress={() => open(item)} scale={0.99}>
                  <View
                    style={[
                      styles.row,
                      {
                        backgroundColor: unread
                          ? withAlpha(colors.primarySoft, 0.35)
                          : 'transparent',
                      },
                    ]}
                  >
                    <View
                      style={[
                        styles.mark,
                        { backgroundColor: unread ? colors.primary : colors.surfaceSunken },
                      ]}
                    >
                      <MaterialIcons
                        name={notificationIcon(item.type)}
                        size={17}
                        color={unread ? colors.onPrimary : colors.inkMuted}
                      />
                    </View>

                    <View style={styles.rowBody}>
                      <View style={styles.rowHead}>
                        <Text
                          numberOfLines={1}
                          style={[unread ? type.bodyStrong : type.body, styles.rowTitle]}
                        >
                          {item.title}
                        </Text>
                        <Text
                          style={[
                            type.caption,
                            { color: colors.inkFaint, marginLeft: AppSpacing.sm },
                          ]}
                        >
                          {Format.relative(item.createdAt)}
                        </Text>
                      </View>

                      {item.body.length > 0 ? (
                        <Text
                          numberOfLines={2}
                          style={[
                            type.bodySmall,
                            { color: colors.inkMuted, lineHeight: 18, marginTop: 2 },
                          ]}
                        >
                          {item.body}
                        </Text>
                      ) : null}
                    </View>
                  </View>
                </PressEffect>
              </Entrance>
            );
          }}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.md,
    paddingVertical: AppSpacing.sm,
  },
  appBarTitle: { flex: 1, textAlign: 'center' },
  appBarAction: { minWidth: 42, alignItems: 'flex-end' },
  list: { paddingBottom: AppSpacing.giant },
  separatorWrap: { paddingLeft: 72, paddingRight: AppSpacing.screenX },
  separator: { height: 1 },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.lg,
  },
  mark: {
    height: 36,
    width: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowBody: { flex: 1, marginLeft: AppSpacing.lg },
  rowHead: { flexDirection: 'row', alignItems: 'center' },
  rowTitle: { flex: 1 },
});
