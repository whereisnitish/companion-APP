import React, { useState, type ReactNode } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons } from '@expo/vector-icons';

import {
  AppAvatar,
  AppChip,
  AppTextField,
  DateTimePickerFlow,
  PressEffect,
} from '../../components';
import { Places, STOCK_PORTRAITS, type Place } from '../../core/utils/locations';
import {
  ACTIVITY_CATEGORIES,
  AVAILABILITY_SLOTS,
  availabilityLabel,
  categoryForeground,
  categoryMeta,
  categoryTint,
  GENDERS,
  genderLabel,
  type ActivityCategory,
  type AvailabilitySlot,
  type Gender,
  type MaterialIconName,
} from '../../models/enums';
import { useInterestCatalog } from '../../queries';
import { AppRadii, AppSpacing, useTheme, withAlpha } from '../../theme';

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export function ageFrom(birthDate: Date): number {
  const now = new Date();
  let age = now.getFullYear() - birthDate.getFullYear();
  if (
    now.getMonth() < birthDate.getMonth() ||
    (now.getMonth() === birthDate.getMonth() && now.getDate() < birthDate.getDate())
  ) {
    age -= 1;
  }
  return age;
}

export function BasicsStep({
  name,
  onNameChange,
  birthDate,
  onBirthDateChange,
  gender,
  onGenderChange,
}: {
  name: string;
  onNameChange: (value: string) => void;
  birthDate: Date | null;
  onBirthDateChange: (value: Date) => void;
  gender: Gender | null;
  onGenderChange: (value: Gender) => void;
}) {
  const { colors, type } = useTheme();
  const [pickerSeed, setPickerSeed] = useState<Date | null>(null);
  const now = new Date();

  return (
    <View>
      <AppTextField
        value={name}
        onChangeText={onNameChange}
        label="Your name"
        hint="What people should call you"
        prefixIcon="person"
        autoCapitalize="words"
        maxLength={40}
      />

      <View style={{ height: AppSpacing.xl }} />
      <Text style={[type.label, { color: colors.inkMuted, marginBottom: AppSpacing.sm }]}>
        Date of birth
      </Text>
      <PressEffect
        onPress={() =>
          setPickerSeed(
            birthDate ?? new Date(now.getFullYear() - 25, now.getMonth(), now.getDate()),
          )
        }
        scale={0.99}
      >
        <View style={[styles.field, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <MaterialIcons name="cake" size={19} color={colors.inkFaint} />
          <Text
            style={[
              type.body,
              { color: birthDate ? colors.ink : colors.inkFaint, marginLeft: AppSpacing.md },
            ]}
          >
            {birthDate
              ? `${MONTHS[birthDate.getMonth()]} ${birthDate.getDate()}, ${birthDate.getFullYear()}`
              : 'Select your birthday'}
          </Text>
          <View style={styles.spacer} />
          {birthDate ? (
            <Text style={[type.caption, { color: colors.inkMuted }]}>
              {`${ageFrom(birthDate)} years old`}
            </Text>
          ) : null}
        </View>
      </PressEffect>

      <View style={{ height: AppSpacing.xl }} />
      <Text style={[type.label, { color: colors.inkMuted, marginBottom: AppSpacing.md }]}>
        You are
      </Text>
      <View style={styles.wrap}>
        {GENDERS.map((option) => (
          <View key={option} style={styles.wrapItem}>
            <AppChip
              label={genderLabel(option)}
              selected={gender === option}
              onPress={() => onGenderChange(option)}
            />
          </View>
        ))}
      </View>

      {/* Date only — the flow's time stage is skipped by taking the day. */}
      <DateTimePickerFlow
        initial={pickerSeed}
        minimumDate={new Date(now.getFullYear() - 99, 0, 1)}
        maximumDate={new Date(now.getFullYear() - 18, now.getMonth(), now.getDate())}
        onDone={(value) => {
          onBirthDateChange(value);
          setPickerSeed(null);
        }}
        onCancel={() => setPickerSeed(null)}
      />
    </View>
  );
}

export function PhotoStep({
  name,
  selected,
  onSelected,
}: {
  name: string;
  selected: string | null;
  onSelected: (url: string | null) => void;
}) {
  const { colors, type } = useTheme();

  return (
    <View>
      <View style={styles.centerRow}>
        <AppAvatar
          name={name.length === 0 ? 'You' : name}
          imageUrl={selected}
          size={116}
          ring={colors.primary}
        />
      </View>

      <View style={{ height: AppSpacing.xxxl }} />
      <View style={styles.grid}>
        {STOCK_PORTRAITS.map((url) => {
          const isSelected = selected === url;
          return (
            <View key={url} style={styles.gridItem}>
              <PressEffect onPress={() => onSelected(isSelected ? null : url)} scale={0.92}>
                <View
                  style={[
                    styles.gridFrame,
                    {
                      borderColor: isSelected ? colors.primary : colors.border,
                      borderWidth: isSelected ? 2 : 1,
                    },
                  ]}
                >
                  <Image
                    source={{ uri: url }}
                    style={[styles.gridImage, { backgroundColor: colors.surfaceSunken }]}
                    contentFit="cover"
                  />
                </View>
              </PressEffect>
            </View>
          );
        })}
      </View>

      <View style={{ height: AppSpacing.xl }} />
      <Text style={[type.caption, styles.centered, { color: colors.inkFaint, lineHeight: 18 }]}>
        Photo uploads arrive with the next release — for now, pick one of these or skip. You can
        change it any time from your profile.
      </Text>
    </View>
  );
}

export function PlaceStep({
  selected,
  onSelected,
}: {
  selected: Place;
  onSelected: (place: Place) => void;
}) {
  const { colors, type } = useTheme();
  const [query, setQuery] = useState('');
  const results = Places.search(query);

  return (
    <View>
      <AppTextField
        value={query}
        onChangeText={setQuery}
        hint="Search your area"
        prefixIcon="search"
      />

      <View style={{ height: AppSpacing.xl }} />
      <View style={styles.wrap}>
        {results.map((place) => (
          <View key={place.name} style={styles.wrapItem}>
            <AppChip
              label={place.name}
              icon="place"
              selected={selected.name === place.name}
              onPress={() => onSelected(place)}
            />
          </View>
        ))}
      </View>

      {results.length === 0 ? (
        <Text style={[type.bodySmall, { color: colors.inkMuted, marginTop: AppSpacing.lg }]}>
          {`No match. The MVP covers ${Places.all.length} Bengaluru neighbourhoods.`}
        </Text>
      ) : null}
    </View>
  );
}

export function ActivitiesStep({
  selected,
  onChange,
}: {
  selected: ActivityCategory[];
  onChange: (value: ActivityCategory[]) => void;
}) {
  const { isDark } = useTheme();

  return (
    <View style={styles.tileGrid}>
      {ACTIVITY_CATEGORIES.map((category) => {
        const meta = categoryMeta(category);
        return (
          <View key={category} style={styles.tileItem}>
            <SelectableTile
              label={meta.label}
              icon={meta.icon}
              hue={categoryForeground(category, isDark)}
              tint={categoryTint(category, isDark)}
              selected={selected.includes(category)}
              onPress={() =>
                onChange(
                  selected.includes(category)
                    ? selected.filter((entry) => entry !== category)
                    : [...selected, category],
                )
              }
            />
          </View>
        );
      })}
    </View>
  );
}

function SelectableTile({
  label,
  icon,
  hue,
  tint,
  selected,
  onPress,
}: {
  label: string;
  icon: MaterialIconName;
  hue: string;
  tint: string;
  selected: boolean;
  onPress: () => void;
}) {
  const { colors, type } = useTheme();

  return (
    <PressEffect onPress={onPress} scale={0.96}>
      <View
        style={[
          styles.tile,
          {
            backgroundColor: selected ? tint : colors.surface,
            borderColor: selected ? withAlpha(hue, 0.45) : colors.border,
            borderWidth: selected ? 1.5 : 1,
          },
        ]}
      >
        <MaterialIcons name={icon} size={20} color={selected ? hue : colors.inkMuted} />
        <Text
          numberOfLines={1}
          style={[
            type.label,
            { color: selected ? colors.ink : colors.inkMuted, flex: 1, marginHorizontal: AppSpacing.md },
          ]}
        >
          {label}
        </Text>
        {selected ? <MaterialIcons name="check-circle" size={18} color={hue} /> : null}
      </View>
    </PressEffect>
  );
}

const AVAILABILITY_HINTS: Record<AvailabilitySlot, string> = {
  TONIGHT: 'Free in the next few hours',
  TOMORROW: 'Something planned for tomorrow',
  THIS_WEEK: 'Any evening this week works',
  WEEKEND: 'Saturdays and Sundays',
  FLEXIBLE: 'Ask me — my schedule moves',
};

export function AvailabilityStep({
  selected,
  onChange,
}: {
  selected: AvailabilitySlot[];
  onChange: (value: AvailabilitySlot[]) => void;
}) {
  const { colors, type } = useTheme();

  return (
    <View>
      {AVAILABILITY_SLOTS.map((slot) => {
        const isSelected = selected.includes(slot);
        return (
          <View key={slot} style={{ marginBottom: AppSpacing.md }}>
            <PressEffect
              onPress={() =>
                onChange(
                  isSelected ? selected.filter((entry) => entry !== slot) : [...selected, slot],
                )
              }
              scale={0.98}
            >
              <View
                style={[
                  styles.slot,
                  {
                    backgroundColor: isSelected ? colors.primarySoft : colors.surface,
                    borderColor: isSelected ? colors.primary : colors.border,
                    borderWidth: isSelected ? 1.5 : 1,
                  },
                ]}
              >
                <View style={styles.flex}>
                  <Text style={type.bodyStrong}>{availabilityLabel(slot)}</Text>
                  <Text style={[type.caption, { color: colors.inkMuted, marginTop: 2 }]}>
                    {AVAILABILITY_HINTS[slot]}
                  </Text>
                </View>
                {isSelected ? (
                  <MaterialIcons name="check-circle" size={20} color={colors.primary} />
                ) : null}
              </View>
            </PressEffect>
          </View>
        );
      })}
    </View>
  );
}

export function InterestsStep({
  selected,
  onChange,
}: {
  selected: string[];
  onChange: (value: string[]) => void;
}) {
  const { colors, type } = useTheme();
  const { data, isPending, error } = useInterestCatalog();

  if (isPending) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="small" />
      </View>
    );
  }

  if (error || !data) {
    return (
      <Text style={[type.bodySmall, { color: colors.inkMuted }]}>
        We could not load interests. You can add them later from your profile.
      </Text>
    );
  }

  return (
    <View>
      <Text style={[type.caption, { color: colors.inkFaint }]}>
        {`${selected.length} of 12 selected`}
      </Text>
      <View style={[styles.wrap, { marginTop: AppSpacing.lg }]}>
        {data.map((interest) => (
          <View key={interest.slug} style={styles.wrapItem}>
            <AppChip
              label={interest.label}
              leading={
                interest.emoji.length > 0 ? (
                  <Text style={{ fontSize: 13 }}>{interest.emoji}</Text>
                ) : undefined
              }
              selected={selected.includes(interest.slug)}
              onPress={() => {
                if (selected.includes(interest.slug)) {
                  onChange(selected.filter((slug) => slug !== interest.slug));
                } else if (selected.length < 12) {
                  onChange([...selected, interest.slug]);
                }
              }}
            />
          </View>
        ))}
      </View>
    </View>
  );
}

export function AboutStep({
  bio,
  onBioChange,
  occupation,
  onOccupationChange,
}: {
  bio: string;
  onBioChange: (value: string) => void;
  occupation: string;
  onOccupationChange: (value: string) => void;
}) {
  return (
    <View>
      <AppTextField
        value={bio}
        onChangeText={onBioChange}
        label="About you"
        hint="Chronically early to films. Will debate the ending over coffee."
        multiline
        numberOfLines={5}
        maxLength={500}
        autoCapitalize="sentences"
        helper={`${bio.length}/500`}
      />
      <View style={{ height: AppSpacing.xl }} />
      <AppTextField
        value={occupation}
        onChangeText={onOccupationChange}
        label="What you do (optional)"
        hint="Product designer"
        prefixIcon="work"
        maxLength={80}
        autoCapitalize="sentences"
      />
    </View>
  );
}

export function StepShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  const { colors, type } = useTheme();

  return (
    <View>
      <Text style={type.headline}>{title}</Text>
      <Text
        style={[type.body, { color: colors.inkMuted, lineHeight: 23, marginTop: AppSpacing.md }]}
      >
        {subtitle}
      </Text>
      <View style={{ marginTop: AppSpacing.xxxl }}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  spacer: { flex: 1 },
  centered: { textAlign: 'center' },
  centerRow: { alignItems: 'center' },
  field: {
    height: 54,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    borderRadius: AppRadii.md,
    borderWidth: 1,
  },
  wrap: { flexDirection: 'row', flexWrap: 'wrap' },
  wrapItem: { marginRight: AppSpacing.sm, marginBottom: AppSpacing.sm },
  grid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -AppSpacing.sm / 2 },
  gridItem: { width: '25%', padding: AppSpacing.sm / 2 },
  gridFrame: { borderRadius: AppRadii.md, padding: 2 },
  gridImage: { width: '100%', aspectRatio: 1, borderRadius: AppRadii.sm },
  tileGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -AppSpacing.sm / 2 },
  tileItem: { width: '50%', padding: AppSpacing.sm / 2 },
  tile: {
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.lg,
    borderRadius: AppRadii.md,
  },
  slot: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: AppSpacing.lg,
    borderRadius: AppRadii.md,
  },
  loading: { padding: AppSpacing.xxxl, alignItems: 'center' },
});
