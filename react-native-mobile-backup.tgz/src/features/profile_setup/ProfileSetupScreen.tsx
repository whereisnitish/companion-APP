import React, { useState } from 'react';
import { Keyboard, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQueryClient } from '@tanstack/react-query';

import { AppButton, AppIconButton, Entrance, useSnackbar } from '../../components';
import { ApiException } from '../../core/network/apiException';
import { Places, type Place } from '../../core/utils/locations';
import { queryKeys } from '../../queries';
import { emptyProfileDraft, profileService, type ProfileDraft } from '../../services';
import { useAuthStore } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import {
  AboutStep,
  ActivitiesStep,
  AvailabilityStep,
  BasicsStep,
  InterestsStep,
  PhotoStep,
  PlaceStep,
  StepShell,
} from './steps';

const STEP_COUNT = 7;

/**
 * Profile setup as a conversation, not a form.
 *
 * One question per screen, each answerable in a tap or two, with a progress
 * rule at the top so the end is always in sight. The whole profile is sent in
 * a single request at the end — no half-built profiles in the database.
 */
export function ProfileSetupScreen() {
  const { colors, type } = useTheme();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const setUser = useAuthStore((state) => state.setUser);

  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<ProfileDraft>(emptyProfileDraft);
  const [place, setPlace] = useState<Place>(Places.fallback);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const patch = (next: Partial<ProfileDraft>) => setDraft((current) => ({ ...current, ...next }));

  /** Each step gates "Continue" on its own answer being present. */
  const canContinue = (() => {
    switch (step) {
      case 0:
        return (
          draft.displayName.trim().length >= 2 &&
          draft.birthDate !== null &&
          draft.gender !== null
        );
      case 3:
        return draft.preferredActivities.length > 0;
      case 4:
        return draft.availability.length > 0;
      default:
        return true;
    }
  })();

  const submit = async () => {
    setIsSubmitting(true);

    const payload: ProfileDraft = {
      ...draft,
      displayName: draft.displayName.trim(),
      bio: draft.bio.trim(),
      occupation: draft.occupation?.trim() ?? null,
      city: place.city,
      area: place.name,
      latitude: place.latitude,
      longitude: place.longitude,
    };

    try {
      const user = await profileService.createProfile(payload);
      setUser(user);
      void queryClient.invalidateQueries({ queryKey: queryKeys.homeFeed });
      // The navigator's auth gate moves us into the app.
    } catch (error) {
      setIsSubmitting(false);
      snackbar.error(
        error instanceof ApiException
          ? error.message
          : 'We could not save your profile. Please try again.',
      );
    }
  };

  const next = () => {
    Keyboard.dismiss();
    if (step === STEP_COUNT - 1) {
      void submit();
      return;
    }
    setStep((current) => current + 1);
  };

  const back = () => {
    Keyboard.dismiss();
    if (step === 0) return;
    setStep((current) => current - 1);
  };

  const steps = [
    <StepShell
      key="basics"
      title="First, the basics."
      subtitle="This is what people see before anything else."
    >
      <BasicsStep
        name={draft.displayName}
        onNameChange={(displayName) => patch({ displayName })}
        birthDate={draft.birthDate}
        onBirthDateChange={(birthDate) => patch({ birthDate })}
        gender={draft.gender}
        onGenderChange={(gender) => patch({ gender })}
      />
    </StepShell>,

    <StepShell
      key="photo"
      title="Add a photo."
      subtitle="Profiles with a face get roughly three times the replies."
    >
      <PhotoStep
        name={draft.displayName}
        selected={draft.avatarUrl}
        onSelected={(avatarUrl) => patch({ avatarUrl })}
      />
    </StepShell>,

    <StepShell
      key="place"
      title="Where are you based?"
      subtitle="We only ever show an approximate distance, never an address."
    >
      <PlaceStep selected={place} onSelected={setPlace} />
    </StepShell>,

    <StepShell
      key="activities"
      title="What are you up for?"
      subtitle="Pick everything that sounds like a good evening."
    >
      <ActivitiesStep
        selected={draft.preferredActivities}
        onChange={(preferredActivities) => patch({ preferredActivities })}
      />
    </StepShell>,

    <StepShell
      key="availability"
      title="When are you free?"
      subtitle="Rough is fine. You can change it any time."
    >
      <AvailabilityStep
        selected={draft.availability}
        onChange={(availability) => patch({ availability })}
      />
    </StepShell>,

    <StepShell
      key="interests"
      title="What are you into?"
      subtitle="Shared interests are how we sort who you see first."
    >
      <InterestsStep selected={draft.interests} onChange={(interests) => patch({ interests })} />
    </StepShell>,

    <StepShell
      key="about"
      title="Say hello."
      subtitle="A line or two. The specific ones always do better."
    >
      <AboutStep
        bio={draft.bio}
        onBioChange={(bio) => patch({ bio })}
        occupation={draft.occupation ?? ''}
        onOccupationChange={(occupation) => patch({ occupation })}
      />
    </StepShell>,
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <View style={{ opacity: step === 0 ? 0 : 1 }}>
          <AppIconButton
            icon="arrow-back"
            bordered={false}
            background="transparent"
            onPress={step === 0 ? null : back}
            accessibilityLabel="Go back"
          />
        </View>

        <View style={[styles.progressTrack, { backgroundColor: colors.surfaceSunken }]}>
          <View
            style={[
              styles.progressFill,
              {
                backgroundColor: colors.primary,
                width: `${((step + 1) / STEP_COUNT) * 100}%`,
              },
            ]}
          />
        </View>

        <Text style={[type.numeric, { color: colors.inkFaint, marginLeft: AppSpacing.lg }]}>
          {`${step + 1}/${STEP_COUNT}`}
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.body}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
      >
        <Entrance key={step} index={0}>
          {steps[step]}
        </Entrance>
      </ScrollView>

      <View style={styles.footer}>
        <AppButton
          label={step === STEP_COUNT - 1 ? 'Finish' : 'Continue'}
          isLoading={isSubmitting}
          onPress={canContinue ? next : null}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: AppSpacing.lg,
    paddingRight: AppSpacing.xxl,
    paddingTop: AppSpacing.sm,
  },
  progressTrack: {
    flex: 1,
    height: 3,
    marginLeft: AppSpacing.sm,
    borderRadius: AppRadii.pill,
    overflow: 'hidden',
  },
  progressFill: { height: 3, borderRadius: AppRadii.pill },
  body: {
    paddingHorizontal: AppSpacing.xxl,
    paddingTop: AppSpacing.xxxl,
    paddingBottom: AppSpacing.xxxl,
  },
  footer: {
    paddingHorizontal: AppSpacing.xxl,
    paddingTop: AppSpacing.md,
    paddingBottom: AppSpacing.xl,
  },
});
