import React, { useCallback, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useQueryClient } from '@tanstack/react-query';

import {
  AppAvatar,
  AppIconButton,
  ErrorStateView,
  PressEffect,
  Shimmer,
  SkeletonBox,
  StateView,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import type { ActivityContext } from '../../models/activity';
import { isRead, isSystem, type Conversation, type Message } from '../../models/conversation';
import { categoryForeground, categoryMeta, categoryTint } from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { queryKeys, useConversationById } from '../../queries';
import { useChat, type ChatApi } from '../../stores';
import { AppRadii, AppSpacing, useTheme } from '../../theme';
import { useSafetyActions } from '../settings/SafetyActionsSheet';

type Navigation = NativeStackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'Chat'>;

const sameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

/**
 * The conversation.
 *
 * Two things make this feel different from a generic chat: the plan is pinned
 * to the top of the thread, so neither person forgets what they agreed to; and
 * the composer sits on its own surface with a send key that only appears when
 * there is something to send.
 */
export function ChatScreen({ route }: { route: Route }) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const { conversationId } = route.params;

  const chat = useChat(conversationId);
  const { data: conversation } = useConversationById(conversationId);
  const [draft, setDraft] = useState('');
  const listRef = useRef<FlatList<Message>>(null);

  const send = useCallback(async () => {
    const body = draft.trim();
    if (body.length === 0) return;
    setDraft('');

    await chat.send(body);
    void queryClient.invalidateQueries({ queryKey: queryKeys.conversations });
    listRef.current?.scrollToOffset({ offset: 0, animated: true });
  }, [draft, chat, queryClient]);

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <ChatHeader conversation={conversation ?? null} isPeerTyping={chat.isPeerTyping} />

      {conversation?.activity ? <ActivityBanner activity={conversation.activity} /> : null}

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={insets.top}
      >
        <View style={styles.flex}>
          <MessageList chat={chat} listRef={listRef} />
        </View>

        <Composer
          value={draft}
          onChangeText={(value) => {
            setDraft(value);
            chat.onComposerChanged(value);
          }}
          onSend={send}
        />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function ChatHeader({
  conversation,
  isPeerTyping,
}: {
  conversation: Conversation | null;
  isPeerTyping: boolean;
}) {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();
  const { showSafetyActions } = useSafetyActions();

  return (
    <View
      style={[styles.header, { backgroundColor: colors.canvas, borderBottomColor: colors.border }]}
    >
      <AppIconButton
        icon="arrow-back"
        bordered={false}
        background="transparent"
        onPress={() => navigation.goBack()}
        accessibilityLabel="Go back"
      />

      {!conversation ? (
        <Shimmer>
          <View style={styles.headerRow}>
            <SkeletonBox circle size={38} />
            <View style={{ width: AppSpacing.md }} />
            <SkeletonBox width={120} height={14} />
          </View>
        </Shimmer>
      ) : (
        <>
          <View style={styles.flex}>
            <PressEffect
              onPress={() =>
                navigation.navigate('PersonProfile', { userId: conversation.participant.id })
              }
              scale={0.98}
            >
              <View style={styles.headerRow}>
                <AppAvatar
                  name={conversation.participant.displayName}
                  imageUrl={conversation.participant.avatarUrl}
                  size={38}
                  isOnline={conversation.participant.isOnline}
                  showPresence
                />
                <View style={styles.headerBody}>
                  <Text numberOfLines={1} style={type.subtitle}>
                    {conversation.participant.displayName}
                  </Text>
                  <Text
                    style={[
                      type.caption,
                      { color: isPeerTyping ? colors.primary : colors.inkMuted },
                    ]}
                  >
                    {isPeerTyping
                      ? 'typing…'
                      : Format.lastSeen(
                          conversation.participant.lastActiveAt,
                          conversation.participant.isOnline,
                        )}
                  </Text>
                </View>
              </View>
            </PressEffect>
          </View>

          <AppIconButton
            icon="more-horiz"
            bordered={false}
            background="transparent"
            accessibilityLabel="More options"
            onPress={() =>
              showSafetyActions({
                userId: conversation.participant.id,
                displayName: conversation.participant.displayName,
              })
            }
          />
        </>
      )}
    </View>
  );
}

/**
 * The plan, pinned. Tapping it opens the activity so the details are never
 * more than one hop away mid-conversation.
 */
function ActivityBanner({ activity }: { activity: ActivityContext }) {
  const { colors, type, isDark } = useTheme();
  const navigation = useNavigation<Navigation>();
  const foreground = categoryForeground(activity.category, isDark);

  return (
    <PressEffect
      onPress={() => navigation.navigate('ActivityDetail', { activityId: activity.id })}
      scale={0.995}
    >
      <View style={[styles.banner, { backgroundColor: categoryTint(activity.category, isDark) }]}>
        <MaterialIcons name={categoryMeta(activity.category).icon} size={16} color={foreground} />
        <Text
          numberOfLines={1}
          style={[
            type.caption,
            { color: colors.ink, fontWeight: '600', marginHorizontal: AppSpacing.md, flex: 1 },
          ]}
        >
          {`${activity.title} · ${Format.whenShort(activity.startsAt)}`}
        </Text>
        <MaterialIcons name="chevron-right" size={18} color={foreground} />
      </View>
    </PressEffect>
  );
}

function MessageList({
  chat,
  listRef,
}: {
  chat: ChatApi;
  listRef: React.RefObject<FlatList<Message> | null>;
}) {
  if (chat.isLoading) {
    return (
      <Shimmer>
        <ScrollView contentContainerStyle={{ padding: AppSpacing.screenX }}>
          {[0, 1, 2, 3, 4, 5].map((index) => (
            <View
              key={index}
              style={[
                styles.skeletonRow,
                { alignItems: index % 2 === 0 ? 'flex-start' : 'flex-end' },
              ]}
            >
              <SkeletonBox
                width={index % 2 === 0 ? 200 : 150}
                height={40}
                radius={AppRadii.lg}
              />
            </View>
          ))}
        </ScrollView>
      </Shimmer>
    );
  }

  if (chat.error && chat.messages.length === 0) {
    return <ErrorStateView error={chat.error} onRetry={() => void chat.load()} />;
  }

  if (chat.messages.length === 0) {
    return (
      <StateView
        icon="waving-hand"
        title="Say the first thing"
        message="You matched on a plan — the hard part is done. Ask about the details."
      />
    );
  }

  return (
    <FlatList
      ref={listRef}
      data={chat.messages}
      inverted
      keyExtractor={(message) => message.id}
      contentContainerStyle={styles.messageList}
      showsVerticalScrollIndicator={false}
      // The list is inverted, so "end reached" means the oldest messages.
      onEndReached={() => void chat.loadMore()}
      onEndReachedThreshold={0.4}
      ListFooterComponent={
        chat.isLoadingMore ? (
          <View style={styles.loadingMore}>
            <ActivityIndicator size="small" />
          </View>
        ) : null
      }
      renderItem={({ item, index }) => {
        // The list is inverted, so the next index is the older message.
        const older = chat.messages[index + 1] ?? null;
        const newer = index > 0 ? chat.messages[index - 1] ?? null : null;

        const showDayDivider = !older || !sameDay(older.createdAt, item.createdAt);
        const isLastOfGroup = !newer || newer.isMine !== item.isMine || isSystem(newer);

        return (
          <View>
            {showDayDivider ? <DayDivider when={item.createdAt} /> : null}
            <MessageBubble
              message={item}
              isLastOfGroup={isLastOfGroup}
              onRetry={() => void chat.retry(item)}
            />
          </View>
        );
      }}
    />
  );
}

function DayDivider({ when }: { when: Date }) {
  const { colors, type } = useTheme();

  return (
    <View style={styles.dayDivider}>
      <View style={[styles.rule, { backgroundColor: colors.border }]} />
      <Text style={[type.caption, { color: colors.inkFaint, marginHorizontal: AppSpacing.md }]}>
        {Format.messageDay(when)}
      </Text>
      <View style={[styles.rule, { backgroundColor: colors.border }]} />
    </View>
  );
}

function MessageBubble({
  message,
  isLastOfGroup,
  onRetry,
}: {
  message: Message;
  isLastOfGroup: boolean;
  onRetry: () => void;
}) {
  const { colors, type } = useTheme();

  if (isSystem(message)) {
    return (
      <View style={styles.systemRow}>
        <View style={[styles.systemBubble, { backgroundColor: colors.surfaceSunken }]}>
          <Text style={[type.caption, styles.centered, { color: colors.inkMuted }]}>
            {message.body}
          </Text>
        </View>
      </View>
    );
  }

  const isMine = message.isMine;
  const maxWidth = Dimensions.get('window').width * 0.74;

  return (
    <View
      style={{
        marginBottom: isLastOfGroup ? AppSpacing.md : AppSpacing.xs + 1,
        alignItems: isMine ? 'flex-end' : 'flex-start',
      }}
    >
      <View style={[styles.bubbleRow, { justifyContent: isMine ? 'flex-end' : 'flex-start' }]}>
        {message.hasFailed ? (
          <PressEffect onPress={onRetry} scale={0.9} hitSlop={8}>
            <MaterialIcons
              name="refresh"
              size={16}
              color={colors.danger}
              style={{ marginRight: AppSpacing.sm }}
            />
          </PressEffect>
        ) : null}

        <View
          style={[
            styles.bubble,
            {
              maxWidth,
              opacity: message.isPending ? 0.62 : 1,
              backgroundColor: isMine ? colors.primary : colors.surface,
              borderWidth: isMine ? 0 : 1,
              borderColor: colors.border,
              borderBottomLeftRadius: isMine ? AppRadii.lg : AppRadii.xs,
              borderBottomRightRadius: isMine ? AppRadii.xs : AppRadii.lg,
            },
          ]}
        >
          <Text style={[type.body, { color: isMine ? colors.onPrimary : colors.ink, lineHeight: 22 }]}>
            {message.body}
          </Text>
        </View>
      </View>

      {isLastOfGroup ? (
        <View style={styles.meta}>
          <Text
            style={[
              type.caption,
              {
                color: message.hasFailed ? colors.danger : colors.inkFaint,
                fontSize: 11,
                lineHeight: 15,
              },
            ]}
          >
            {message.hasFailed ? 'Not sent — tap to retry' : Format.time(message.createdAt)}
          </Text>
          {isMine && !message.hasFailed ? (
            <MaterialIcons
              name={message.isPending ? 'schedule' : isRead(message) ? 'done-all' : 'done'}
              size={13}
              color={isRead(message) ? colors.primary : colors.inkFaint}
              style={{ marginLeft: AppSpacing.xs + 1 }}
            />
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

function Composer({
  value,
  onChangeText,
  onSend,
}: {
  value: string;
  onChangeText: (value: string) => void;
  onSend: () => void;
}) {
  const { colors, type } = useTheme();
  const insets = useSafeAreaInsets();
  const canSend = value.trim().length > 0;

  return (
    <View
      style={[
        styles.composer,
        {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          paddingBottom: insets.bottom + AppSpacing.md,
        },
      ]}
    >
      <View style={[styles.composerField, { backgroundColor: colors.surfaceSunken }]}>
        <TextInput
          value={value}
          onChangeText={onChangeText}
          multiline
          maxLength={2000}
          autoCapitalize="sentences"
          placeholder="Message"
          placeholderTextColor={colors.inkFaint}
          selectionColor={colors.primary}
          style={[type.body, styles.composerInput, { color: colors.ink }]}
        />
      </View>

      <View style={{ width: AppSpacing.sm }} />
      <View style={{ opacity: canSend ? 1 : 0.4, transform: [{ scale: canSend ? 1 : 0.82 }] }}>
        <AppIconButton
          icon="arrow-upward"
          size={44}
          iconSize={19}
          background={colors.primary}
          foreground={colors.onPrimary}
          bordered={false}
          onPress={canSend ? onSend : null}
          accessibilityLabel="Send"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: AppSpacing.sm,
    paddingRight: AppSpacing.lg,
    paddingTop: AppSpacing.sm,
    paddingBottom: AppSpacing.md,
    borderBottomWidth: 1,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  headerBody: { flex: 1, marginLeft: AppSpacing.md },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.md,
  },
  messageList: {
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.lg,
  },
  skeletonRow: { marginBottom: AppSpacing.md },
  loadingMore: { paddingVertical: AppSpacing.lg, alignItems: 'center' },
  dayDivider: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: AppSpacing.lg,
  },
  rule: { flex: 1, height: 1 },
  systemRow: { alignItems: 'center', paddingVertical: AppSpacing.md },
  systemBubble: {
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.sm,
    borderRadius: AppRadii.pill,
  },
  centered: { textAlign: 'center' },
  bubbleRow: { flexDirection: 'row', alignItems: 'flex-end' },
  bubble: {
    paddingHorizontal: AppSpacing.lg,
    paddingVertical: AppSpacing.md,
    borderTopLeftRadius: AppRadii.lg,
    borderTopRightRadius: AppRadii.lg,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: AppSpacing.xs + 1,
    paddingHorizontal: AppSpacing.xs,
  },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: AppSpacing.lg,
    paddingTop: AppSpacing.md,
    borderTopWidth: 1,
  },
  composerField: {
    flex: 1,
    minHeight: 44,
    maxHeight: 132,
    justifyContent: 'center',
    paddingHorizontal: AppSpacing.lg,
    borderRadius: AppRadii.xl,
  },
  composerInput: { paddingVertical: 12, maxHeight: 108 },
});
