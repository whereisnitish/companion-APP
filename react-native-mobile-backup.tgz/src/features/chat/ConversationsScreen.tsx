import React from 'react';
import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import {
  AppAvatar,
  Entrance,
  ErrorStateView,
  ListRowSkeleton,
  PressEffect,
  Shimmer,
  StateView,
  VerifiedBadge,
} from '../../components';
import { Format } from '../../core/utils/formatters';
import type { Conversation } from '../../models/conversation';
import { categoryForeground, categoryMeta, isVerified } from '../../models/enums';
import type { RootStackParamList } from '../../navigation/types';
import { useConversations, useUnreadMessages } from '../../queries';
import { AppRadii, AppSpacing, useTheme } from '../../theme';

type Navigation = NativeStackNavigationProp<RootStackParamList>;

/**
 * The inbox.
 *
 * Every thread here exists because an invitation was accepted, so each row
 * carries the plan it came from. That context is the difference between a
 * message list and a pile of strangers.
 */
export function ConversationsScreen() {
  const { colors, type } = useTheme();
  const navigation = useNavigation<Navigation>();

  const { data, isPending, error, refetch, isRefetching } = useConversations();
  const unread = useUnreadMessages();

  return (
    <SafeAreaView edges={['top']} style={[styles.container, { backgroundColor: colors.canvas }]}>
      <View style={styles.header}>
        <Text style={type.headline}>Messages</Text>
        <Text style={[type.bodySmall, { color: colors.inkMuted, marginTop: AppSpacing.xs }]}>
          {unread === 0
            ? 'All caught up.'
            : `${unread} unread ${unread === 1 ? 'message' : 'messages'}.`}
        </Text>
      </View>

      <View style={styles.body}>
        {isPending ? (
          <Shimmer>
            <ScrollView>
              {[0, 1, 2, 3, 4, 5].map((index) => (
                <ListRowSkeleton key={index} leadingSize={52} />
              ))}
            </ScrollView>
          </Shimmer>
        ) : error ? (
          <ScrollView contentContainerStyle={styles.stateBody}>
            <ErrorStateView error={error} onRetry={() => void refetch()} />
          </ScrollView>
        ) : (data ?? []).length === 0 ? (
          <ScrollView contentContainerStyle={styles.stateBody}>
            <StateView
              icon="forum"
              title="No conversations yet"
              message="A chat opens the moment an invitation is accepted — with the plan already in it."
              actionLabel="Find someone"
              onAction={() => navigation.navigate('Tabs', { screen: 'Discover' })}
            />
          </ScrollView>
        ) : (
          <FlatList
            data={data ?? []}
            keyExtractor={(conversation) => conversation.id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={isRefetching}
                onRefresh={() => void refetch()}
                tintColor={colors.primary}
              />
            }
            ItemSeparatorComponent={() => (
              <View style={styles.separatorWrap}>
                <View style={[styles.separator, { backgroundColor: colors.border }]} />
              </View>
            )}
            renderItem={({ item, index }) => (
              <Entrance index={index}>
                <ConversationRow conversation={item} />
              </Entrance>
            )}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

function ConversationRow({ conversation }: { conversation: Conversation }) {
  const { colors, type, isDark } = useTheme();
  const navigation = useNavigation<Navigation>();

  const hasUnread = conversation.unreadCount > 0;
  const activity = conversation.activity;

  return (
    <PressEffect
      onPress={() => navigation.navigate('Chat', { conversationId: conversation.id })}
      scale={0.99}
    >
      <View style={styles.row}>
        <AppAvatar
          name={conversation.participant.displayName}
          imageUrl={conversation.participant.avatarUrl}
          size={52}
          isOnline={conversation.participant.isOnline}
          showPresence
        />

        <View style={styles.rowBody}>
          <View style={styles.rowHead}>
            <Text
              numberOfLines={1}
              style={[hasUnread ? type.bodyStrong : type.body, styles.rowName]}
            >
              {conversation.participant.displayName}
            </Text>
            {isVerified(conversation.participant.verification) ? (
              <View style={{ marginLeft: AppSpacing.xs + 2 }}>
                <VerifiedBadge size={13} status={conversation.participant.verification} />
              </View>
            ) : null}
            <View style={styles.spacer} />
            <Text
              style={[
                type.caption,
                {
                  color: hasUnread ? colors.accent : colors.inkFaint,
                  fontWeight: hasUnread ? '600' : '400',
                },
              ]}
            >
              {Format.relative(conversation.lastMessageAt)}
            </Text>
          </View>

          {activity ? (
            <View style={styles.activityRow}>
              <MaterialIcons
                name={categoryMeta(activity.category).icon}
                size={12}
                color={categoryForeground(activity.category, isDark)}
              />
              <Text
                numberOfLines={1}
                style={[
                  type.caption,
                  {
                    color: categoryForeground(activity.category, isDark),
                    marginLeft: AppSpacing.xs + 1,
                    flex: 1,
                  },
                ]}
              >
                {`${activity.title} · ${Format.whenShort(activity.startsAt)}`}
              </Text>
            </View>
          ) : null}

          <View style={styles.previewRow}>
            <Text
              numberOfLines={2}
              style={[
                type.bodySmall,
                { color: hasUnread ? colors.ink : colors.inkMuted, lineHeight: 18, flex: 1 },
              ]}
            >
              {conversation.lastMessagePreview.length === 0
                ? 'Say hello'
                : conversation.lastMessagePreview}
            </Text>

            {hasUnread ? (
              <View style={[styles.unread, { backgroundColor: colors.accent }]}>
                <Text style={[type.caption, styles.unreadText]}>
                  {conversation.unreadCount > 9 ? '9+' : `${conversation.unreadCount}`}
                </Text>
              </View>
            ) : null}
          </View>
        </View>
      </View>
    </PressEffect>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: AppSpacing.screenX, paddingVertical: AppSpacing.lg },
  body: { flex: 1 },
  listContent: { paddingBottom: AppSpacing.giant },
  stateBody: { flexGrow: 1, paddingTop: 30 },
  separatorWrap: { paddingLeft: 84, paddingRight: AppSpacing.screenX },
  separator: { height: 1 },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: AppSpacing.screenX,
    paddingVertical: AppSpacing.lg,
  },
  rowBody: { flex: 1, marginLeft: AppSpacing.lg },
  rowHead: { flexDirection: 'row', alignItems: 'center' },
  rowName: { flexShrink: 1 },
  spacer: { flex: 1 },
  activityRow: { flexDirection: 'row', alignItems: 'center', marginTop: AppSpacing.xs + 2 },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginTop: AppSpacing.xs + 2,
  },
  unread: {
    minWidth: 20,
    height: 20,
    paddingHorizontal: 6,
    marginLeft: AppSpacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: AppRadii.pill,
  },
  unreadText: { color: '#FFFFFF', fontSize: 11, lineHeight: 15, fontWeight: '700' },
});
