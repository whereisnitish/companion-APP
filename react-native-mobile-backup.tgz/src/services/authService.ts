import { dataObject, type ApiClient } from '../core/network/apiClient';
import type { AuthTokens } from '../core/storage/tokenStorage';
import { parseCurrentUser, type CurrentUser } from '../models/profile';
import { asObject, asOptionalString, asString } from '../models/json';

export interface AuthSession {
  tokens: AuthTokens;
  user: CurrentUser;
}

function parseSession(json: Record<string, unknown>): AuthSession {
  return {
    tokens: {
      accessToken: asString(json.accessToken),
      refreshToken: asString(json.refreshToken),
    },
    user: parseCurrentUser(asObject(json.user)),
  };
}

export class AuthService {
  constructor(private readonly client: ApiClient) {}

  async register(params: {
    email?: string;
    phone?: string;
    password: string;
  }): Promise<AuthSession> {
    const response = await this.client.post(
      '/auth/register',
      {
        ...(params.email ? { email: params.email } : {}),
        ...(params.phone ? { phone: params.phone } : {}),
        password: params.password,
      },
      { skipAuth: true },
    );
    return parseSession(dataObject(response));
  }

  async login(params: { email?: string; phone?: string; password: string }): Promise<AuthSession> {
    const response = await this.client.post(
      '/auth/login',
      {
        ...(params.email ? { email: params.email } : {}),
        ...(params.phone ? { phone: params.phone } : {}),
        password: params.password,
      },
      { skipAuth: true },
    );
    return parseSession(dataObject(response));
  }

  /**
   * Development OTP: the server returns the code so the flow is testable
   * offline. In production the response carries only `{ sent: true }`.
   */
  async requestOtp(phone: string): Promise<string | null> {
    const response = await this.client.post('/auth/otp/request', { phone }, { skipAuth: true });
    return asOptionalString(dataObject(response).devCode);
  }

  async verifyOtp(phone: string, code: string): Promise<AuthSession> {
    const response = await this.client.post(
      '/auth/otp/verify',
      { phone, code },
      { skipAuth: true },
    );
    return parseSession(dataObject(response));
  }

  async logout(refreshToken: string): Promise<void> {
    await this.client.post('/auth/logout', { refreshToken });
  }
}
