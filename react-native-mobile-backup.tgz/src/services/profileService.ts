import { dataObject, type ApiClient } from '../core/network/apiClient';
import type { ActivityCategory, AvailabilitySlot, Gender } from '../models/enums';
import { asObjects } from '../models/json';
import {
  parseCurrentUser,
  parseInterest,
  parseProfile,
  type CurrentUser,
  type Interest,
  type Profile,
} from '../models/profile';

/** Everything the profile setup flow collects, in one object. */
export interface ProfileDraft {
  displayName: string;
  birthDate: Date | null;
  gender: Gender | null;
  bio: string;
  occupation: string | null;
  city: string;
  area: string | null;
  latitude: number | null;
  longitude: number | null;
  avatarUrl: string | null;
  photos: string[];
  interests: string[];
  preferredActivities: ActivityCategory[];
  availability: AvailabilitySlot[];
}

export const emptyProfileDraft = (): ProfileDraft => ({
  displayName: '',
  birthDate: null,
  gender: null,
  bio: '',
  occupation: null,
  city: 'Bengaluru',
  area: null,
  latitude: null,
  longitude: null,
  avatarUrl: null,
  photos: [],
  interests: [],
  preferredActivities: [],
  availability: [],
});

export function profileDraftToJson(draft: ProfileDraft): Record<string, unknown> {
  return {
    displayName: draft.displayName,
    ...(draft.birthDate ? { birthDate: draft.birthDate.toISOString() } : {}),
    ...(draft.gender ? { gender: draft.gender } : {}),
    bio: draft.bio,
    ...(draft.occupation ? { occupation: draft.occupation } : {}),
    city: draft.city,
    ...(draft.area ? { area: draft.area } : {}),
    ...(draft.latitude !== null ? { latitude: draft.latitude } : {}),
    ...(draft.longitude !== null ? { longitude: draft.longitude } : {}),
    ...(draft.avatarUrl ? { avatarUrl: draft.avatarUrl } : {}),
    photos: draft.photos,
    interests: draft.interests,
    preferredActivities: draft.preferredActivities,
    availability: draft.availability,
  };
}

export class ProfileService {
  constructor(private readonly client: ApiClient) {}

  async fetchMe(): Promise<CurrentUser> {
    const response = await this.client.get('/users/me');
    return parseCurrentUser(dataObject(response));
  }

  async createProfile(draft: ProfileDraft): Promise<CurrentUser> {
    const response = await this.client.post('/users/me/profile', profileDraftToJson(draft));
    return parseCurrentUser(dataObject(response));
  }

  async updateProfile(patch: Record<string, unknown>): Promise<CurrentUser> {
    const response = await this.client.put('/users/me', patch);
    return parseCurrentUser(dataObject(response));
  }

  async fetchProfile(userId: string): Promise<Profile> {
    const response = await this.client.get(`/users/${userId}`);
    return parseProfile(dataObject(response));
  }

  async fetchInterests(): Promise<Interest[]> {
    const response = await this.client.get('/catalog/interests');
    return asObjects(dataObject(response).items).map(parseInterest);
  }
}
