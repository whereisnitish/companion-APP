import { dataList, dataObject, type ApiClient } from '../core/network/apiClient';
import { parseActivity, type Activity } from '../models/activity';
import type { ActivityCategory, GenderPreference } from '../models/enums';

/** What the create-activity flow collects, step by step. */
export interface ActivityDraft {
  category: ActivityCategory | null;
  title: string;
  description: string;
  startsAt: Date | null;
  locationName: string;
  area: string | null;
  city: string;
  latitude: number | null;
  longitude: number | null;
  lookingFor: GenderPreference;
  minAge: number;
  maxAge: number;
  capacity: number;
}

export const emptyActivityDraft = (): ActivityDraft => ({
  category: null,
  title: '',
  description: '',
  startsAt: null,
  locationName: '',
  area: null,
  city: 'Bengaluru',
  latitude: null,
  longitude: null,
  lookingFor: 'ANYONE',
  minAge: 18,
  maxAge: 99,
  capacity: 1,
});

export function isActivityDraftReady(draft: ActivityDraft): boolean {
  return (
    draft.category !== null &&
    draft.title.trim().length >= 3 &&
    draft.startsAt !== null &&
    draft.locationName.trim().length >= 2
  );
}

export function activityDraftToJson(draft: ActivityDraft): Record<string, unknown> {
  return {
    category: draft.category,
    title: draft.title.trim(),
    description: draft.description.trim(),
    startsAt: draft.startsAt?.toISOString() ?? null,
    locationName: draft.locationName.trim(),
    ...(draft.area ? { area: draft.area } : {}),
    city: draft.city,
    latitude: draft.latitude,
    longitude: draft.longitude,
    lookingFor: draft.lookingFor,
    minAge: draft.minAge,
    maxAge: draft.maxAge,
    capacity: draft.capacity,
  };
}

export class ActivityService {
  constructor(private readonly client: ApiClient) {}

  async create(draft: ActivityDraft): Promise<Activity> {
    const response = await this.client.post('/activities', activityDraftToJson(draft));
    return parseActivity(dataObject(response));
  }

  async fetch(id: string): Promise<Activity> {
    const response = await this.client.get(`/activities/${id}`);
    return parseActivity(dataObject(response));
  }

  async list(scope = 'mine'): Promise<Activity[]> {
    const response = await this.client.get('/activities', { scope, limit: 50 });
    return dataList(response).map(parseActivity);
  }

  async cancel(id: string): Promise<void> {
    await this.client.delete(`/activities/${id}`);
  }
}
