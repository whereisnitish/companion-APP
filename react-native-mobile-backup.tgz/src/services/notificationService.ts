import { dataList, meta, type ApiClient } from '../core/network/apiClient';
import { parseNotification, type AppNotification } from '../models/appNotification';
import { asInt } from '../models/json';

export interface NotificationPage {
  items: AppNotification[];
  unreadCount: number;
}

export class NotificationService {
  constructor(private readonly client: ApiClient) {}

  async list(): Promise<NotificationPage> {
    const response = await this.client.get('/notifications', { limit: 40 });
    return {
      items: dataList(response).map(parseNotification),
      unreadCount: asInt(meta(response).unreadCount),
    };
  }

  async markRead(id: string): Promise<void> {
    await this.client.post(`/notifications/${id}/read`);
  }

  async markAllRead(): Promise<void> {
    await this.client.post('/notifications/read-all');
  }
}
