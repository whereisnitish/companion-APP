import { ApiClient } from '../core/network/apiClient';
import { SocketClient } from '../core/realtime/socketClient';
import { TokenStorage } from '../core/storage/tokenStorage';
import { ActivityService } from './activityService';
import { AuthService } from './authService';
import { ConversationService } from './conversationService';
import { DiscoveryService } from './discoveryService';
import { InvitationService } from './invitationService';
import { NotificationService } from './notificationService';
import { ProfileService } from './profileService';
import { SafetyService } from './safetyService';

/**
 * The service graph, built once for the process.
 *
 * Riverpod wired these together lazily; in React the wiring is static, so a
 * single module-level container keeps every consumer pointing at the same
 * `ApiClient` (and therefore the same in-memory access token) without a
 * provider tree.
 */
export const tokenStorage = new TokenStorage();
export const apiClient = new ApiClient(tokenStorage);
export const socketClient = new SocketClient();

export const authService = new AuthService(apiClient);
export const profileService = new ProfileService(apiClient);
export const discoveryService = new DiscoveryService(apiClient);
export const activityService = new ActivityService(apiClient);
export const invitationService = new InvitationService(apiClient);
export const conversationService = new ConversationService(apiClient);
export const notificationService = new NotificationService(apiClient);
export const safetyService = new SafetyService(apiClient);

export * from './activityService';
export * from './authService';
export * from './conversationService';
export * from './discoveryService';
export * from './invitationService';
export * from './notificationService';
export * from './profileService';
export * from './safetyService';
