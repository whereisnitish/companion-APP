import { dataObject, type ApiClient } from '../core/network/apiClient';
import { asObjects, asOptionalString, asString } from '../models/json';

/** Why someone was reported. The wire values match the backend enum exactly. */
export type ReportReason =
  | 'INAPPROPRIATE_MESSAGES'
  | 'FAKE_PROFILE'
  | 'HARASSMENT'
  | 'INAPPROPRIATE_PHOTOS'
  | 'SCAM_OR_SPAM'
  | 'UNDERAGE'
  | 'SAFETY_CONCERN'
  | 'OTHER';

export const REPORT_REASONS: readonly ReportReason[] = [
  'INAPPROPRIATE_MESSAGES',
  'FAKE_PROFILE',
  'HARASSMENT',
  'INAPPROPRIATE_PHOTOS',
  'SCAM_OR_SPAM',
  'UNDERAGE',
  'SAFETY_CONCERN',
  'OTHER',
];

const REPORT_REASON_LABELS: Record<ReportReason, string> = {
  INAPPROPRIATE_MESSAGES: 'Inappropriate messages',
  FAKE_PROFILE: 'Fake profile or photos',
  HARASSMENT: 'Harassment or hate',
  INAPPROPRIATE_PHOTOS: 'Inappropriate photos',
  SCAM_OR_SPAM: 'Scam or spam',
  UNDERAGE: 'They may be under 18',
  SAFETY_CONCERN: 'I felt unsafe',
  OTHER: 'Something else',
};

export const reportReasonLabel = (reason: ReportReason) => REPORT_REASON_LABELS[reason];

export interface BlockedUser {
  id: string;
  displayName: string;
  avatarUrl: string | null;
}

export class SafetyService {
  constructor(private readonly client: ApiClient) {}

  async block(userId: string, reason?: string): Promise<void> {
    await this.client.post(`/safety/users/${userId}/block`, reason ? { reason } : {});
  }

  async unblock(userId: string): Promise<void> {
    await this.client.delete(`/safety/users/${userId}/block`);
  }

  async report(userId: string, reason: ReportReason, details: string): Promise<string> {
    const response = await this.client.post(`/safety/users/${userId}/report`, { reason, details });
    return (
      asOptionalString(dataObject(response).message) ??
      'Thanks for letting us know. Our team will review this.'
    );
  }

  async listBlocked(): Promise<BlockedUser[]> {
    const response = await this.client.get('/safety/blocks');
    return asObjects(dataObject(response).items).map((json) => ({
      id: asString(json.id),
      displayName: asString(json.displayName, 'Someone'),
      avatarUrl: asOptionalString(json.avatarUrl),
    }));
  }
}
