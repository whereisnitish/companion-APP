import { dataList, dataObject, meta, type ApiClient } from '../core/network/apiClient';
import { parseActivity, type Activity } from '../models/activity';
import type { ActivityCategory, AvailabilitySlot, Gender } from '../models/enums';
import { parseHomeFeed, type HomeFeed } from '../models/homeFeed';
import { asBool, asInt } from '../models/json';
import { parseProfile, type Profile } from '../models/profile';

/** The full set of discovery filters. Immutable so it can be a query key. */
export interface DiscoveryFilters {
  activities: ActivityCategory[];
  availability: AvailabilitySlot[];
  genders: Gender[];
  interests: string[];
  minAge: number;
  maxAge: number;
  radiusKm: number;
  query: string;
}

export const NO_FILTERS: DiscoveryFilters = {
  activities: [],
  availability: [],
  genders: [],
  interests: [],
  minAge: 18,
  maxAge: 99,
  radiusKm: 25,
  query: '',
};

/**
 * How many filters the user has actually changed — drives the badge on the
 * filter button, so it only ever counts deliberate choices.
 */
export function activeFilterCount(filters: DiscoveryFilters): number {
  let count = 0;
  if (filters.activities.length > 0) count += 1;
  if (filters.availability.length > 0) count += 1;
  if (filters.genders.length > 0) count += 1;
  if (filters.interests.length > 0) count += 1;
  if (filters.minAge !== 18 || filters.maxAge !== 99) count += 1;
  if (filters.radiusKm !== 25) count += 1;
  return count;
}

export const isDefaultFilters = (filters: DiscoveryFilters) => activeFilterCount(filters) === 0;

export function filtersToQuery(
  filters: DiscoveryFilters,
  page: number,
  limit = 20,
): Record<string, unknown> {
  return {
    ...(filters.activities.length > 0 ? { activities: filters.activities.join(',') } : {}),
    ...(filters.availability.length > 0 ? { availability: filters.availability.join(',') } : {}),
    ...(filters.genders.length > 0 ? { genders: filters.genders.join(',') } : {}),
    ...(filters.interests.length > 0 ? { interests: filters.interests.join(',') } : {}),
    minAge: filters.minAge,
    maxAge: filters.maxAge,
    radiusKm: filters.radiusKm,
    ...(filters.query.trim().length > 0 ? { query: filters.query.trim() } : {}),
    page,
    limit,
  };
}

export interface PagedResult<T> {
  items: T[];
  page: number;
  hasMore: boolean;
}

export class DiscoveryService {
  constructor(private readonly client: ApiClient) {}

  async fetchHomeFeed(): Promise<HomeFeed> {
    const response = await this.client.get('/discover');
    return parseHomeFeed(dataObject(response));
  }

  async discoverPeople(
    filters: DiscoveryFilters,
    page = 1,
    limit = 20,
  ): Promise<PagedResult<Profile>> {
    const response = await this.client.get('/discover/people', filtersToQuery(filters, page, limit));
    const envelopeMeta = meta(response);
    return {
      items: dataList(response).map(parseProfile),
      page: asInt(envelopeMeta.page, page),
      hasMore: asBool(envelopeMeta.hasMore),
    };
  }

  async discoverActivities(
    filters: DiscoveryFilters,
    page = 1,
    limit = 20,
  ): Promise<PagedResult<Activity>> {
    const response = await this.client.get(
      '/discover/activities',
      filtersToQuery(filters, page, limit),
    );
    const envelopeMeta = meta(response);
    return {
      items: dataList(response).map(parseActivity),
      page: asInt(envelopeMeta.page, page),
      hasMore: asBool(envelopeMeta.hasMore),
    };
  }
}
