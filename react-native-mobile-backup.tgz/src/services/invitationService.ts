import { dataList, dataObject, type ApiClient } from '../core/network/apiClient';
import type { ActivityCategory, InvitationStatus } from '../models/enums';
import {
  parseInvitation,
  parseInvitationCounts,
  type Invitation,
  type InvitationCounts,
  type InvitationDirection,
} from '../models/invitation';

export class InvitationService {
  constructor(private readonly client: ApiClient) {}

  async send(params: {
    recipientId: string;
    activityId?: string | null;
    category?: ActivityCategory | null;
    proposedAt?: Date | null;
    locationName?: string | null;
    message?: string;
  }): Promise<Invitation> {
    const response = await this.client.post('/invitations', {
      recipientId: params.recipientId,
      ...(params.activityId ? { activityId: params.activityId } : {}),
      ...(params.category ? { category: params.category } : {}),
      ...(params.proposedAt ? { proposedAt: params.proposedAt.toISOString() } : {}),
      ...(params.locationName ? { locationName: params.locationName } : {}),
      message: params.message ?? '',
    });
    return parseInvitation(dataObject(response));
  }

  async list(direction: InvitationDirection, status?: InvitationStatus): Promise<Invitation[]> {
    const path = direction === 'received' ? '/invitations/received' : '/invitations/sent';
    const response = await this.client.get(path, {
      limit: 50,
      ...(status ? { status } : {}),
    });
    return dataList(response).map(parseInvitation);
  }

  async counts(): Promise<InvitationCounts> {
    const response = await this.client.get('/invitations/counts');
    return parseInvitationCounts(dataObject(response));
  }

  async accept(id: string): Promise<Invitation> {
    const response = await this.client.post(`/invitations/${id}/accept`);
    return parseInvitation(dataObject(response));
  }

  async decline(id: string): Promise<Invitation> {
    const response = await this.client.post(`/invitations/${id}/decline`);
    return parseInvitation(dataObject(response));
  }

  async cancel(id: string): Promise<Invitation> {
    const response = await this.client.post(`/invitations/${id}/cancel`);
    return parseInvitation(dataObject(response));
  }
}
