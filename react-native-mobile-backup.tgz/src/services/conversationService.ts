import { dataList, dataObject, meta, type ApiClient } from '../core/network/apiClient';
import {
  parseConversation,
  parseMessage,
  type Conversation,
  type Message,
} from '../models/conversation';
import { asOptionalString } from '../models/json';

export interface MessagePage {
  messages: Message[];
  nextCursor: string | null;
}

export class ConversationService {
  constructor(private readonly client: ApiClient) {}

  async list(): Promise<Conversation[]> {
    const response = await this.client.get('/conversations');
    return dataList(response).map(parseConversation);
  }

  async fetch(id: string): Promise<Conversation> {
    const response = await this.client.get(`/conversations/${id}`);
    return parseConversation(dataObject(response));
  }

  /**
   * Returns messages newest-first; the chat view renders an inverted list so
   * paging older messages never disturbs the scroll position.
   */
  async messages(conversationId: string, cursor?: string | null, limit = 30): Promise<MessagePage> {
    const response = await this.client.get(`/conversations/${conversationId}/messages`, {
      limit,
      ...(cursor ? { cursor } : {}),
    });
    return {
      messages: dataList(response).map(parseMessage),
      nextCursor: asOptionalString(meta(response).nextCursor),
    };
  }

  async send(conversationId: string, body: string): Promise<Message> {
    const response = await this.client.post(`/conversations/${conversationId}/messages`, { body });
    return parseMessage(dataObject(response));
  }

  async markRead(conversationId: string): Promise<void> {
    await this.client.post(`/conversations/${conversationId}/read`);
  }
}
