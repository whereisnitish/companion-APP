# Companion — mobile

React Native (Expo SDK 54) client for Companion. Ported from the original
Flutter app; the product, the design system and the API contract are unchanged.

## Running it

```bash
npm install
npx expo start          # then press i / a, or scan with Expo Go
```

The backend must be running (`cd ../backend && npm run dev`).

### Pointing at the API

`AppConfig` resolves the host in this order:

1. `EXPO_PUBLIC_API_BASE_URL`
2. `expo.extra.apiBaseUrl` in `app.json`
3. **the packager's own host** — so a physical device on the same Wi-Fi finds
   your machine automatically
4. `10.0.2.2:4000` on Android, `localhost:4000` everywhere else

To override:

```bash
EXPO_PUBLIC_API_BASE_URL=http://192.168.1.18:4000 npx expo start
```

## Checks

```bash
npm run typecheck   # tsc --noEmit
npm test            # jest
```

## How the Flutter concepts map

| Flutter | React Native |
| --- | --- |
| Riverpod `StateNotifierProvider` (auth, discover) | Zustand stores — `src/stores/` |
| Riverpod `FutureProvider` (feed, invites, inbox) | TanStack Query hooks — `src/queries/` |
| Riverpod `Provider` for services | a module-level container — `src/services/index.ts` |
| `ref.listen(realtimeEvents)` inside each provider | one event→query table — `src/queries/realtimeBridge.ts` |
| go_router `redirect` on auth stage | conditionally mounted stacks — `src/navigation/RootNavigator.tsx` |
| `StatefulShellRoute.indexedStack` | `createBottomTabNavigator` with a custom tab bar |
| `ThemeExtension` (`AppColors`, `AppTypography`) | `ThemeProvider` + `useTheme()` — `src/theme/` |
| `showModalBottomSheet` (imperative) | host components at the root (`InviteSheetProvider`, `SafetyActionsProvider`, `SnackbarProvider`) |
| `CustomPainter` (brand mark, success burst, onboarding art) | `react-native-svg` |
| Dio + interceptors | axios + interceptors — `src/core/network/apiClient.ts` |
| `flutter_secure_storage` | `expo-secure-store` |
| `shared_preferences` | `@react-native-async-storage/async-storage` |
| `cached_network_image` | `expo-image` |
| `intl` `DateFormat` | `date-fns` |

## Layout

```
src/
  core/        config, axios client, secure storage, socket, formatters
  models/      wire types and defensive parsers
  services/    one class per API area, plus the service container
  stores/      auth, discover, and the per-conversation chat hook
  queries/     TanStack Query hooks, keys, and the realtime bridge
  theme/       colour, type, spacing, shadow tokens + ThemeProvider
  components/  the design system (button, card, chip, sheet, avatar, …)
  features/    one folder per feature, mirroring the Flutter layout
  navigation/  root stack, tabs, and the auth gate
```

## Deliberately stubbed

Carried over from the Flutter MVP: photo upload (a curated set is offered
instead), identity verification, and push delivery — notifications persist
server-side and are read in-app.
