#!/usr/bin/env bash
# Generates the android/ and ios/ platform folders for this project without
# clobbering the hand-written pubspec.yaml, then fetches packages.
set -euo pipefail

cd "$(dirname "$0")/.."

cp pubspec.yaml pubspec.yaml.bak

flutter create \
  --platforms=android,ios \
  --project-name companion \
  --org app.companion \
  --no-overwrite \
  .

# `flutter create` rewrites pubspec.yaml with its own template. Restore ours.
mv pubspec.yaml.bak pubspec.yaml

flutter pub get

echo
echo "Mobile app ready. Run it with:"
echo "  flutter run --dart-define=API_BASE_URL=http://localhost:4000    # iOS simulator"
echo "  flutter run --dart-define=API_BASE_URL=http://10.0.2.2:4000     # Android emulator"
